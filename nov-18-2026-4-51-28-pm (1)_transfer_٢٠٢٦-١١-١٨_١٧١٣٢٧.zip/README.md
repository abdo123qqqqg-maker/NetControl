# نت كنترول (NetControl)

تطبيق أندرويد أصيل (Kotlin + Jetpack Compose + Material 3) باللغة العربية الكاملة مع دعم RTL من اليمين إلى اليسار، مصمم لمراقبة استهلاك الإنترنت، تحليل استهلاك التطبيقات والأجهزة، التوزيع الذكي للباقة، وإدارة أجهزة الراوتر عبر بروتوكولات الشبكة الفعلية.

## المعمارية والبنية البرمجية
- **واجهة المستخدم (UI Layer)**: Jetpack Compose + Material Design 3 + Navigation Compose + رسوم بيانية تفاعلية مخصصة عبر `Canvas` + خطوط عربية مدمجة (`Cairo` و `IBM Plex Sans Arabic`).
- **إدارة الحالة (State Management)**: `NetControlViewModel` مع `StateFlow` و `collectAsStateWithLifecycle`.
- **طبقة البيانات المحلية (Local Persistence)**: Room SQLite (`NetControlDatabase`) لتخزين الأجهزة، حصص التوزيع الذكي، قواعد السرعة، سجل القراءات التاريخية، والإشعارات، بالإضافة إلى `DataStore Preferences` لإعدادات التطبيق.
- **طبقة الأمان والخصوصية**: تشفير كلمات مرور الراوتر ورموز الوسيط باستخدام `AndroidKeyStore` (AES-256-GCM)، وحماية واجهة الإدارة برمز PIN مشفّر (`SHA-256` مع Salt عشوائي) وبصمة الجهاز (`BiometricPrompt`).

## المحركات الفعلية والتوافق مع الراوترات
1. **مراقبة هذا الهاتف والتطبيقات (`AndroidTrafficEngine`)**:
   - يقرأ الاستهلاك الحقيقي للبيانات والتطبيقات عبر `NetworkStatsManager` و `TrafficStats` و `ConnectivityManager` بعد منح صلاحية `PACKAGE_USAGE_STATS`.
2. **فحص الشبكة المحلية (`LanScannerEngine`)**:
   - يكتشف البوابة الافتراضية، ويفحص الأجهزة النشطة عبر الشبكة الفرعية، وبروتوكول `SSDP/UPnP`، وجدول ARP (عند سماح نظام أندرويد)، مع قاعدة بيانات OUI للتعرف على الشركات المصنعة.
3. **نظام محولات الراوتر المرن (`RouterAdapter` / `RouterRegistry`)**:
   - **OpenWrt**: تكامل JSON-RPC عبر `/ubus` (عرض الأجهزة، حظر MAC عبر جدار الحماية، إعادة تشغيل WAN).
   - **MikroTik RouterOS v7+**: تكامل REST API (`/rest/...`) + اكتشاف المنفذ `8728` (عرض أجهزة DHCP، قياس الاستهلاك، تحديد السرعة الفعلي via Simple Queues، وحظر الأجهزة).
   - **Huawei HiLink**: قراءة XML API (`/api/device/information`, `/api/monitoring/traffic-statistics`, `/api/wlan/host-list`).
   - **TR-064 / UPnP IGD**: اكتشاف الراوتر وقراءة الوصف والبيانات عبر XML.
   - **TP-Link / ASUS / ZTE / Tenda**: فحص واجهة الويب وتوضيح الميزات المدعومة وغير المدعومة بشفافية.
   - **وسيط الشبكة المحلي (`NetControlGatewayAdapter`)**: واجهة REST لربط خادم وسيط محلي (مثل Raspberry Pi أو Linux Gateway يعمل بـ `nftables` + `tc`) لتنفيذ حصص الجيجابايت وتحديد السرعة حتى مع راوترات مزودي الخدمة المحدودة.

## البناء والاختبار
- تشغيل الاختبارات:
  `gradle :app:testDebugUnitTest`
- بناء حزمة Debug APK:
  `gradle :app:assembleDebug`
