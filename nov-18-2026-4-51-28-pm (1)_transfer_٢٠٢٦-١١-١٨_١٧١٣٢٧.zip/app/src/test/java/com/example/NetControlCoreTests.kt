package com.example

import com.example.core.network.LanScannerEngine
import com.example.core.security.CryptoManager
import com.example.domain.model.DeviceQuotaAllocation
import com.example.domain.model.Formatters
import com.example.domain.model.RouterVendor
import com.example.router.RouterRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NetControlCoreTests {

    @Test
    fun `quota allocation math calculates remaining and percentage accurately`() {
        val gb50Bytes = 50L * 1024L * 1024L * 1024L
        val used25Gb = 25L * 1024L * 1024L * 1024L
        val quota = DeviceQuotaAllocation(
            deviceId = "mac:AA:BB:CC:DD:EE:FF",
            deviceName = "هاتف أحمد",
            allocatedGb = 50.0,
            usedBytes = used25Gb,
            resetDayOfMonth = 1
        )
        assertEquals(gb50Bytes, quota.effectiveQuotaBytes)
        assertEquals(used25Gb, quota.remainingBytes)
        assertEquals(50f, quota.usagePercent, 0.1f)
    }

    @Test
    fun `extra approved quota increases effective quota and remaining bytes`() {
        val used50Gb = 50L * 1024L * 1024L * 1024L
        val quota = DeviceQuotaAllocation(
            deviceId = "ip:192.168.1.12",
            deviceName = "هاتف محمد",
            allocatedGb = 50.0,
            usedBytes = used50Gb,
            resetDayOfMonth = 1,
            extraApprovedGb = 10.0
        )
        assertEquals(10L * 1024L * 1024L * 1024L, quota.remainingBytes)
        assertTrue(quota.usagePercent < 90f)
    }

    @Test
    fun `pin hashing verifies correct pin and rejects wrong pin`() {
        val salt = CryptoManager.generateSalt()
        val hash = CryptoManager.hashPin("4829", salt)
        assertTrue(CryptoManager.verifyPin("4829", salt, hash))
        assertFalse(CryptoManager.verifyPin("1234", salt, hash))
    }

    @Test
    fun `lan scanner validates RFC1918 private ipv4 and OUI vendors`() {
        val scanner = LanScannerEngine()
        assertTrue(scanner.isPrivateIpv4("192.168.1.1"))
        assertTrue(scanner.isPrivateIpv4("10.0.0.5"))
        assertTrue(scanner.isPrivateIpv4("172.16.4.10"))
        assertFalse(scanner.isPrivateIpv4("8.8.8.8"))

        assertEquals("TP-Link", LanScannerEngine.lookupOuiVendor("50:C7:BF:11:22:33"))
        assertEquals("MikroTik", LanScannerEngine.lookupOuiVendor("4C:5E:0C:AA:BB:CC"))
        assertEquals("Apple", LanScannerEngine.lookupOuiVendor("28:CF:E9:01:02:03"))
    }

    @Test
    fun `router registry reports honest capability matrices per vendor`() {
        val registry = RouterRegistry()
        val mikrotikCaps = registry.capabilitiesFor(RouterVendor.MIKROTIK)
        val openwrtCaps = registry.capabilitiesFor(RouterVendor.OPENWRT)
        val gatewayCaps = registry.capabilitiesFor(RouterVendor.GATEWAY_AGENT)
        val tplinkCaps = registry.capabilitiesFor(RouterVendor.TPLINK)
        val huaweiCaps = registry.capabilitiesFor(RouterVendor.HUAWEI)

        assertTrue(mikrotikCaps.supportsSpeedLimiting)
        assertTrue(mikrotikCaps.supportsDeviceBlocking)
        assertTrue(openwrtCaps.supportsDeviceBlocking)
        assertTrue(gatewayCaps.supportsQuotaEnforcement)
        assertTrue(gatewayCaps.supportsSpeedLimiting)

        // Stock TP-Link & Huawei HiLink must not claim direct per-device speed/quota enforcement
        assertFalse(tplinkCaps.supportsQuotaEnforcement)
        assertFalse(tplinkCaps.supportsSpeedLimiting)
        assertFalse(huaweiCaps.supportsSpeedLimiting)
        assertTrue(huaweiCaps.supportsDeviceList)
    }

    @Test
    fun `arabic byte and speed formatters return expected units`() {
        assertTrue(Formatters.formatBytes(2L * 1024L * 1024L * 1024L).contains("جيجابايت"))
        assertTrue(Formatters.formatBytes(15L * 1024L * 1024L).contains("ميجابايت"))
        assertTrue(Formatters.formatSpeedBps(2_500_000L).contains("ميجابت/ث"))
    }
}
