package com.example.core.network

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.content.Intent
import com.example.domain.model.AppUsageStat
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.LiveConnectionInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.util.Calendar

class AndroidTrafficEngine(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val networkStatsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as? NetworkStatsManager

    private var lastSampleTimeMs: Long = System.currentTimeMillis()
    private var lastTotalRxBytes: Long = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
    private var lastTotalTxBytes: Long = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessIntent(): Intent {
        return Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun sampleLiveConnection(): LiveConnectionInfo {
        val now = System.currentTimeMillis()
        val currentRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val currentTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
        val elapsedSec = ((now - lastSampleTimeMs).coerceAtLeast(500L)) / 1000.0

        val rxSpeedBps = if (currentRx >= lastTotalRxBytes && lastTotalRxBytes > 0L) {
            ((currentRx - lastTotalRxBytes) / elapsedSec).toLong()
        } else 0L

        val txSpeedBps = if (currentTx >= lastTotalTxBytes && lastTotalTxBytes > 0L) {
            ((currentTx - lastTotalTxBytes) / elapsedSec).toLong()
        } else 0L

        lastSampleTimeMs = now
        lastTotalRxBytes = currentRx
        lastTotalTxBytes = currentTx

        val activeNetwork = connectivityManager.activeNetwork
        val caps = activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
        val linkProps = activeNetwork?.let { connectivityManager.getLinkProperties(it) }

        val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val isValidated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

        val status = when {
            caps == null -> ConnectionStatus.OFFLINE
            !hasInternet -> ConnectionStatus.LIMITED
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                if (isValidated) ConnectionStatus.WIFI_ONLINE else ConnectionStatus.LIMITED
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                if (isValidated) ConnectionStatus.CELLULAR_ONLINE else ConnectionStatus.LIMITED
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                if (isValidated) ConnectionStatus.ETHERNET_ONLINE else ConnectionStatus.LIMITED
            }
            else -> if (isValidated) ConnectionStatus.WIFI_ONLINE else ConnectionStatus.LIMITED
        }

        val localIp = linkProps?.linkAddresses
            ?.mapNotNull { it.address as? Inet4Address }
            ?.firstOrNull { !it.isLoopbackAddress }
            ?.hostAddress ?: "—"

        val routeGateway = linkProps?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress

        @Suppress("DEPRECATION")
        val dhcpGateway = wifiManager?.dhcpInfo?.gateway?.let { intToIp(it) }?.takeIf { it != "0.0.0.0" }
        val gatewayIp = routeGateway ?: dhcpGateway ?: "—"

        val dnsServers = linkProps?.dnsServers?.mapNotNull { it.hostAddress }.orEmpty()

        @Suppress("DEPRECATION")
        val wifiInfo = wifiManager?.connectionInfo
        val linkSpeedMbps = wifiInfo?.linkSpeed?.takeIf { it > 0 } ?: 0
        @Suppress("DEPRECATION")
        val signalPercent = wifiInfo?.rssi?.let { rssi ->
            WifiManager.calculateSignalLevel(rssi, 100)
        } ?: 0

        @Suppress("DEPRECATION")
        val rawSsid = wifiInfo?.ssid?.trim('"')?.takeIf {
            it.isNotBlank() && it != "<unknown ssid>"
        }

        val networkName = when (status) {
            ConnectionStatus.WIFI_ONLINE -> rawSsid ?: "شبكة Wi-Fi المحلية"
            ConnectionStatus.CELLULAR_ONLINE -> "بيانات الهاتف المحمول"
            ConnectionStatus.ETHERNET_ONLINE -> "شبكة إيثرنت"
            ConnectionStatus.LIMITED -> rawSsid ?: "شبكة محلية (بدون إنترنت)"
            ConnectionStatus.OFFLINE -> "لا يوجد اتصال"
        }

        return LiveConnectionInfo(
            status = status,
            networkName = networkName,
            localIp = localIp,
            gatewayIp = gatewayIp,
            dnsServers = dnsServers,
            linkSpeedMbps = linkSpeedMbps,
            signalPercent = signalPercent,
            downloadBps = rxSpeedBps,
            uploadBps = txSpeedBps
        )
    }

    suspend fun queryPhoneDataTotals(): Triple<Long, Long, Long> = withContext(Dispatchers.IO) {
        if (!hasUsageStatsPermission() || networkStatsManager == null) {
            return@withContext Triple(0L, 0L, 0L)
        }
        val now = System.currentTimeMillis()
        val todayStart = startOfDayMillis()
        val weekStart = startOfWeekMillis()
        val monthStart = startOfMonthMillis()

        val today = queryDeviceTotalRange(todayStart, now)
        val week = queryDeviceTotalRange(weekStart, now)
        val month = queryDeviceTotalRange(monthStart, now)
        Triple(today, week, month)
    }

    suspend fun queryInstalledAppsUsage(): List<AppUsageStat> = withContext(Dispatchers.IO) {
        if (!hasUsageStatsPermission() || networkStatsManager == null) {
            return@withContext emptyList()
        }

        val now = System.currentTimeMillis()
        val todayStart = startOfDayMillis()
        val weekStart = startOfWeekMillis()
        val monthStart = startOfMonthMillis()

        val todayMap = queryUidBreakdown(todayStart, now)
        val weekMap = queryUidBreakdown(weekStart, now)
        val monthMap = queryUidBreakdown(monthStart, now)

        val allUids = (todayMap.keys + weekMap.keys + monthMap.keys).distinct()
        val totalMonthAllApps = monthMap.values.sumOf { it.first + it.second }.coerceAtLeast(1L)

        val pm = context.packageManager
        val stats = mutableListOf<AppUsageStat>()

        for (uid in allUids) {
            val monthPair = monthMap[uid] ?: (0L to 0L)
            val weekPair = weekMap[uid] ?: (0L to 0L)
            val todayPair = todayMap[uid] ?: (0L to 0L)

            val monthTotal = monthPair.first + monthPair.second
            if (monthTotal <= 0L) continue

            val (pkgName, label) = resolveUidIdentity(pm, uid)
            stats.add(
                AppUsageStat(
                    packageName = pkgName,
                    appName = label,
                    uid = uid,
                    totalBytes = monthTotal,
                    downloadBytes = monthPair.first,
                    uploadBytes = monthPair.second,
                    todayBytes = todayPair.first + todayPair.second,
                    weekBytes = weekPair.first + weekPair.second,
                    monthBytes = monthTotal,
                    percentageOfTotal = ((monthTotal.toDouble() / totalMonthAllApps.toDouble()) * 100.0).toFloat()
                )
            )
        }

        stats.sortedByDescending { it.monthBytes }
    }

    private fun queryDeviceTotalRange(startMs: Long, endMs: Long): Long {
        var total = 0L
        val mgr = networkStatsManager ?: return 0L
        listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE).forEach { netType ->
            runCatching {
                @Suppress("DEPRECATION")
                val bucket = mgr.querySummaryForDevice(netType, null, startMs, endMs)
                total += bucket.rxBytes + bucket.txBytes
            }
        }
        return total
    }

    private fun queryUidBreakdown(startMs: Long, endMs: Long): Map<Int, Pair<Long, Long>> {
        val mgr = networkStatsManager ?: return emptyMap()
        val result = mutableMapOf<Int, Pair<Long, Long>>()
        listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE).forEach { netType ->
            runCatching {
                @Suppress("DEPRECATION")
                val stats = mgr.querySummary(netType, null, startMs, endMs)
                val bucket = NetworkStats.Bucket()
                while (stats.hasNextBucket()) {
                    stats.getNextBucket(bucket)
                    val uid = bucket.uid
                    val prev = result[uid] ?: (0L to 0L)
                    result[uid] = (prev.first + bucket.rxBytes) to (prev.second + bucket.txBytes)
                }
                stats.close()
            }
        }
        return result
    }

    private fun resolveUidIdentity(pm: PackageManager, uid: Int): Pair<String, String> {
        when (uid) {
            Process.SYSTEM_UID -> return "android.system" to "خدمات نظام أندرويد"
            1001 -> return "com.android.phone" to "اتصالات الهاتف والشبكة"
            NetworkStats.Bucket.UID_TETHERING -> return "android.tethering" to "نقطة الاتصال والمشاركة"
            NetworkStats.Bucket.UID_REMOVED -> return "android.removed" to "تطبيقات محذوفة"
        }
        val pkgs = pm.getPackagesForUid(uid)
        val primaryPkg = pkgs?.firstOrNull() ?: return "uid.$uid" to "تطبيق نظام ($uid)"
        val label = runCatching {
            val appInfo: ApplicationInfo = pm.getApplicationInfo(primaryPkg, 0)
            pm.getApplicationLabel(appInfo).toString()
        }.getOrElse { primaryPkg }
        return primaryPkg to label
    }

    private fun startOfDayMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfWeekMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun startOfMonthMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun intToIp(ip: Int): String {
        return "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }
}
