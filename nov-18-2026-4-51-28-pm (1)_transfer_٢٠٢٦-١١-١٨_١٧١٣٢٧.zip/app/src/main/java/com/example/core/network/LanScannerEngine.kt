package com.example.core.network

import android.os.Build
import com.example.domain.model.DeviceIconKey
import com.example.domain.model.DeviceInfo
import com.example.domain.model.DeviceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

data class LanDiscoveryReport(
    val devices: List<DeviceInfo>,
    val arpAccessible: Boolean,
    val noteAr: String
)

class LanScannerEngine {

    suspend fun scanLocalNetwork(
        localIp: String,
        gatewayIp: String
    ): LanDiscoveryReport = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val discovered = linkedMapOf<String, DeviceInfo>()

        // 1. Always register this Android phone accurately
        if (localIp != "—" && isPrivateIpv4(localIp)) {
            val phoneName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
            discovered[localIp] = DeviceInfo(
                id = "ip:$localIp",
                originalName = "$phoneName (هذا الهاتف)",
                customName = "",
                ipAddress = localIp,
                macAddress = "محلي (أندرويد)",
                deviceType = DeviceType.PHONE,
                manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
                isOnline = true,
                isKnown = true,
                isNew = false,
                isBlocked = false,
                isPaused = false,
                iconKey = DeviceIconKey.SMARTPHONE,
                totalBytes = 0L,
                downloadBytes = 0L,
                uploadBytes = 0L,
                todayBytes = 0L,
                weekBytes = 0L,
                monthBytes = 0L,
                currentDownloadBps = 0L,
                currentUploadBps = 0L,
                lastSeenMillis = now,
                sourceLabelAr = "الجهاز الحالي"
            )
        }

        // 2. Always register Gateway if detected
        if (gatewayIp != "—" && isPrivateIpv4(gatewayIp)) {
            discovered[gatewayIp] = DeviceInfo(
                id = "ip:$gatewayIp",
                originalName = "بوابة الشبكة / الراوتر ($gatewayIp)",
                customName = "",
                ipAddress = gatewayIp,
                macAddress = "—",
                deviceType = DeviceType.ROUTER,
                manufacturer = "البوابة الافتراضية",
                isOnline = true,
                isKnown = true,
                isNew = false,
                isBlocked = false,
                isPaused = false,
                iconKey = DeviceIconKey.OTHER,
                totalBytes = 0L,
                downloadBytes = 0L,
                uploadBytes = 0L,
                todayBytes = 0L,
                weekBytes = 0L,
                monthBytes = 0L,
                currentDownloadBps = 0L,
                currentUploadBps = 0L,
                lastSeenMillis = now,
                sourceLabelAr = "بوابة الشبكة"
            )
        }

        // 3. Try reading /proc/net/arp (works on Android <= 10, restricted on Android 11+)
        val arpEntries = readProcNetArp()
        for ((ip, mac) in arpEntries) {
            val vendor = lookupOuiVendor(mac)
            val inferredType = inferDeviceType(vendor, null)
            val existing = discovered[ip]
            val key = if (mac != "00:00:00:00:00:00" && mac.isNotBlank()) "mac:${mac.uppercase()}" else "ip:$ip"
            discovered[ip] = (existing ?: DeviceInfo(
                id = key,
                originalName = if (vendor != "غير معروف") "$vendor ($ip)" else "جهاز شبكة ($ip)",
                customName = "",
                ipAddress = ip,
                macAddress = mac.uppercase(),
                deviceType = inferredType,
                manufacturer = vendor,
                isOnline = true,
                isKnown = false,
                isNew = true,
                isBlocked = false,
                isPaused = false,
                iconKey = iconForDeviceType(inferredType),
                totalBytes = 0L,
                downloadBytes = 0L,
                uploadBytes = 0L,
                todayBytes = 0L,
                weekBytes = 0L,
                monthBytes = 0L,
                currentDownloadBps = 0L,
                currentUploadBps = 0L,
                lastSeenMillis = now,
                sourceLabelAr = "جدول ARP المحلي"
            )).copy(
                id = if (existing?.sourceLabelAr == "الجهاز الحالي") existing.id else key,
                macAddress = mac.uppercase(),
                manufacturer = if (vendor != "غير معروف") vendor else (existing?.manufacturer ?: vendor)
            )
        }

        // 4. SSDP Multicast Discovery for UPnP routers, Smart TVs, Media Devices
        val ssdpHosts = discoverSsdpDevices()
        for ((ip, serverHeader) in ssdpHosts) {
            val existing = discovered[ip]
            val inferredType = inferDeviceType(serverHeader, serverHeader)
            if (existing == null) {
                discovered[ip] = DeviceInfo(
                    id = "ip:$ip",
                    originalName = serverHeader.take(36).ifBlank { "جهاز UPnP ($ip)" },
                    customName = "",
                    ipAddress = ip,
                    macAddress = "—",
                    deviceType = inferredType,
                    manufacturer = extractVendorFromServer(serverHeader),
                    isOnline = true,
                    isKnown = false,
                    isNew = true,
                    isBlocked = false,
                    isPaused = false,
                    iconKey = iconForDeviceType(inferredType),
                    totalBytes = 0L,
                    downloadBytes = 0L,
                    uploadBytes = 0L,
                    todayBytes = 0L,
                    weekBytes = 0L,
                    monthBytes = 0L,
                    currentDownloadBps = 0L,
                    currentUploadBps = 0L,
                    lastSeenMillis = now,
                    sourceLabelAr = "اكتشاف SSDP / UPnP"
                )
            }
        }

        // 5. Fast Subnet Probe on /24 prefix (TCP common ports + ICMP reachability)
        val subnetPrefix = localIp.substringBeforeLast('.', "")
            .takeIf { it.count { ch -> ch == '.' } == 2 && isPrivateIpv4(localIp) }
            ?: gatewayIp.substringBeforeLast('.', "")
                .takeIf { it.count { ch -> ch == '.' } == 2 && isPrivateIpv4(gatewayIp) }

        if (subnetPrefix != null) {
            val activeIps = probeSubnetHosts(subnetPrefix, skipIps = discovered.keys)
            for ((ip, hostName) in activeIps) {
                if (!discovered.containsKey(ip)) {
                    val inferredType = inferDeviceType(hostName, hostName)
                    discovered[ip] = DeviceInfo(
                        id = "ip:$ip",
                        originalName = hostName?.takeIf { it != ip } ?: "جهاز متصل ($ip)",
                        customName = "",
                        ipAddress = ip,
                        macAddress = "—",
                        deviceType = inferredType,
                        manufacturer = "غير محدد (يلزم ربط الراوتر لـ MAC)",
                        isOnline = true,
                        isKnown = false,
                        isNew = true,
                        isBlocked = false,
                        isPaused = false,
                        iconKey = iconForDeviceType(inferredType),
                        totalBytes = 0L,
                        downloadBytes = 0L,
                        uploadBytes = 0L,
                        todayBytes = 0L,
                        weekBytes = 0L,
                        monthBytes = 0L,
                        currentDownloadBps = 0L,
                        currentUploadBps = 0L,
                        lastSeenMillis = now,
                        sourceLabelAr = "فحص الشبكة الفرعية"
                    )
                }
            }
        }

        val arpAccessible = arpEntries.isNotEmpty()
        val note = if (arpAccessible) {
            "تم فحص الشبكة المحلية وقراءة عناوين MAC عبر جدول ARP."
        } else {
            "قيود أندرويد الحديثة تمنع قراءة جدول ARP مباشرة؛ تم فحص الأجهزة النشطة عبر الشبكة الفرعية وUPnP. اربط الراوتر للحصول على قائمة MAC الكاملة واستهلاك كل جهاز."
        }

        LanDiscoveryReport(
            devices = discovered.values.toList(),
            arpAccessible = arpAccessible,
            noteAr = note
        )
    }

    private fun readProcNetArp(): List<Pair<String, String>> {
        return runCatching {
            val file = File("/proc/net/arp")
            if (!file.exists() || !file.canRead()) return emptyList()
            file.readLines()
                .drop(1)
                .mapNotNull { line ->
                    val cols = line.trim().split(Regex("\\s+"))
                    if (cols.size >= 4) {
                        val ip = cols[0]
                        val mac = cols[3]
                        if (isPrivateIpv4(ip) && mac.matches(Regex("([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}")) && mac != "00:00:00:00:00:00") {
                            ip to mac
                        } else null
                    } else null
                }
        }.getOrElse { emptyList() }
    }

    private fun discoverSsdpDevices(): Map<String, String> {
        val found = mutableMapOf<String, String>()
        runCatching {
            val socket = DatagramSocket().apply {
                soTimeout = 900
                broadcast = true
            }
            val query = (
                "M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 1\r\n" +
                    "ST: ssdp:all\r\n\r\n"
                ).toByteArray(Charsets.UTF_8)
            val dest = InetAddress.getByName("239.255.255.250")
            socket.send(DatagramPacket(query, query.size, dest, 1900))

            val deadline = System.currentTimeMillis() + 1100L
            val buf = ByteArray(2048)
            while (System.currentTimeMillis() < deadline) {
                val packet = DatagramPacket(buf, buf.size)
                try {
                    socket.receive(packet)
                    val ip = packet.address?.hostAddress ?: continue
                    val body = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    val server = body.lines()
                        .firstOrNull { it.startsWith("SERVER:", ignoreCase = true) }
                        ?.substringAfter(":")?.trim()
                        ?: "جهاز UPnP"
                    if (isPrivateIpv4(ip)) {
                        found.putIfAbsent(ip, server)
                    }
                } catch (_: Exception) {
                    break
                }
            }
            socket.close()
        }
        return found
    }

    private suspend fun probeSubnetHosts(
        prefix: String,
        skipIps: Set<String>
    ): List<Pair<String, String?>> = coroutineScope {
        val probePorts = listOf(80, 443, 8080, 62078, 8008, 554, 22)
        // Scan hosts in chunks of 32 for fast bounded concurrency
        val hosts = (1..254).map { "$prefix.$it" }.filterNot { it in skipIps }
        val results = mutableListOf<Pair<String, String?>>()
        hosts.chunked(32).forEach { chunk ->
            val chunkHits = chunk.map { ip ->
                async(Dispatchers.IO) {
                    val reachable = runCatching {
                        val addr = InetAddress.getByName(ip)
                        if (addr.isReachable(120)) {
                            true
                        } else {
                            probePorts.any { port ->
                                runCatching {
                                    Socket().use { s ->
                                        s.connect(InetSocketAddress(ip, port), 90)
                                        true
                                    }
                                }.getOrDefault(false)
                            }
                        }
                    }.getOrDefault(false)
                    if (reachable) {
                        val host = runCatching { InetAddress.getByName(ip).hostName }.getOrNull()
                        ip to host
                    } else null
                }
            }.awaitAll().filterNotNull()
            results.addAll(chunkHits)
        }
        results
    }

    fun isPrivateIpv4(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        val octets = parts.mapNotNull { it.toIntOrNull() }
        if (octets.size != 4 || octets.any { it !in 0..255 }) return false
        return octets[0] == 10 ||
            (octets[0] == 192 && octets[1] == 168) ||
            (octets[0] == 172 && octets[1] in 16..31)
    }

    companion object {
        fun lookupOuiVendor(mac: String): String {
            val prefix = mac.uppercase().replace("-", ":").take(8)
            return OUI_MAP[prefix] ?: "غير معروف"
        }

        fun inferDeviceType(vendorOrName: String?, hint: String?): DeviceType {
            val text = "${vendorOrName.orEmpty()} ${hint.orEmpty()}".lowercase()
            return when {
                text.contains("tv") || text.contains("lg electronics") || text.contains("bravia") || text.contains("roku") -> DeviceType.TV
                text.contains("iphone") || text.contains("ipad") -> if (text.contains("ipad")) DeviceType.TABLET else DeviceType.PHONE
                text.contains("apple") || text.contains("samsung") || text.contains("xiaomi") || text.contains("oppo") || text.contains("realme") -> DeviceType.PHONE
                text.contains("intel") || text.contains("dell") || text.contains("lenovo") || text.contains("hp") || text.contains("asus") -> DeviceType.LAPTOP
                text.contains("router") || text.contains("gateway") || text.contains("mikrotik") || text.contains("openwrt") || text.contains("tp-link") -> DeviceType.ROUTER
                text.contains("espressif") || text.contains("tuya") || text.contains("sonoff") -> DeviceType.IOT
                else -> DeviceType.UNKNOWN
            }
        }

        fun iconForDeviceType(type: DeviceType): DeviceIconKey = when (type) {
            DeviceType.PHONE -> DeviceIconKey.SMARTPHONE
            DeviceType.LAPTOP -> DeviceIconKey.LAPTOP
            DeviceType.DESKTOP -> DeviceIconKey.DESKTOP
            DeviceType.TV -> DeviceIconKey.TV
            DeviceType.TABLET -> DeviceIconKey.TABLET
            DeviceType.IOT -> DeviceIconKey.IOT
            DeviceType.ROUTER, DeviceType.UNKNOWN -> DeviceIconKey.OTHER
        }

        private fun extractVendorFromServer(server: String): String {
            val lower = server.lowercase()
            return when {
                lower.contains("tp-link") -> "TP-Link"
                lower.contains("huawei") -> "Huawei"
                lower.contains("asus") -> "ASUS"
                lower.contains("mikrotik") -> "MikroTik"
                lower.contains("openwrt") -> "OpenWrt"
                lower.contains("samsung") -> "Samsung"
                lower.contains("lg") -> "LG"
                lower.contains("sony") -> "Sony"
                else -> "جهاز شبكة"
            }
        }

        private val OUI_MAP = mapOf(
            "00:1A:2B" to "Cisco",
            "00:50:56" to "VMware",
            "00:1D:AA" to "TP-Link",
            "50:C7:BF" to "TP-Link",
            "B0:BE:76" to "TP-Link",
            "EC:08:6B" to "TP-Link",
            "00:E0:FC" to "Huawei",
            "28:6E:D4" to "Huawei",
            "48:46:FB" to "Huawei",
            "70:72:3C" to "Huawei",
            "04:D9:F5" to "ASUS",
            "2C:FD:A1" to "ASUS",
            "38:D5:47" to "ASUS",
            "4C:5E:0C" to "MikroTik",
            "D4:CA:6D" to "MikroTik",
            "CC:2D:E0" to "MikroTik",
            "C8:3A:35" to "Tenda",
            "D8:32:14" to "Tenda",
            "54:22:F8" to "ZTE",
            "78:96:82" to "ZTE",
            "F4:F5:D8" to "Google",
            "3C:5A:B4" to "Google",
            "28:CF:E9" to "Apple",
            "F0:18:98" to "Apple",
            "AC:BC:32" to "Apple",
            "BC:30:7D" to "Samsung",
            "5C:0A:5B" to "Samsung",
            "34:23:BA" to "Samsung",
            "64:CC:2E" to "Xiaomi",
            "7C:1D:D9" to "Xiaomi",
            "24:0A:C4" to "Espressif (IoT)",
            "A4:CF:12" to "Espressif (IoT)",
            "3C:7C:3F" to "ASUS",
            "98:DE:D0" to "TP-Link"
        )
    }
}
