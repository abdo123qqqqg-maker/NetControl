package com.example.core.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.domain.model.AnalyticsSummary
import com.example.domain.model.AppUsageStat
import com.example.domain.model.DeviceInfo
import com.example.domain.model.DeviceQuotaAllocation
import com.example.domain.model.Formatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportExporter(private val context: Context) {

    suspend fun exportCsv(
        uri: Uri,
        devices: List<DeviceInfo>,
        apps: List<AppUsageStat>,
        quotas: List<DeviceQuotaAllocation>,
        summary: AnalyticsSummary
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            val sb = StringBuilder()
            // UTF-8 BOM for clean Arabic display in Excel
            sb.append('\uFEFF')
            sb.appendLine("تقرير نت كنترول — $dateStr")
            sb.appendLine("متوسط الاستهلاك اليومي,${Formatters.formatBytes(summary.dailyAverageBytes)}")
            sb.appendLine("إجمالي التحميل,${Formatters.formatBytes(summary.totalDownloadBytes)}")
            sb.appendLine("إجمالي الرفع,${Formatters.formatBytes(summary.totalUploadBytes)}")
            sb.appendLine("توقع انتهاء الباقة,${summary.predictedExhaustionLabelAr}")
            sb.appendLine()
            sb.appendLine("القسم,الاسم,IP / الحزمة,MAC,الشركة المصنعة,الاستهلاك الشهري,التحميل,الرفع,الحالة")
            devices.forEach { d ->
                sb.appendLine(
                    listOf(
                        "جهاز",
                        escapeCsv(d.displayName),
                        escapeCsv(d.ipAddress),
                        escapeCsv(d.macAddress),
                        escapeCsv(d.manufacturer),
                        Formatters.formatBytes(d.monthBytes),
                        Formatters.formatBytes(d.downloadBytes),
                        Formatters.formatBytes(d.uploadBytes),
                        if (d.isOnline) "متصل" else "غير متصل"
                    ).joinToString(",")
                )
            }
            apps.take(40).forEach { a ->
                sb.appendLine(
                    listOf(
                        "تطبيق",
                        escapeCsv(a.appName),
                        escapeCsv(a.packageName),
                        "—",
                        "أندرويد محلي",
                        Formatters.formatBytes(a.monthBytes),
                        Formatters.formatBytes(a.downloadBytes),
                        Formatters.formatBytes(a.uploadBytes),
                        "${String.format(Locale.US, "%.1f", a.percentageOfTotal)}%"
                    ).joinToString(",")
                )
            }
            quotas.forEach { q ->
                sb.appendLine(
                    listOf(
                        "حصة ذكية",
                        escapeCsv(q.deviceName),
                        "—",
                        "—",
                        "تخصيص ${q.allocatedGb} GB",
                        Formatters.formatBytes(q.usedBytes),
                        "—",
                        "—",
                        "${String.format(Locale.US, "%.1f", q.usagePercent)}%"
                    ).joinToString(",")
                )
            }

            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(sb.toString().toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: throw IllegalStateException("تعذر فتح ملف التصدير للكتابة.")
            Unit
        }
    }

    suspend fun exportPdf(
        uri: Uri,
        devices: List<DeviceInfo>,
        apps: List<AppUsageStat>,
        quotas: List<DeviceQuotaAllocation>,
        summary: AnalyticsSummary
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val pdf = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            var page = pdf.startPage(pageInfo)
            var canvas: Canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.rgb(0, 121, 107)
                textSize = 18f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val headerPaint = Paint().apply {
                color = Color.rgb(15, 23, 42)
                textSize = 13f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val bodyPaint = Paint().apply {
                color = Color.rgb(51, 65, 85)
                textSize = 10.5f
                textAlign = Paint.Align.RIGHT
            }

            val rightX = 555f
            var y = 48f

            fun ensureSpace(needed: Float) {
                if (y + needed > 800f) {
                    pdf.finishPage(page)
                    page = pdf.startPage(
                        PdfDocument.PageInfo.Builder(595, 842, pdf.pages.size + 1).create()
                    )
                    canvas = page.canvas
                    y = 48f
                }
            }

            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            canvas.drawText("تقرير نت كنترول — تحليل استهلاك الشبكة", rightX, y, titlePaint)
            y += 22f
            canvas.drawText("تاريخ التقرير: $dateStr", rightX, y, bodyPaint)
            y += 26f

            canvas.drawText("ملخص التحليلات", rightX, y, headerPaint)
            y += 18f
            canvas.drawText("• متوسط الاستهلاك اليومي: ${Formatters.formatBytes(summary.dailyAverageBytes)}", rightX, y, bodyPaint)
            y += 16f
            canvas.drawText("• إجمالي التحميل: ${Formatters.formatBytes(summary.totalDownloadBytes)}  |  الرفع: ${Formatters.formatBytes(summary.totalUploadBytes)}", rightX, y, bodyPaint)
            y += 16f
            canvas.drawText("• توقع انتهاء الباقة: ${summary.predictedExhaustionLabelAr}", rightX, y, bodyPaint)
            y += 24f

            canvas.drawText("الأجهزة المتصلة والمكتشفة (${devices.size})", rightX, y, headerPaint)
            y += 18f
            devices.take(15).forEach { d ->
                ensureSpace(18f)
                val status = if (d.isOnline) "متصل" else "سابق"
                canvas.drawText(
                    "• ${d.displayName} (${d.ipAddress}) — $status — ${Formatters.formatBytes(d.monthBytes)}",
                    rightX,
                    y,
                    bodyPaint
                )
                y += 16f
            }

            y += 12f
            ensureSpace(40f)
            canvas.drawText("أكثر التطبيقات استهلاكًا على هذا الهاتف", rightX, y, headerPaint)
            y += 18f
            apps.take(15).forEach { a ->
                ensureSpace(18f)
                canvas.drawText(
                    "• ${a.appName}: ${Formatters.formatBytes(a.monthBytes)} (${String.format(Locale.US, "%.1f", a.percentageOfTotal)}%)",
                    rightX,
                    y,
                    bodyPaint
                )
                y += 16f
            }

            if (quotas.isNotEmpty()) {
                y += 12f
                ensureSpace(40f)
                canvas.drawText("توزيع الحصص الذكي", rightX, y, headerPaint)
                y += 18f
                quotas.forEach { q ->
                    ensureSpace(18f)
                    canvas.drawText(
                        "• ${q.deviceName}: مخصص ${q.allocatedGb} جيجابايت — مستهلك ${Formatters.formatBytes(q.usedBytes)} (${q.usagePercent.toInt()}%)",
                        rightX,
                        y,
                        bodyPaint
                    )
                    y += 16f
                }
            }

            pdf.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { out ->
                pdf.writeTo(out)
                out.flush()
            } ?: throw IllegalStateException("تعذر فتح ملف PDF للكتابة.")
            pdf.close()
        }
    }

    private fun escapeCsv(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return "\"$clean\""
    }
}
