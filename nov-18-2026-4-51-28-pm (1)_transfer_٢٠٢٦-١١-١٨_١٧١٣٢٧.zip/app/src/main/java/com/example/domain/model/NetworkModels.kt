package com.example.domain.model

import java.text.DecimalFormat
import kotlin.math.roundToInt

enum class AppThemeMode(val labelAr: String) {
    SYSTEM("تلقائي حسب النظام"),
    DARK("الوضع الداكن"),
    LIGHT("الوضع الفاتح")
}

enum class ConnectionStatus(val labelAr: String) {
    WIFI_ONLINE("متصل عبر واي فاي"),
    CELLULAR_ONLINE("متصل عبر بيانات الجوال"),
    ETHERNET_ONLINE("متصل عبر كابل شبكة"),
    LIMITED("اتصال محدود بدون إنترنت"),
    OFFLINE("غير متصل بالإنترنت")
}

data class LiveConnectionInfo(
    val status: ConnectionStatus = ConnectionStatus.OFFLINE,
    val networkName: String = "غير معروف",
    val localIp: String = "—",
    val gatewayIp: String = "—",
    val dnsServers: List<String> = emptyList(),
    val linkSpeedMbps: Int = 0,
    val signalPercent: Int = 0,
    val downloadBps: Long = 0L,
    val uploadBps: Long = 0L,
    val phoneTodayBytes: Long = 0L,
    val phoneWeekBytes: Long = 0L,
    val phoneMonthBytes: Long = 0L
)

enum class DeviceType(val labelAr: String) {
    PHONE("هاتف ذكي"),
    LAPTOP("حاسوب محمول"),
    DESKTOP("حاسوب مكتبي"),
    TV("تلفاز ذكي"),
    TABLET("جهاز لوحي"),
    ROUTER("راوتر / نقطة وصول"),
    IOT("جهاز ذكي (IoT)"),
    UNKNOWN("جهاز غير مصنف")
}

enum class DeviceIconKey(val labelAr: String) {
    SMARTPHONE("هاتف"),
    LAPTOP("لابتوب"),
    DESKTOP("كمبيوتر"),
    TV("تلفاز"),
    TABLET("تابلت"),
    GAME_CONSOLE("ألعاب"),
    IOT("جهاز ذكي"),
    OTHER("جهاز آخر")
}

data class DeviceInfo(
    val id: String,
    val originalName: String,
    val customName: String,
    val ipAddress: String,
    val macAddress: String,
    val deviceType: DeviceType,
    val manufacturer: String,
    val isOnline: Boolean,
    val isKnown: Boolean,
    val isNew: Boolean,
    val isBlocked: Boolean,
    val isPaused: Boolean,
    val iconKey: DeviceIconKey,
    val customAvatarUri: String? = null,
    val totalBytes: Long,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val todayBytes: Long,
    val weekBytes: Long,
    val monthBytes: Long,
    val currentDownloadBps: Long,
    val currentUploadBps: Long,
    val lastSeenMillis: Long,
    val sourceLabelAr: String = "فحص الشبكة المحلية"
) {
    val displayName: String
        get() = customName.ifBlank { originalName.ifBlank { ipAddress } }
}

data class AppUsageStat(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val totalBytes: Long,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val todayBytes: Long,
    val weekBytes: Long,
    val monthBytes: Long,
    val percentageOfTotal: Float
)

enum class QuotaActionType(val labelAr: String, val descriptionAr: String) {
    NOTIFY("إرسال إشعار", "تنبيه فوري عند الوصول إلى النسبة المحددة"),
    THROTTLE("تقليل سرعة الإنترنت", "خفض السرعة تلقائيًا عبر الراوتر أو الوسيط المدعوم"),
    PAUSE("إيقاف الإنترنت مؤقتًا", "تعليق اتصال الجهاز مؤقتًا حتى تدخل المستخدم"),
    BLOCK_UNTIL_RESET("حظر حتى موعد التجديد", "منع الوصول للإنترنت حتى بداية الدورة الجديدة"),
    ALLOW_WITH_APPROVAL("السماح بعد موافقة المستخدم", "إرسال طلب موافقة فورية لفتح استخدام إضافي")
}

data class DeviceQuotaAllocation(
    val deviceId: String,
    val deviceName: String,
    val allocatedGb: Double,
    val usedBytes: Long,
    val resetDayOfMonth: Int,
    val actionAt50: QuotaActionType = QuotaActionType.NOTIFY,
    val actionAt80: QuotaActionType = QuotaActionType.NOTIFY,
    val actionAt90: QuotaActionType = QuotaActionType.THROTTLE,
    val actionAt100: QuotaActionType = QuotaActionType.PAUSE,
    val extraApprovedGb: Double = 0.0,
    val lastTriggeredThreshold: Int = 0
) {
    val effectiveQuotaBytes: Long
        get() = ((allocatedGb + extraApprovedGb) * 1024.0 * 1024.0 * 1024.0).toLong().coerceAtLeast(1L)

    val remainingBytes: Long
        get() = (effectiveQuotaBytes - usedBytes).coerceAtLeast(0L)

    val usagePercent: Float
        get() = ((usedBytes.toDouble() / effectiveQuotaBytes.toDouble()) * 100.0)
            .toFloat()
            .coerceIn(0f, 150f)
}

enum class NetworkPriority(val labelAr: String) {
    HIGH("أولوية عالية"),
    NORMAL("أولوية متوسطة"),
    LOW("أولوية منخفضة")
}

data class SpeedControlRule(
    val deviceId: String,
    val deviceName: String,
    val maxDownloadMbps: Float,
    val maxUploadMbps: Float,
    val priority: NetworkPriority,
    val isEnabled: Boolean,
    val isPaused: Boolean,
    val appliedToRouter: Boolean,
    val lastSyncedMillis: Long
)

enum class RouterVendor(val displayNameAr: String, val defaultPorts: List<Int>) {
    AUTO("اكتشاف تلقائي ذكي", listOf(80, 443, 8080, 49000)),
    OPENWRT("OpenWrt (LuCI / ubus)", listOf(80, 443)),
    MIKROTIK("MikroTik RouterOS", listOf(80, 443, 8728)),
    HUAWEI("Huawei HiLink / Harmony", listOf(80, 443)),
    TPLINK("TP-Link", listOf(80, 443)),
    ASUS("ASUS (AsusWRT)", listOf(80, 8443, 443)),
    ZTE("ZTE", listOf(80, 443)),
    TENDA("Tenda", listOf(80)),
    TR064_UPNP("TR-064 / UPnP عام", listOf(49000, 1900, 80)),
    GATEWAY_AGENT("وسيط الشبكة المحلي (NetControl Gateway)", listOf(8090, 8443))
}

enum class RouterProtocol(val labelAr: String) {
    UBUS_RPC("OpenWrt ubus JSON-RPC"),
    ROUTEROS_REST("MikroTik RouterOS REST API"),
    ROUTEROS_API("MikroTik Native API (TCP 8728)"),
    TR064_SOAP("TR-064 / SOAP XML"),
    HILINK_HTTP("Huawei HiLink XML API"),
    VENDOR_HTTP("واجهة الويب الرسمية للشركة المصنعة"),
    UPNP_IGD("UPnP Internet Gateway Device"),
    GATEWAY_REST("بروتوكول وسيط الشبكة المحلي (REST + nftables/tc)")
}

data class RouterCapabilities(
    val supportsDeviceList: Boolean = false,
    val supportsPerDeviceTraffic: Boolean = false,
    val supportsQuotaEnforcement: Boolean = false,
    val supportsSpeedLimiting: Boolean = false,
    val supportsDeviceBlocking: Boolean = false,
    val supportsConnectionRestart: Boolean = false,
    val supportsLiveBandwidth: Boolean = false,
    val supportedFeaturesAr: List<String> = emptyList(),
    val unsupportedFeaturesAr: List<String> = emptyList(),
    val technicalNoteAr: String = ""
)

data class RouterProfile(
    val id: Long = 1L,
    val vendor: RouterVendor = RouterVendor.AUTO,
    val protocol: RouterProtocol = RouterProtocol.VENDOR_HTTP,
    val hostIp: String = "192.168.1.1",
    val port: Int = 80,
    val useHttps: Boolean = false,
    val username: String = "admin",
    val manufacturer: String = "غير متصل بعد",
    val modelName: String = "—",
    val firmwareVersion: String = "—",
    val isConnected: Boolean = false,
    val lastCheckedMillis: Long = 0L,
    val statusMessageAr: String = "لم يتم الاتصال بالراوتر بعد. اضغط «اكتشاف تلقائي» أو أدخل بيانات الدخول.",
    val capabilities: RouterCapabilities = RouterCapabilities(),
    val gatewayAgentUrl: String = "",
    val gatewayAgentConnected: Boolean = false
)

data class RouterControlResult(
    val success: Boolean,
    val messageAr: String,
    val requiresGatewayAgent: Boolean = false
)

enum class UsageChartPeriod(val labelAr: String) {
    DAILY("يومي"),
    WEEKLY("أسبوعي"),
    MONTHLY("شهري")
}

data class UsageDataPoint(
    val labelAr: String,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val timestampMillis: Long
) {
    val totalBytes: Long get() = downloadBytes + uploadBytes
}

data class AnalyticsSummary(
    val dailyAverageBytes: Long = 0L,
    val predictedDaysRemaining: Int? = null,
    val predictedExhaustionLabelAr: String = "بيانات غير كافية للتوقع",
    val anomalyDetected: Boolean = false,
    val anomalyMessageAr: String = "لا يوجد ارتفاع غير طبيعي في الاستهلاك حاليًا.",
    val totalDownloadBytes: Long = 0L,
    val totalUploadBytes: Long = 0L
)

enum class NotificationType(val labelAr: String) {
    NEW_DEVICE("جهاز جديد"),
    UNKNOWN_DEVICE("جهاز غير معروف"),
    QUOTA_WARNING("تنبيه حصة"),
    QUOTA_EXCEEDED("نفاد الحصة"),
    INTERNET_DOWN("انقطاع الإنترنت"),
    USAGE_SPIKE("ارتفاع غير معتاد"),
    PLAN_EXPIRING("قرب انتهاء الباقة"),
    APPROVAL_REQUEST("طلب موافقة استخدام إضافي")
}

data class SmartNotification(
    val id: Long = 0L,
    val type: NotificationType,
    val titleAr: String,
    val messageAr: String,
    val timestampMillis: Long,
    val isRead: Boolean = false,
    val relatedDeviceId: String? = null,
    val requiresApproval: Boolean = false,
    val approvalHandled: Boolean = false
)

object Formatters {
    private val oneDec = DecimalFormat("0.0")
    private val twoDec = DecimalFormat("0.00")

    fun formatBytes(bytes: Long): String {
        val safe = bytes.coerceAtLeast(0L)
        val kb = safe / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> "${twoDec.format(gb)} جيجابايت"
            mb >= 1.0 -> "${oneDec.format(mb)} ميجابايت"
            kb >= 1.0 -> "${oneDec.format(kb)} كيلوبايت"
            else -> "$safe بايت"
        }
    }

    fun formatBytesCompact(bytes: Long): String {
        val safe = bytes.coerceAtLeast(0L)
        val kb = safe / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> "${twoDec.format(gb)} GB"
            mb >= 1.0 -> "${oneDec.format(mb)} MB"
            kb >= 1.0 -> "${oneDec.format(kb)} KB"
            else -> "$safe B"
        }
    }

    fun formatSpeedBps(bytesPerSec: Long): String {
        val bitsPerSec = bytesPerSec.coerceAtLeast(0L) * 8.0
        val kbps = bitsPerSec / 1000.0
        val mbps = kbps / 1000.0
        return when {
            mbps >= 1.0 -> "${oneDec.format(mbps)} ميجابت/ث"
            kbps >= 1.0 -> "${kbps.roundToInt()} كيلوبت/ث"
            else -> "${bitsPerSec.roundToInt()} بت/ث"
        }
    }

    fun bytesToGb(bytes: Long): Double = bytes.coerceAtLeast(0L) / (1024.0 * 1024.0 * 1024.0)
}
