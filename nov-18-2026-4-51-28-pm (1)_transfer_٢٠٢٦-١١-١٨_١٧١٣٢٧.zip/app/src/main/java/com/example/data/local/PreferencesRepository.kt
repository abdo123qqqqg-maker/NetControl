package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.security.CryptoManager
import com.example.domain.model.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.netControlDataStore by preferencesDataStore(name = "netcontrol_prefs")

data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val totalMonthlyPlanGb: Double = 200.0,
    val cycleResetDay: Int = 1,
    val pinEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val pinHash: String = "",
    val pinSalt: String = "",
    val notifyOnNewDevice: Boolean = true,
    val notifyOnInternetDown: Boolean = true,
    val notifyOnUsageSpike: Boolean = true
)

class PreferencesRepository(private val context: Context) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PLAN_GB = doublePreferencesKey("total_monthly_plan_gb")
        val RESET_DAY = intPreferencesKey("cycle_reset_day")
        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val NOTIFY_NEW_DEVICE = booleanPreferencesKey("notify_new_device")
        val NOTIFY_INTERNET_DOWN = booleanPreferencesKey("notify_internet_down")
        val NOTIFY_USAGE_SPIKE = booleanPreferencesKey("notify_usage_spike")
    }

    val settingsFlow: Flow<UserSettings> = context.netControlDataStore.data.map { prefs ->
        val themeStr = prefs[Keys.THEME_MODE] ?: AppThemeMode.SYSTEM.name
        val theme = runCatching { AppThemeMode.valueOf(themeStr) }.getOrDefault(AppThemeMode.SYSTEM)
        UserSettings(
            themeMode = theme,
            totalMonthlyPlanGb = prefs[Keys.PLAN_GB] ?: 200.0,
            cycleResetDay = (prefs[Keys.RESET_DAY] ?: 1).coerceIn(1, 28),
            pinEnabled = prefs[Keys.PIN_ENABLED] ?: false,
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            pinSalt = prefs[Keys.PIN_SALT] ?: "",
            notifyOnNewDevice = prefs[Keys.NOTIFY_NEW_DEVICE] ?: true,
            notifyOnInternetDown = prefs[Keys.NOTIFY_INTERNET_DOWN] ?: true,
            notifyOnUsageSpike = prefs[Keys.NOTIFY_USAGE_SPIKE] ?: true
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.netControlDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setPlanConfig(totalGb: Double, resetDay: Int) {
        context.netControlDataStore.edit {
            it[Keys.PLAN_GB] = totalGb.coerceAtLeast(1.0)
            it[Keys.RESET_DAY] = resetDay.coerceIn(1, 28)
        }
    }

    suspend fun enablePin(pin: String, enableBiometric: Boolean) {
        val salt = CryptoManager.generateSalt()
        val hash = CryptoManager.hashPin(pin, salt)
        context.netControlDataStore.edit {
            it[Keys.PIN_SALT] = salt
            it[Keys.PIN_HASH] = hash
            it[Keys.PIN_ENABLED] = true
            it[Keys.BIOMETRIC_ENABLED] = enableBiometric
        }
    }

    suspend fun disableSecurityLock() {
        context.netControlDataStore.edit {
            it[Keys.PIN_ENABLED] = false
            it[Keys.BIOMETRIC_ENABLED] = false
            it[Keys.PIN_HASH] = ""
            it[Keys.PIN_SALT] = ""
        }
    }

    suspend fun setNotificationPreferences(
        onNewDevice: Boolean,
        onInternetDown: Boolean,
        onUsageSpike: Boolean
    ) {
        context.netControlDataStore.edit {
            it[Keys.NOTIFY_NEW_DEVICE] = onNewDevice
            it[Keys.NOTIFY_INTERNET_DOWN] = onInternetDown
            it[Keys.NOTIFY_USAGE_SPIKE] = onUsageSpike
        }
    }

    suspend fun clearAllPreferences() {
        context.netControlDataStore.edit { it.clear() }
    }
}
