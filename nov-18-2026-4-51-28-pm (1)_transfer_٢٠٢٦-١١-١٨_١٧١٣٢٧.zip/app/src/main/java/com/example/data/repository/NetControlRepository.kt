package com.example.data.repository

import android.content.Context
import com.example.core.export.AlertNotifier
import com.example.core.network.AndroidTrafficEngine
import com.example.core.network.LanDiscoveryReport
import com.example.core.network.LanScannerEngine
import com.example.core.security.CryptoManager
import com.example.data.local.AppNotificationEntity
import com.example.data.local.NetControlDatabase
import com.example.data.local.PreferencesRepository
import com.example.data.local.QuotaAllocationEntity
import com.example.data.local.RouterProfileEntity
import com.example.data.local.SpeedRuleEntity
import com.example.data.local.TrackedDeviceEntity
import com.example.data.local.UsageSnapshotEntity
import com.example.data.local.UserSettings
import com.example.domain.model.AnalyticsSummary
import com.example.domain.model.AppUsageStat
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.DeviceIconKey
import com.example.domain.model.DeviceInfo
import com.example.domain.model.DeviceQuotaAllocation
import com.example.domain.model.DeviceType
import com.example.domain.model.Formatters
import com.example.domain.model.LiveConnectionInfo
import com.example.domain.model.NetworkPriority
import com.example.domain.model.NotificationType
import com.example.domain.model.QuotaActionType
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import com.example.domain.model.SmartNotification
import com.example.domain.model.SpeedControlRule
import com.example.domain.model.UsageChartPeriod
import com.example.domain.model.UsageDataPoint
import com.example.router.RouterRegistry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class NetControlRepository(context: Context) {

    private val db = NetControlDatabase.getInstance(context)
    private val routerDao = db.routerProfileDao()
    private val deviceDao = db.trackedDeviceDao()
    private val quotaDao = db.quotaAllocationDao()
    private val speedRuleDao = db.speedRuleDao()
    private val snapshotDao = db.usageSnapshotDao()
    private val notificationDao = db.appNotificationDao()

    val preferences = PreferencesRepository(context)
    val trafficEngine = AndroidTrafficEngine(context)
    val lanScanner = LanScannerEngine()
    val routerRegistry = RouterRegistry()
    val alertNotifier = AlertNotifier(context)

    private val _liveConnection = MutableStateFlow(LiveConnectionInfo())
    val liveConnection: StateFlow<LiveConnectionInfo> = _liveConnection.asStateFlow()

    private val _appUsage = MutableStateFlow<List<AppUsageStat>>(emptyList())
    val appUsage: StateFlow<List<AppUsageStat>> = _appUsage.asStateFlow()

    private val _hasUsagePermission = MutableStateFlow(trafficEngine.hasUsageStatsPermission())
    val hasUsagePermission: StateFlow<Boolean> = _hasUsagePermission.asStateFlow()

    private val _lanScanNote = MutableStateFlow("اضغط «فحص الشبكة» لاكتشاف الأجهزة المتصلة بالراوتر.")
    val lanScanNote: StateFlow<String> = _lanScanNote.asStateFlow()

    private var previousStatus: ConnectionStatus? = null

    val userSettings: Flow<UserSettings> = preferences.settingsFlow

    val routerProfile: Flow<RouterProfile> = routerDao.observeRouterProfile().map { entity ->
        if (entity == null) {
            RouterProfile()
        } else {
            val vendor = runCatching { RouterVendor.valueOf(entity.vendorName) }.getOrDefault(RouterVendor.AUTO)
            val protocol = runCatching { RouterProtocol.valueOf(entity.protocolName) }.getOrDefault(RouterProtocol.VENDOR_HTTP)
            val caps: RouterCapabilities = routerRegistry.capabilitiesFor(vendor)
            RouterProfile(
                id = entity.id,
                vendor = vendor,
                protocol = protocol,
                hostIp = entity.hostIp,
                port = entity.port,
                useHttps = entity.useHttps,
                username = entity.username,
                manufacturer = entity.manufacturer,
                modelName = entity.modelName,
                firmwareVersion = entity.firmwareVersion,
                isConnected = entity.isConnected,
                lastCheckedMillis = entity.lastCheckedMillis,
                statusMessageAr = entity.statusMessageAr,
                capabilities = caps,
                gatewayAgentUrl = entity.gatewayAgentUrl,
                gatewayAgentConnected = entity.gatewayAgentConnected
            )
        }
    }

    val devices: Flow<List<DeviceInfo>> = deviceDao.observeDevices().map { list ->
        list.map { it.toDomain() }
    }

    val quotas: Flow<List<DeviceQuotaAllocation>> = quotaDao.observeQuotas().map { list ->
        list.map { it.toDomain() }
    }

    val speedRules: Flow<List<SpeedControlRule>> = speedRuleDao.observeRules().map { list ->
        list.map { it.toDomain() }
    }

    val notifications: Flow<List<SmartNotification>> = notificationDao.observeNotifications().map { list ->
        list.map { it.toDomain() }
    }

    val usageSnapshots: Flow<List<UsageSnapshotEntity>> = snapshotDao.observeAll()

    suspend fun refreshLiveTelemetry(settings: UserSettings) {
        val permGranted = trafficEngine.hasUsageStatsPermission()
        _hasUsagePermission.value = permGranted

        val baseLive = trafficEngine.sampleLiveConnection()
        val totals = if (permGranted) trafficEngine.queryPhoneDataTotals() else Triple(0L, 0L, 0L)

        val enrichedLive = baseLive.copy(
            phoneTodayBytes = totals.first,
            phoneWeekBytes = totals.second,
            phoneMonthBytes = totals.third
        )
        _liveConnection.value = enrichedLive

        if (previousStatus != null && previousStatus != ConnectionStatus.OFFLINE && baseLive.status == ConnectionStatus.OFFLINE) {
            if (settings.notifyOnInternetDown) {
                recordNotification(
                    type = NotificationType.INTERNET_DOWN,
                    titleAr = "انقطاع اتصال الإنترنت",
                    messageAr = "تم رصد انقطاع في اتصال الإنترنت عن الجهاز الحالي."
                )
            }
        }
        previousStatus = baseLive.status

        if (permGranted) {
            val apps = trafficEngine.queryInstalledAppsUsage()
            _appUsage.value = apps
            val dlTotal = apps.sumOf { it.downloadBytes }
            val ulTotal = apps.sumOf { it.uploadBytes }
            val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            snapshotDao.insert(
                UsageSnapshotEntity(
                    id = snapshotDao.getByDateKey(todayKey)?.id ?: 0L,
                    timestampMillis = System.currentTimeMillis(),
                    dateKey = todayKey,
                    downloadBytes = dlTotal,
                    uploadBytes = ulTotal,
                    source = "NetworkStatsManager"
                )
            )
            // Update local phone entry in tracked devices with real Android usage
            if (baseLive.localIp != "—") {
                val existing = deviceDao.getAllOnce().firstOrNull { it.ipAddress == baseLive.localIp }
                if (existing != null) {
                    deviceDao.upsert(
                        existing.copy(
                            isOnline = true,
                            todayBytes = totals.first,
                            weekBytes = totals.second,
                            monthBytes = totals.third,
                            totalBytes = totals.third,
                            downloadBytes = dlTotal,
                            uploadBytes = ulTotal,
                            currentDownloadBps = enrichedLive.downloadBps,
                            currentUploadBps = enrichedLive.uploadBps,
                            lastSeenMillis = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    suspend fun scanLanAndSyncRouter(settings: UserSettings): LanDiscoveryReport {
        val live = _liveConnection.value
        val lanReport = lanScanner.scanLocalNetwork(live.localIp, live.gatewayIp)
        _lanScanNote.value = lanReport.noteAr

        val merged = mutableListOf<DeviceInfo>()
        merged.addAll(lanReport.devices)

        // Also pull devices from connected router if any
        val routerEntity = routerDao.getRouterProfileOnce()
        if (routerEntity != null && routerEntity.isConnected) {
            val profile = routerEntity.toDomain(routerRegistry)
            val pass = CryptoManager.decrypt(routerEntity.encryptedPassword)
            val routerDevices = routerRegistry.adapterFor(profile.vendor).fetchDevices(profile, pass).getOrDefault(emptyList())
            for (rd in routerDevices) {
                val idx = merged.indexOfFirst {
                    (rd.macAddress != "—" && it.macAddress.equals(rd.macAddress, ignoreCase = true)) ||
                        (rd.ipAddress != "—" && it.ipAddress == rd.ipAddress)
                }
                if (idx >= 0) {
                    val prev = merged[idx]
                    merged[idx] = rd.copy(
                        id = prev.id,
                        todayBytes = maxOf(prev.todayBytes, rd.todayBytes),
                        weekBytes = maxOf(prev.weekBytes, rd.weekBytes),
                        monthBytes = maxOf(prev.monthBytes, rd.monthBytes),
                        totalBytes = maxOf(prev.totalBytes, rd.totalBytes)
                    )
                } else {
                    merged.add(rd)
                }
            }
        }

        persistScannedDevices(merged, settings)
        evaluateQuotasAndAlerts(settings)
        return lanReport
    }

    private suspend fun persistScannedDevices(scanned: List<DeviceInfo>, settings: UserSettings) {
        val now = System.currentTimeMillis()
        val existingList = deviceDao.getAllOnce()
        val existingById = existingList.associateBy { it.id }.toMutableMap()
        val seenIds = mutableSetOf<String>()

        val toSave = mutableListOf<TrackedDeviceEntity>()
        for (item in scanned) {
            val existing = existingById[item.id]
                ?: existingList.firstOrNull { it.ipAddress == item.ipAddress && item.ipAddress != "—" }

            if (existing == null) {
                seenIds.add(item.id)
                toSave.add(item.toEntity())
                if (settings.notifyOnNewDevice && item.deviceType != DeviceType.ROUTER && item.sourceLabelAr != "الجهاز الحالي") {
                    recordNotification(
                        type = NotificationType.NEW_DEVICE,
                        titleAr = "اتصال جهاز جديد بالشبكة",
                        messageAr = "تم رصد ${item.displayName} (${item.ipAddress}) لأول مرة.",
                        relatedDeviceId = item.id
                    )
                }
            } else {
                seenIds.add(existing.id)
                toSave.add(
                    existing.copy(
                        ipAddress = item.ipAddress,
                        macAddress = if (item.macAddress != "—") item.macAddress else existing.macAddress,
                        manufacturer = if (item.manufacturer != "غير معروف") item.manufacturer else existing.manufacturer,
                        isOnline = item.isOnline,
                        isNew = false,
                        totalBytes = maxOf(existing.totalBytes, item.totalBytes),
                        downloadBytes = maxOf(existing.downloadBytes, item.downloadBytes),
                        uploadBytes = maxOf(existing.uploadBytes, item.uploadBytes),
                        todayBytes = maxOf(existing.todayBytes, item.todayBytes),
                        weekBytes = maxOf(existing.weekBytes, item.weekBytes),
                        monthBytes = maxOf(existing.monthBytes, item.monthBytes),
                        currentDownloadBps = item.currentDownloadBps,
                        currentUploadBps = item.currentUploadBps,
                        lastSeenMillis = now,
                        sourceLabelAr = item.sourceLabelAr
                    )
                )
            }
        }

        // Mark previously known devices that didn't appear as offline (previously connected)
        for (old in existingList) {
            if (old.id !in seenIds) {
                toSave.add(old.copy(isOnline = false, isNew = false, currentDownloadBps = 0L, currentUploadBps = 0L))
            }
        }

        deviceDao.upsertAll(toSave)
    }

    suspend fun connectRouter(
        vendor: RouterVendor,
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String,
        gatewayUrl: String,
        gatewayToken: String,
        settings: UserSettings
    ): Result<RouterProfile> {
        val result = routerRegistry.connect(vendor, hostIp, port, useHttps, username, password)
        return result.map { snapshot ->
            val profile = snapshot.profile.copy(
                gatewayAgentUrl = gatewayUrl.trim(),
                gatewayAgentConnected = gatewayUrl.isNotBlank() && vendor == RouterVendor.GATEWAY_AGENT
            )
            routerDao.upsert(
                RouterProfileEntity(
                    id = 1L,
                    vendorName = profile.vendor.name,
                    protocolName = profile.protocol.name,
                    hostIp = profile.hostIp,
                    port = profile.port,
                    useHttps = profile.useHttps,
                    username = profile.username,
                    encryptedPassword = CryptoManager.encrypt(password),
                    manufacturer = profile.manufacturer,
                    modelName = profile.modelName,
                    firmwareVersion = profile.firmwareVersion,
                    isConnected = profile.isConnected,
                    lastCheckedMillis = profile.lastCheckedMillis,
                    statusMessageAr = profile.statusMessageAr,
                    gatewayAgentUrl = profile.gatewayAgentUrl,
                    encryptedGatewayToken = CryptoManager.encrypt(gatewayToken),
                    gatewayAgentConnected = profile.gatewayAgentConnected
                )
            )
            if (snapshot.devices.isNotEmpty()) {
                persistScannedDevices(snapshot.devices, settings)
            }
            profile
        }
    }

    suspend fun autoDetectRouterVendor(hostIp: String): RouterVendor {
        return routerRegistry.autoDetectVendor(hostIp)
    }

    suspend fun updateDeviceCustomization(
        deviceId: String,
        customName: String,
        iconKey: DeviceIconKey,
        customAvatarUri: String?,
        isKnown: Boolean
    ) {
        val entity = deviceDao.getAllOnce().firstOrNull { it.id == deviceId } ?: return
        deviceDao.upsert(
            entity.copy(
                customName = customName.trim(),
                iconKeyName = iconKey.name,
                customAvatarUri = customAvatarUri,
                isKnown = isKnown,
                isNew = false
            )
        )
    }

    suspend fun setDeviceBlocked(device: DeviceInfo, blocked: Boolean): RouterControlResult {
        val routerEntity = routerDao.getRouterProfileOnce()
            ?: return RouterControlResult(false, "لم يتم ربط الراوتر أو وسيط الشبكة بعد.", requiresGatewayAgent = true)
        val profile = routerEntity.toDomain(routerRegistry)
        val pass = CryptoManager.decrypt(routerEntity.encryptedPassword)
        val adapter = routerRegistry.resolveControlAdapter(profile)
        val res = adapter.setDeviceBlocked(profile, pass, device, blocked)
        if (res.success) {
            deviceDao.getAllOnce().firstOrNull { it.id == device.id }?.let { entity ->
                deviceDao.upsert(entity.copy(isBlocked = blocked, isPaused = blocked))
            }
        }
        return res
    }

    suspend fun restartRouterConnection(): RouterControlResult {
        val routerEntity = routerDao.getRouterProfileOnce()
            ?: return RouterControlResult(false, "لا يوجد راوتر متصل حاليًا.")
        val profile = routerEntity.toDomain(routerRegistry)
        val pass = CryptoManager.decrypt(routerEntity.encryptedPassword)
        return routerRegistry.resolveControlAdapter(profile).restartWanConnection(profile, pass)
    }

    suspend fun saveQuotaAllocation(allocation: DeviceQuotaAllocation) {
        quotaDao.upsert(
            QuotaAllocationEntity(
                deviceId = allocation.deviceId,
                deviceName = allocation.deviceName,
                allocatedGb = allocation.allocatedGb,
                usedBytes = allocation.usedBytes,
                resetDayOfMonth = allocation.resetDayOfMonth,
                actionAt50 = allocation.actionAt50.name,
                actionAt80 = allocation.actionAt80.name,
                actionAt90 = allocation.actionAt90.name,
                actionAt100 = allocation.actionAt100.name,
                extraApprovedGb = allocation.extraApprovedGb,
                lastTriggeredThreshold = allocation.lastTriggeredThreshold
            )
        )
    }

    suspend fun deleteQuotaAllocation(deviceId: String) {
        quotaDao.deleteByDeviceId(deviceId)
    }

    suspend fun applySpeedRule(rule: SpeedControlRule, device: DeviceInfo?): RouterControlResult {
        val routerEntity = routerDao.getRouterProfileOnce()
        val res = if (routerEntity != null && routerEntity.isConnected && device != null) {
            val profile = routerEntity.toDomain(routerRegistry)
            val pass = CryptoManager.decrypt(routerEntity.encryptedPassword)
            val adapter = routerRegistry.resolveControlAdapter(profile)
            if (rule.isPaused || !rule.isEnabled) {
                adapter.clearDeviceSpeedLimit(profile, pass, device)
            } else {
                adapter.setDeviceSpeedLimit(profile, pass, device, rule.maxDownloadMbps, rule.maxUploadMbps)
            }
        } else {
            RouterControlResult(
                success = false,
                messageAr = "تم حفظ قاعدة السرعة محليًا. اربط راوترًا داعمًا (OpenWrt / MikroTik) أو وسيط الشبكة المحلي لتنفيذها فعليًا على الشبكة.",
                requiresGatewayAgent = true
            )
        }

        speedRuleDao.upsert(
            SpeedRuleEntity(
                deviceId = rule.deviceId,
                deviceName = rule.deviceName,
                maxDownloadMbps = rule.maxDownloadMbps,
                maxUploadMbps = rule.maxUploadMbps,
                priorityName = rule.priority.name,
                isEnabled = rule.isEnabled,
                isPaused = rule.isPaused,
                appliedToRouter = res.success,
                lastSyncedMillis = System.currentTimeMillis()
            )
        )
        return res
    }

    suspend fun evaluateQuotasAndAlerts(settings: UserSettings) {
        val devicesMap = deviceDao.getAllOnce().associateBy { it.id }
        val quotas = quotaDao.getAllOnce()
        for (q in quotas) {
            val dev = devicesMap[q.deviceId]
            val currentUsed = dev?.monthBytes ?: q.usedBytes
            val domain = q.copy(usedBytes = currentUsed).toDomain()
            val pct = domain.usagePercent.toInt()
            val thresholds = listOf(100, 90, 80, 50)
            val hit = thresholds.firstOrNull { pct >= it && it > q.lastTriggeredThreshold }
            if (hit != null) {
                val action = when (hit) {
                    100 -> domain.actionAt100
                    90 -> domain.actionAt90
                    80 -> domain.actionAt80
                    else -> domain.actionAt50
                }
                val title = "وصول ${domain.deviceName} إلى $hit% من الحصة"
                val msg = "استهلك الجهاز ${Formatters.formatBytes(currentUsed)} من أصل ${domain.allocatedGb} جيجابايت. الإجراء المحدد: ${action.labelAr}."

                recordNotification(
                    type = if (action == QuotaActionType.ALLOW_WITH_APPROVAL) NotificationType.APPROVAL_REQUEST else if (hit >= 100) NotificationType.QUOTA_EXCEEDED else NotificationType.QUOTA_WARNING,
                    titleAr = title,
                    messageAr = msg,
                    relatedDeviceId = domain.deviceId,
                    requiresApproval = action == QuotaActionType.ALLOW_WITH_APPROVAL
                )

                // Execute router control action if supported
                if (dev != null) {
                    val domainDev = dev.toDomain()
                    when (action) {
                        QuotaActionType.THROTTLE -> {
                            applySpeedRule(
                                SpeedControlRule(
                                    deviceId = domainDev.id,
                                    deviceName = domainDev.displayName,
                                    maxDownloadMbps = 2f,
                                    maxUploadMbps = 1f,
                                    priority = NetworkPriority.LOW,
                                    isEnabled = true,
                                    isPaused = false,
                                    appliedToRouter = false,
                                    lastSyncedMillis = System.currentTimeMillis()
                                ),
                                domainDev
                            )
                        }
                        QuotaActionType.PAUSE, QuotaActionType.BLOCK_UNTIL_RESET -> {
                            setDeviceBlocked(domainDev, true)
                        }
                        else -> Unit
                    }
                }
                quotaDao.upsert(q.copy(usedBytes = currentUsed, lastTriggeredThreshold = hit))
            } else if (dev != null && dev.monthBytes != q.usedBytes) {
                quotaDao.upsert(q.copy(usedBytes = dev.monthBytes))
            }
        }
    }

    suspend fun approveExtraQuota(notificationId: Long, deviceId: String, extraGb: Double) {
        val q = quotaDao.getAllOnce().firstOrNull { it.deviceId == deviceId }
        if (q != null) {
            quotaDao.upsert(q.copy(extraApprovedGb = q.extraApprovedGb + extraGb))
        }
        deviceDao.getAllOnce().firstOrNull { it.id == deviceId }?.let { dev ->
            if (dev.isBlocked) setDeviceBlocked(dev.toDomain(), false)
        }
        notificationDao.markApprovalHandled(notificationId)
    }

    suspend fun markAllNotificationsRead() {
        notificationDao.markAllRead()
    }

    suspend fun recordNotification(
        type: NotificationType,
        titleAr: String,
        messageAr: String,
        relatedDeviceId: String? = null,
        requiresApproval: Boolean = false
    ) {
        val id = notificationDao.insert(
            AppNotificationEntity(
                typeName = type.name,
                titleAr = titleAr,
                messageAr = messageAr,
                timestampMillis = System.currentTimeMillis(),
                isRead = false,
                relatedDeviceId = relatedDeviceId,
                requiresApproval = requiresApproval
            )
        )
        alertNotifier.postAlert(id.toInt(), titleAr, messageAr)
    }

    fun buildChartSeries(
        snapshots: List<UsageSnapshotEntity>,
        period: UsageChartPeriod,
        live: LiveConnectionInfo
    ): List<UsageDataPoint> {
        val now = System.currentTimeMillis()
        if (snapshots.isEmpty()) {
            // Return real single current point (zero fabrication!)
            return listOf(
                UsageDataPoint(
                    labelAr = "اليوم",
                    downloadBytes = live.phoneTodayBytes,
                    uploadBytes = 0L,
                    timestampMillis = now
                )
            )
        }
        return when (period) {
            UsageChartPeriod.DAILY -> snapshots.takeLast(7).map {
                UsageDataPoint(
                    labelAr = it.dateKey.takeLast(5),
                    downloadBytes = it.downloadBytes,
                    uploadBytes = it.uploadBytes,
                    timestampMillis = it.timestampMillis
                )
            }
            UsageChartPeriod.WEEKLY -> snapshots.takeLast(28).chunked(7).mapIndexed { index, chunk ->
                UsageDataPoint(
                    labelAr = "أسبوع ${index + 1}",
                    downloadBytes = chunk.sumOf { it.downloadBytes },
                    uploadBytes = chunk.sumOf { it.uploadBytes },
                    timestampMillis = chunk.last().timestampMillis
                )
            }
            UsageChartPeriod.MONTHLY -> snapshots.groupBy { it.dateKey.take(7) }.entries.toList().takeLast(6).map { (ym, list) ->
                UsageDataPoint(
                    labelAr = ym,
                    downloadBytes = list.maxOfOrNull { it.downloadBytes } ?: 0L,
                    uploadBytes = list.maxOfOrNull { it.uploadBytes } ?: 0L,
                    timestampMillis = list.last().timestampMillis
                )
            }
        }
    }

    fun computeAnalyticsSummary(
        snapshots: List<UsageSnapshotEntity>,
        live: LiveConnectionInfo,
        apps: List<AppUsageStat>,
        settings: UserSettings
    ): AnalyticsSummary {
        val totalDl = apps.sumOf { it.downloadBytes }
        val totalUl = apps.sumOf { it.uploadBytes }
        val daysInMonthElapsed = Calendar.getInstance().get(Calendar.DAY_OF_MONTH).coerceAtLeast(1)
        val monthTotal = live.phoneMonthBytes.coerceAtLeast(totalDl + totalUl)
        val dailyAvg = monthTotal / daysInMonthElapsed

        val planBytes = (settings.totalMonthlyPlanGb * 1024.0 * 1024.0 * 1024.0).toLong()
        val remainingBytes = (planBytes - monthTotal).coerceAtLeast(0L)
        val predictedDays = if (dailyAvg > 0L) (remainingBytes / dailyAvg).toInt() else null
        val predictedLabel = when {
            remainingBytes <= 0L -> "تم استهلاك كامل الباقة"
            predictedDays == null -> "بانتظار تسجيل استهلاك فعلي للتوقع"
            else -> "متبقٍ تقريبًا $predictedDays يومًا بمعدل الاستهلاك الحالي"
        }

        val anomaly = dailyAvg > 0L && live.phoneTodayBytes > (dailyAvg * 2.2)
        val anomalyMsg = if (anomaly) {
            "ارتفاع غير معتاد: استهلاك اليوم (${Formatters.formatBytes(live.phoneTodayBytes)}) يتجاوز ضعف المتوسط اليومي (${Formatters.formatBytes(dailyAvg)})."
        } else {
            "معدل الاستهلاك اليومي ضمن النطاق الطبيعي."
        }

        return AnalyticsSummary(
            dailyAverageBytes = dailyAvg,
            predictedDaysRemaining = predictedDays,
            predictedExhaustionLabelAr = predictedLabel,
            anomalyDetected = anomaly,
            anomalyMessageAr = anomalyMsg,
            totalDownloadBytes = totalDl,
            totalUploadBytes = totalUl
        )
    }

    suspend fun clearAllUserData() {
        routerDao.clearAll()
        deviceDao.clearAll()
        quotaDao.clearAll()
        speedRuleDao.clearAll()
        snapshotDao.clearAll()
        notificationDao.clearAll()
        preferences.clearAllPreferences()
    }
}

private fun RouterProfileEntity.toDomain(registry: RouterRegistry): RouterProfile {
    val vendor = runCatching { RouterVendor.valueOf(vendorName) }.getOrDefault(RouterVendor.AUTO)
    val protocol = runCatching { RouterProtocol.valueOf(protocolName) }.getOrDefault(RouterProtocol.VENDOR_HTTP)
    return RouterProfile(
        id = id,
        vendor = vendor,
        protocol = protocol,
        hostIp = hostIp,
        port = port,
        useHttps = useHttps,
        username = username,
        manufacturer = manufacturer,
        modelName = modelName,
        firmwareVersion = firmwareVersion,
        isConnected = isConnected,
        lastCheckedMillis = lastCheckedMillis,
        statusMessageAr = statusMessageAr,
        capabilities = registry.capabilitiesFor(vendor),
        gatewayAgentUrl = gatewayAgentUrl,
        gatewayAgentConnected = gatewayAgentConnected
    )
}

private fun TrackedDeviceEntity.toDomain() = DeviceInfo(
    id = id,
    originalName = originalName,
    customName = customName,
    ipAddress = ipAddress,
    macAddress = macAddress,
    deviceType = runCatching { DeviceType.valueOf(deviceTypeName) }.getOrDefault(DeviceType.UNKNOWN),
    manufacturer = manufacturer,
    isOnline = isOnline,
    isKnown = isKnown,
    isNew = isNew,
    isBlocked = isBlocked,
    isPaused = isPaused,
    iconKey = runCatching { DeviceIconKey.valueOf(iconKeyName) }.getOrDefault(DeviceIconKey.OTHER),
    customAvatarUri = customAvatarUri,
    totalBytes = totalBytes,
    downloadBytes = downloadBytes,
    uploadBytes = uploadBytes,
    todayBytes = todayBytes,
    weekBytes = weekBytes,
    monthBytes = monthBytes,
    currentDownloadBps = currentDownloadBps,
    currentUploadBps = currentUploadBps,
    lastSeenMillis = lastSeenMillis,
    sourceLabelAr = sourceLabelAr
)

private fun DeviceInfo.toEntity() = TrackedDeviceEntity(
    id = id,
    originalName = originalName,
    customName = customName,
    ipAddress = ipAddress,
    macAddress = macAddress,
    deviceTypeName = deviceType.name,
    manufacturer = manufacturer,
    isOnline = isOnline,
    isKnown = isKnown,
    isNew = isNew,
    isBlocked = isBlocked,
    isPaused = isPaused,
    iconKeyName = iconKey.name,
    customAvatarUri = customAvatarUri,
    totalBytes = totalBytes,
    downloadBytes = downloadBytes,
    uploadBytes = uploadBytes,
    todayBytes = todayBytes,
    weekBytes = weekBytes,
    monthBytes = monthBytes,
    currentDownloadBps = currentDownloadBps,
    currentUploadBps = currentUploadBps,
    lastSeenMillis = lastSeenMillis,
    sourceLabelAr = sourceLabelAr
)

private fun QuotaAllocationEntity.toDomain() = DeviceQuotaAllocation(
    deviceId = deviceId,
    deviceName = deviceName,
    allocatedGb = allocatedGb,
    usedBytes = usedBytes,
    resetDayOfMonth = resetDayOfMonth,
    actionAt50 = runCatching { QuotaActionType.valueOf(actionAt50) }.getOrDefault(QuotaActionType.NOTIFY),
    actionAt80 = runCatching { QuotaActionType.valueOf(actionAt80) }.getOrDefault(QuotaActionType.NOTIFY),
    actionAt90 = runCatching { QuotaActionType.valueOf(actionAt90) }.getOrDefault(QuotaActionType.THROTTLE),
    actionAt100 = runCatching { QuotaActionType.valueOf(actionAt100) }.getOrDefault(QuotaActionType.PAUSE),
    extraApprovedGb = extraApprovedGb,
    lastTriggeredThreshold = lastTriggeredThreshold
)

private fun SpeedRuleEntity.toDomain() = SpeedControlRule(
    deviceId = deviceId,
    deviceName = deviceName,
    maxDownloadMbps = maxDownloadMbps,
    maxUploadMbps = maxUploadMbps,
    priority = runCatching { NetworkPriority.valueOf(priorityName) }.getOrDefault(NetworkPriority.NORMAL),
    isEnabled = isEnabled,
    isPaused = isPaused,
    appliedToRouter = appliedToRouter,
    lastSyncedMillis = lastSyncedMillis
)

private fun AppNotificationEntity.toDomain() = SmartNotification(
    id = id,
    type = runCatching { NotificationType.valueOf(typeName) }.getOrDefault(NotificationType.QUOTA_WARNING),
    titleAr = titleAr,
    messageAr = messageAr,
    timestampMillis = timestampMillis,
    isRead = isRead,
    relatedDeviceId = relatedDeviceId,
    requiresApproval = requiresApproval,
    approvalHandled = approvalHandled
)
