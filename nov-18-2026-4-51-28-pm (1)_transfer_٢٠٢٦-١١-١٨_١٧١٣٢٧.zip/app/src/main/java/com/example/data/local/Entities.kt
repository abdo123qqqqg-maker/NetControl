package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "router_profiles")
data class RouterProfileEntity(
    @PrimaryKey val id: Long = 1L,
    val vendorName: String,
    val protocolName: String,
    val hostIp: String,
    val port: Int,
    val useHttps: Boolean,
    val username: String,
    val encryptedPassword: String,
    val manufacturer: String,
    val modelName: String,
    val firmwareVersion: String,
    val isConnected: Boolean,
    val lastCheckedMillis: Long,
    val statusMessageAr: String,
    val gatewayAgentUrl: String = "",
    val encryptedGatewayToken: String = "",
    val gatewayAgentConnected: Boolean = false
)

@Entity(tableName = "tracked_devices")
data class TrackedDeviceEntity(
    @PrimaryKey val id: String,
    val originalName: String,
    val customName: String,
    val ipAddress: String,
    val macAddress: String,
    val deviceTypeName: String,
    val manufacturer: String,
    val isOnline: Boolean,
    val isKnown: Boolean,
    val isNew: Boolean,
    val isBlocked: Boolean,
    val isPaused: Boolean,
    val iconKeyName: String,
    val customAvatarUri: String? = null,
    val totalBytes: Long,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val todayBytes: Long,
    val weekBytes: Long,
    val monthBytes: Long,
    val currentDownloadBps: Long,
    val currentUploadBps: Long,
    val lastSeenMillis: Long,
    val sourceLabelAr: String
)

@Entity(tableName = "quota_allocations")
data class QuotaAllocationEntity(
    @PrimaryKey val deviceId: String,
    val deviceName: String,
    val allocatedGb: Double,
    val usedBytes: Long,
    val resetDayOfMonth: Int,
    val actionAt50: String,
    val actionAt80: String,
    val actionAt90: String,
    val actionAt100: String,
    val extraApprovedGb: Double = 0.0,
    val lastTriggeredThreshold: Int = 0
)

@Entity(tableName = "speed_rules")
data class SpeedRuleEntity(
    @PrimaryKey val deviceId: String,
    val deviceName: String,
    val maxDownloadMbps: Float,
    val maxUploadMbps: Float,
    val priorityName: String,
    val isEnabled: Boolean,
    val isPaused: Boolean,
    val appliedToRouter: Boolean,
    val lastSyncedMillis: Long
)

@Entity(tableName = "usage_snapshots")
data class UsageSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestampMillis: Long,
    val dateKey: String,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val source: String
)

@Entity(tableName = "app_notifications")
data class AppNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val typeName: String,
    val titleAr: String,
    val messageAr: String,
    val timestampMillis: Long,
    val isRead: Boolean = false,
    val relatedDeviceId: String? = null,
    val requiresApproval: Boolean = false,
    val approvalHandled: Boolean = false
)
