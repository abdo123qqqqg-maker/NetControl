package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        RouterProfileEntity::class,
        TrackedDeviceEntity::class,
        QuotaAllocationEntity::class,
        SpeedRuleEntity::class,
        UsageSnapshotEntity::class,
        AppNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NetControlDatabase : RoomDatabase() {
    abstract fun routerProfileDao(): RouterProfileDao
    abstract fun trackedDeviceDao(): TrackedDeviceDao
    abstract fun quotaAllocationDao(): QuotaAllocationDao
    abstract fun speedRuleDao(): SpeedRuleDao
    abstract fun usageSnapshotDao(): UsageSnapshotDao
    abstract fun appNotificationDao(): AppNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: NetControlDatabase? = null

        fun getInstance(context: Context): NetControlDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NetControlDatabase::class.java,
                    "netcontrol_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
