package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RouterProfileDao {
    @Query("SELECT * FROM router_profiles WHERE id = 1 LIMIT 1")
    fun observeRouterProfile(): Flow<RouterProfileEntity?>

    @Query("SELECT * FROM router_profiles WHERE id = 1 LIMIT 1")
    suspend fun getRouterProfileOnce(): RouterProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: RouterProfileEntity)

    @Query("DELETE FROM router_profiles")
    suspend fun clearAll()
}

@Dao
interface TrackedDeviceDao {
    @Query("SELECT * FROM tracked_devices ORDER BY isOnline DESC, monthBytes DESC")
    fun observeDevices(): Flow<List<TrackedDeviceEntity>>

    @Query("SELECT * FROM tracked_devices WHERE id = :id LIMIT 1")
    fun observeDevice(id: String): Flow<TrackedDeviceEntity?>

    @Query("SELECT * FROM tracked_devices")
    suspend fun getAllOnce(): List<TrackedDeviceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(devices: List<TrackedDeviceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(device: TrackedDeviceEntity)

    @Query("DELETE FROM tracked_devices")
    suspend fun clearAll()
}

@Dao
interface QuotaAllocationDao {
    @Query("SELECT * FROM quota_allocations ORDER BY allocatedGb DESC")
    fun observeQuotas(): Flow<List<QuotaAllocationEntity>>

    @Query("SELECT * FROM quota_allocations")
    suspend fun getAllOnce(): List<QuotaAllocationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(quota: QuotaAllocationEntity)

    @Query("DELETE FROM quota_allocations WHERE deviceId = :deviceId")
    suspend fun deleteByDeviceId(deviceId: String)

    @Query("DELETE FROM quota_allocations")
    suspend fun clearAll()
}

@Dao
interface SpeedRuleDao {
    @Query("SELECT * FROM speed_rules")
    fun observeRules(): Flow<List<SpeedRuleEntity>>

    @Query("SELECT * FROM speed_rules")
    suspend fun getAllOnce(): List<SpeedRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: SpeedRuleEntity)

    @Query("DELETE FROM speed_rules WHERE deviceId = :deviceId")
    suspend fun deleteByDeviceId(deviceId: String)

    @Query("DELETE FROM speed_rules")
    suspend fun clearAll()
}

@Dao
interface UsageSnapshotDao {
    @Query("SELECT * FROM usage_snapshots ORDER BY timestampMillis ASC")
    fun observeAll(): Flow<List<UsageSnapshotEntity>>

    @Query("SELECT * FROM usage_snapshots WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getByDateKey(dateKey: String): UsageSnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(snapshot: UsageSnapshotEntity)

    @Query("DELETE FROM usage_snapshots")
    suspend fun clearAll()
}

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestampMillis DESC")
    fun observeNotifications(): Flow<List<AppNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: AppNotificationEntity): Long

    @Query("UPDATE app_notifications SET isRead = 1")
    suspend fun markAllRead()

    @Query("UPDATE app_notifications SET isRead = 1, approvalHandled = 1 WHERE id = :id")
    suspend fun markApprovalHandled(id: Long)

    @Query("DELETE FROM app_notifications")
    suspend fun clearAll()
}
