package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.model.DeviceInfo
import com.example.domain.model.DeviceQuotaAllocation
import com.example.domain.model.Formatters
import com.example.domain.model.QuotaActionType
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InfoBannerCard
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.NetControlUiState
import java.util.Locale

@Composable
fun QuotaDistributionScreen(
    state: NetControlUiState,
    onSavePlanConfig: (Double, Int) -> Unit,
    onSaveQuota: (DeviceQuotaAllocation) -> Unit,
    onDeleteQuota: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPlanDialog by remember { mutableStateOf(false) }
    var editingAllocation by remember { mutableStateOf<DeviceQuotaAllocation?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val supportsQuota = state.routerProfile.capabilities.supportsQuotaEnforcement ||
        state.routerProfile.gatewayAgentConnected

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "التوزيع الذكي للإنترنت",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "وزّع باقتك الشهرية على الأجهزة وحدد إجراءات التقييد التلقائية",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("quota_add_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(4.dp))
                    Text("إضافة حصة")
                }
            }
        }

        if (!supportsQuota) {
            item {
                InfoBannerCard(
                    title = "ملاحظة التنفيذ على الراوتر",
                    body = "تُراقَب الحصص وتصدر الإشعارات تلقائيًا داخل التطبيق. أما الإيقاف أو الحظر الفوري عند 90% و100% فيتم تنفيذه على الشبكة عند ربط راوتر OpenWrt / MikroTik أو وسيط الشبكة المحلي.",
                    accentColor = StatusWarning
                )
            }
        }

        // Plan Pool Overview Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إجمالي الباقة وتوزيع الحصص", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { showPlanDialog = true }) {
                            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("تعديل الباقة")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PoolMetric("حجم الباقة", "${state.settings.totalMonthlyPlanGb.toInt()} جيجابايت")
                        PoolMetric("الموزع للأجهزة", "${String.format(Locale.US, "%.1f", state.totalAllocatedGb)} جيجابايت")
                        PoolMetric("الاحتياطي المشترك", "${String.format(Locale.US, "%.1f", state.reservePoolGb)} جيجابايت")
                    }

                    Text(
                        text = "موعد إعادة التعيين الشهري: يوم ${state.settings.cycleResetDay} من كل شهر",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (state.quotas.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.PieChart,
                    title = "لم يتم توزيع حصص للأجهزة بعد",
                    description = "اضغط «إضافة حصة» لتحديد حصة كل جهاز بالجيجابايت وضبط إجراءات التنبيه أو تقليل السرعة عند 50% و80% و90% و100%.",
                    actionLabel = "تخصيص أول جهاز",
                    onAction = { showAddDialog = true }
                )
            }
        } else {
            items(state.quotas, key = { it.deviceId }) { quota ->
                QuotaItemCard(
                    quota = quota,
                    onEdit = { editingAllocation = quota },
                    onDelete = { onDeleteQuota(quota.deviceId) }
                )
            }
        }
    }

    if (showPlanDialog) {
        EditPlanDialog(
            currentGb = state.settings.totalMonthlyPlanGb,
            currentResetDay = state.settings.cycleResetDay,
            onDismiss = { showPlanDialog = false },
            onConfirm = { gb, day ->
                onSavePlanConfig(gb, day)
                showPlanDialog = false
            }
        )
    }

    if (showAddDialog || editingAllocation != null) {
        QuotaEditorDialog(
            devices = state.devices,
            existing = editingAllocation,
            resetDay = state.settings.cycleResetDay,
            maxSuggestedGb = state.settings.totalMonthlyPlanGb,
            onDismiss = {
                showAddDialog = false
                editingAllocation = null
            },
            onSave = { allocation ->
                onSaveQuota(allocation)
                showAddDialog = false
                editingAllocation = null
            }
        )
    }
}

@Composable
private fun PoolMetric(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun QuotaItemCard(
    quota: DeviceQuotaAllocation,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val pct = quota.usagePercent
    val barColor = when {
        pct >= 100f -> StatusDanger
        pct >= 80f -> StatusWarning
        else -> StatusOnline
    }

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = quota.deviceName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "الحصة: ${quota.allocatedGb} جيجابايت" +
                            if (quota.extraApprovedGb > 0) " (+${quota.extraApprovedGb} إضافي)" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Rounded.Edit, contentDescription = "تعديل الحصة")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.Delete, contentDescription = "حذف الحصة", tint = StatusDanger)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((pct / 100f).coerceIn(0.02f, 1f))
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(barColor)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "المستهلك: ${Formatters.formatBytes(quota.usedBytes)} (${pct.toInt()}%)",
                    style = MaterialTheme.typography.bodySmall,
                    color = barColor,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "المتبقي: ${Formatters.formatBytes(quota.remainingBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "إجراءات العتبات: 50% (${quota.actionAt50.labelAr}) • 80% (${quota.actionAt80.labelAr}) • 90% (${quota.actionAt90.labelAr}) • 100% (${quota.actionAt100.labelAr})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "إعادة التعيين: يوم ${quota.resetDayOfMonth} شهريًا",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EditPlanDialog(
    currentGb: Double,
    currentResetDay: Int,
    onDismiss: () -> Unit,
    onConfirm: (Double, Int) -> Unit
) {
    var gbText by remember { mutableStateOf(currentGb.toInt().toString()) }
    var dayText by remember { mutableStateOf(currentResetDay.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إعدادات الباقة الشهرية") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = gbText,
                    onValueChange = { if (it.all(Char::isDigit)) gbText = it },
                    label = { Text("حجم الباقة الكلي (جيجابايت)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(
                    value = dayText,
                    onValueChange = { if (it.all(Char::isDigit)) dayText = it },
                    label = { Text("يوم التجديد الشهري (1 - 28)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val gb = gbText.toDoubleOrNull()?.coerceAtLeast(1.0) ?: currentGb
                val day = dayText.toIntOrNull()?.coerceIn(1, 28) ?: currentResetDay
                onConfirm(gb, day)
            }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuotaEditorDialog(
    devices: List<DeviceInfo>,
    existing: DeviceQuotaAllocation?,
    resetDay: Int,
    maxSuggestedGb: Double,
    onDismiss: () -> Unit,
    onSave: (DeviceQuotaAllocation) -> Unit
) {
    var selectedDeviceId by remember { mutableStateOf(existing?.deviceId ?: devices.firstOrNull()?.id ?: "custom_${System.currentTimeMillis()}") }
    var deviceName by remember { mutableStateOf(existing?.deviceName ?: devices.firstOrNull()?.displayName ?: "") }
    var allocatedGb by remember { mutableDoubleStateOf(existing?.allocatedGb ?: 20.0) }
    var a50 by remember { mutableStateOf(existing?.actionAt50 ?: QuotaActionType.NOTIFY) }
    var a80 by remember { mutableStateOf(existing?.actionAt80 ?: QuotaActionType.NOTIFY) }
    var a90 by remember { mutableStateOf(existing?.actionAt90 ?: QuotaActionType.THROTTLE) }
    var a100 by remember { mutableStateOf(existing?.actionAt100 ?: QuotaActionType.PAUSE) }
    var deviceMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "تخصيص حصة جهاز" else "تعديل حصة ${existing.deviceName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (existing == null && devices.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = deviceMenuExpanded,
                        onExpandedChange = { deviceMenuExpanded = !deviceMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = deviceName.ifBlank { "اختر جهازًا من الشبكة" },
                            onValueChange = { deviceName = it },
                            readOnly = false,
                            label = { Text("الجهاز") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deviceMenuExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = deviceMenuExpanded,
                            onDismissRequest = { deviceMenuExpanded = false }
                        ) {
                            devices.forEach { d ->
                                DropdownMenuItem(
                                    text = { Text("${d.displayName} (${d.ipAddress})") },
                                    onClick = {
                                        selectedDeviceId = d.id
                                        deviceName = d.displayName
                                        deviceMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = deviceName,
                        onValueChange = { deviceName = it },
                        label = { Text("اسم الجهاز") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(
                    text = "الحصة المخصصة: ${allocatedGb.toInt()} جيجابايت",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Slider(
                    value = allocatedGb.toFloat(),
                    onValueChange = { allocatedGb = it.toDouble() },
                    valueRange = 1f..maxSuggestedGb.toFloat().coerceAtLeast(10f)
                )

                ActionSelectorRow("عند 50%", a50) { a50 = it }
                ActionSelectorRow("عند 80%", a80) { a80 = it }
                ActionSelectorRow("عند 90%", a90) { a90 = it }
                ActionSelectorRow("عند 100%", a100) { a100 = it }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val matchedDev = devices.firstOrNull { it.id == selectedDeviceId }
                    onSave(
                        DeviceQuotaAllocation(
                            deviceId = selectedDeviceId,
                            deviceName = deviceName.ifBlank { "جهاز مخصص" },
                            allocatedGb = allocatedGb.toInt().toDouble().coerceAtLeast(1.0),
                            usedBytes = matchedDev?.monthBytes ?: existing?.usedBytes ?: 0L,
                            resetDayOfMonth = resetDay,
                            actionAt50 = a50,
                            actionAt80 = a80,
                            actionAt90 = a90,
                            actionAt100 = a100,
                            extraApprovedGb = existing?.extraApprovedGb ?: 0.0,
                            lastTriggeredThreshold = existing?.lastTriggeredThreshold ?: 0
                        )
                    )
                },
                enabled = deviceName.isNotBlank(),
                modifier = Modifier.testTag("quota_dialog_save")
            ) {
                Text("حفظ الحصة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActionSelectorRow(
    thresholdLabel: String,
    selected: QuotaActionType,
    onSelect: (QuotaActionType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selected.labelAr,
            onValueChange = {},
            readOnly = true,
            label = { Text("الإجراء $thresholdLabel") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            QuotaActionType.entries.forEach { act ->
                DropdownMenuItem(
                    text = { Text(act.labelAr) },
                    onClick = {
                        onSelect(act)
                        expanded = false
                    }
                )
            }
        }
    }
}
