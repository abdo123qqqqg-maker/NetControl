package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.UsageChartPeriod
import com.example.ui.components.ComparisonBarList
import com.example.ui.components.InfoBannerCard
import com.example.ui.components.InteractiveTrafficChart
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.DownloadColor
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.UploadColor
import com.example.ui.viewmodel.NetControlUiState

@Composable
fun AnalyticsScreen(
    state: NetControlUiState,
    onSelectChartPeriod: (UsageChartPeriod) -> Unit,
    onExportCsv: (Uri) -> Unit,
    onExportPdf: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val csvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportCsv(uri)
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) onExportPdf(uri)
    }

    val summary = state.analyticsSummary
    val deviceBars = state.devices.sortedByDescending { it.monthBytes }.take(6).map { it.displayName to it.monthBytes }
    val appBars = state.appUsage.take(6).map { it.appName to it.monthBytes }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "التحليلات والتقارير",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تقارير يومية وأسبوعية وشهرية، توقعات الباقة، وتصدير PDF / CSV",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Anomaly Detection Alert
        item {
            InfoBannerCard(
                title = if (summary.anomalyDetected) "تنبيه ارتفاع غير طبيعي" else "حالة الاستهلاك والتوقعات",
                body = "${summary.anomalyMessageAr}\nتوقع انتهاء الباقة: ${summary.predictedExhaustionLabelAr}",
                accentColor = if (summary.anomalyDetected) StatusDanger else StatusOnline
            )
        }

        // Daily Avg & DL/UL Comparison KPIs
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricStatCard(
                    title = "المتوسط اليومي",
                    value = Formatters.formatBytes(summary.dailyAverageBytes),
                    subtitle = summary.predictedDaysRemaining?.let { "يكفي ~$it يومًا" } ?: "قيد الحساب",
                    icon = Icons.Rounded.TrendingUp,
                    accentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                MetricStatCard(
                    title = "التحميل مقابل الرفع",
                    value = Formatters.formatBytesCompact(summary.totalDownloadBytes),
                    subtitle = "الرفع: ${Formatters.formatBytesCompact(summary.totalUploadBytes)}",
                    icon = Icons.Rounded.Download,
                    accentColor = DownloadColor,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Period Report Chart
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("تقرير الاستهلاك حسب الفترة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        UsageChartPeriod.entries.forEach { period ->
                            FilterChip(
                                selected = state.chartPeriod == period,
                                onClick = { onSelectChartPeriod(period) },
                                label = { Text("تقرير ${period.labelAr}") }
                            )
                        }
                    }
                    InteractiveTrafficChart(data = state.chartData)
                }
            }
        }

        // Devices Comparison
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("مقارنة استهلاك الأجهزة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (deviceBars.isEmpty()) {
                        Text(
                            text = "لا توجد بيانات استهلاك مسجلة للأجهزة حتى الآن.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        ComparisonBarList(items = deviceBars, barColor = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Apps Comparison
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("مقارنة استهلاك التطبيقات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (appBars.isEmpty()) {
                        Text(
                            text = "فعّل صلاحية إحصائيات الاستخدام لعرض مقارنة التطبيقات.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        ComparisonBarList(items = appBars, barColor = UploadColor)
                    }
                }
            }
        }

        // Export Buttons (Real PDF & CSV via SAF)
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("تصدير التقارير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { pdfLauncher.launch("netcontrol_report.pdf") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_pdf_button")
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("تصدير PDF")
                        }
                        OutlinedButton(
                            onClick = { csvLauncher.launch("netcontrol_report.csv") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_csv_button")
                        ) {
                            Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("تصدير CSV")
                        }
                    }
                }
            }
        }
    }
}
