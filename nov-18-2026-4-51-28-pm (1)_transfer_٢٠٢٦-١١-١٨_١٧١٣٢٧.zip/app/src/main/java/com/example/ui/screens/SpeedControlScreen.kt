package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.DeviceInfo
import com.example.domain.model.NetworkPriority
import com.example.domain.model.SpeedControlRule
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InfoBannerCard
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.NetControlUiState

@Composable
fun SpeedControlScreen(
    state: NetControlUiState,
    onApplyRule: (DeviceInfo, Float, Float, NetworkPriority, Boolean, Boolean) -> Unit,
    onNavigateToRouter: () -> Unit,
    onScanNetwork: () -> Unit,
    modifier: Modifier = Modifier
) {
    val supportsSpeed = state.routerProfile.capabilities.supportsSpeedLimiting ||
        state.routerProfile.gatewayAgentConnected

    val rulesByDevice = remember(state.speedRules) {
        state.speedRules.associateBy { it.deviceId }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "التحكم في سرعة الإنترنت",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "ضبط أقصى سرعة للتحميل والرفع والأولوية لكل جهاز عبر واجهة الراوتر أو الوسيط",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            if (supportsSpeed) {
                InfoBannerCard(
                    title = "جاهز للتنفيذ الشبكي الفعلي",
                    body = "الراوتر أو وسيط الشبكة متصل ويدعم تحديد السرعة الفعلي لكل جهاز (${state.routerProfile.protocol.labelAr}).",
                    accentColor = StatusOnline
                )
            } else {
                InfoBannerCard(
                    title = "يتطلب راوترًا داعمًا لـ QoS / Queue أو وسيط شبكة",
                    body = "لا يمكن للراوتر الحالي فرض حدود سرعة برمجيًا مباشرة. يمكنك إعداد القواعد وحفظها، ثم ربط MikroTik أو OpenWrt أو وسيط الشبكة المحلي لتنفيذها.",
                    accentColor = StatusWarning,
                    actionLabel = "إعداد الراوتر / الوسيط",
                    onActionClick = onNavigateToRouter
                )
            }
        }

        if (state.devices.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Speed,
                    title = "لا توجد أجهزة لضبط سرعتها",
                    description = "افحص الشبكة المحلية أو اربط الراوتر أولاً لاكتشاف الأجهزة المتصلة.",
                    actionLabel = "فحص الشبكة الآن",
                    onAction = onScanNetwork
                )
            }
        } else {
            items(state.devices, key = { it.id }) { device ->
                DeviceSpeedRuleCard(
                    device = device,
                    existingRule = rulesByDevice[device.id],
                    canExecuteOnRouter = supportsSpeed,
                    onApply = { dl, ul, prio, enabled, paused ->
                        onApplyRule(device, dl, ul, prio, enabled, paused)
                    }
                )
            }
        }
    }
}

@Composable
private fun DeviceSpeedRuleCard(
    device: DeviceInfo,
    existingRule: SpeedControlRule?,
    canExecuteOnRouter: Boolean,
    onApply: (Float, Float, NetworkPriority, Boolean, Boolean) -> Unit
) {
    var dlMbps by remember(device.id, existingRule) {
        mutableFloatStateOf(existingRule?.maxDownloadMbps ?: 20f)
    }
    var ulMbps by remember(device.id, existingRule) {
        mutableFloatStateOf(existingRule?.maxUploadMbps ?: 10f)
    }
    var priority by remember(device.id, existingRule) {
        mutableStateOf(existingRule?.priority ?: NetworkPriority.NORMAL)
    }
    var isEnabled by remember(device.id, existingRule) {
        mutableStateOf(existingRule?.isEnabled ?: false)
    }
    var isPaused by remember(device.id, existingRule) {
        mutableStateOf(existingRule?.isPaused ?: false)
    }

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(device.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${device.ipAddress} • ${if (existingRule?.appliedToRouter == true) "مفعّل على الراوتر" else "محفوظ محليًا"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = isEnabled, onCheckedChange = { isEnabled = it })
            }

            Text(
                text = "أقصى سرعة تحميل: ${dlMbps.toInt()} ميجابت/ث",
                style = MaterialTheme.typography.labelLarge
            )
            Slider(
                value = dlMbps,
                onValueChange = { dlMbps = it },
                valueRange = 1f..200f
            )

            Text(
                text = "أقصى سرعة رفع: ${ulMbps.toInt()} ميجابت/ث",
                style = MaterialTheme.typography.labelLarge
            )
            Slider(
                value = ulMbps,
                onValueChange = { ulMbps = it },
                valueRange = 1f..100f
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NetworkPriority.entries.forEach { p ->
                    FilterChip(
                        selected = priority == p,
                        onClick = { priority = p },
                        label = { Text(p.labelAr) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        dlMbps = 2f
                        ulMbps = 1f
                        isEnabled = true
                        isPaused = false
                        onApply(2f, 1f, NetworkPriority.LOW, true, false)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("تقييد سريع (2M)")
                }
                OutlinedButton(
                    onClick = {
                        val nextPaused = !isPaused
                        isPaused = nextPaused
                        onApply(dlMbps, ulMbps, priority, isEnabled, nextPaused)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (isPaused) Icons.Rounded.PlayCircle else Icons.Rounded.PauseCircle,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.size(4.dp))
                    Text(if (isPaused) "استئناف التحكم" else "إيقاف التحكم")
                }
            }

            Button(
                onClick = { onApply(dlMbps, ulMbps, priority, isEnabled, isPaused) },
                enabled = canExecuteOnRouter || isEnabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("speed_apply_${device.id}")
            ) {
                Text(if (canExecuteOnRouter) "تطبيق القاعدة على الراوتر" else "حفظ القاعدة")
            }
        }
    }
}
