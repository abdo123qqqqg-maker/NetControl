package com.example.ui.navigation

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.domain.model.AppThemeMode
import com.example.ui.components.PinLockOverlay
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AppUsageScreen
import com.example.ui.screens.DeviceDetailsScreen
import com.example.ui.screens.DevicesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.QuotaDistributionScreen
import com.example.ui.screens.RouterManagementScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SpeedControlScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.theme.NetControlTheme
import com.example.ui.viewmodel.NetControlViewModel

object NetRoutes {
    const val DASHBOARD = "dashboard"
    const val DEVICES = "devices"
    const val DEVICE_DETAILS = "device_details/{deviceId}"
    const val APPS = "apps"
    const val QUOTA = "quota"
    const val SPEED = "speed"
    const val ANALYTICS = "analytics"
    const val ROUTER = "router"
    const val NOTIFICATIONS = "notifications"
    const val SETTINGS = "settings"

    fun deviceDetails(deviceId: String): String = "device_details/${Uri.encode(deviceId)}"
}

private data class NavDestination(
    val route: String,
    val labelAr: String,
    val icon: ImageVector,
    val testTag: String
)

private val bottomDestinations = listOf(
    NavDestination(NetRoutes.DASHBOARD, "الرئيسية", Icons.Rounded.Dashboard, "nav_dashboard"),
    NavDestination(NetRoutes.DEVICES, "الأجهزة", Icons.Rounded.Devices, "nav_devices"),
    NavDestination(NetRoutes.APPS, "التطبيقات", Icons.Rounded.Apps, "nav_apps"),
    NavDestination(NetRoutes.QUOTA, "الباقة", Icons.Rounded.PieChart, "nav_quota"),
    NavDestination(NetRoutes.ROUTER, "الراوتر", Icons.Rounded.Router, "nav_router")
)

private val secondaryDestinations = listOf(
    NavDestination(NetRoutes.SPEED, "التحكم في السرعة", Icons.Rounded.Speed, "menu_speed"),
    NavDestination(NetRoutes.ANALYTICS, "تحليلات وتقارير", Icons.Rounded.Analytics, "menu_analytics"),
    NavDestination(NetRoutes.NOTIFICATIONS, "الإشعارات الذكية", Icons.Rounded.Notifications, "menu_notifications"),
    NavDestination(NetRoutes.SETTINGS, "الإعدادات والأمان", Icons.Rounded.Settings, "menu_settings")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetControlApp(
    viewModel: NetControlViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val isDark = when (state.settings.themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.showBanner(
            if (granted) "تم تفعيل صلاحية الإشعارات بنجاح." else "تم رفض صلاحية الإشعارات؛ لن تظهر تنبيهات النظام."
        )
    }

    // Refresh real usage permissions & stats whenever user returns from Android Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshNow()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    NetControlTheme(darkTheme = isDark) {
        if (state.isLocked) {
            PinLockOverlay(
                biometricEnabled = state.settings.biometricEnabled,
                errorText = state.lockError,
                onPinSubmit = viewModel::unlockWithPin,
                onBiometricSuccess = viewModel::unlockWithBiometricSuccess
            )
            return@NetControlTheme
        }

        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        val snackbarHostState = remember { SnackbarHostState() }
        var showMoreSheet by remember { mutableStateOf(false) }

        LaunchedEffect(state.statusBannerMessage) {
            val msg = state.statusBannerMessage
            if (!msg.isNullOrBlank()) {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearBanner()
            }
        }

        fun navigateTopLevel(route: String) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "نت كنترول",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { navigateTopLevel(NetRoutes.SPEED) },
                            modifier = Modifier.testTag("topbar_speed_button")
                        ) {
                            Icon(Icons.Rounded.Speed, contentDescription = "التحكم في السرعة")
                        }
                        IconButton(
                            onClick = { navigateTopLevel(NetRoutes.ANALYTICS) },
                            modifier = Modifier.testTag("topbar_analytics_button")
                        ) {
                            Icon(Icons.Rounded.Analytics, contentDescription = "التحليلات والتقارير")
                        }
                        IconButton(
                            onClick = { navigateTopLevel(NetRoutes.NOTIFICATIONS) },
                            modifier = Modifier.testTag("topbar_notifications_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (state.unreadNotificationsCount > 0) {
                                        Badge { Text("${state.unreadNotificationsCount}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Rounded.Notifications, contentDescription = "الإشعارات")
                            }
                        }
                        IconButton(
                            onClick = { showMoreSheet = true },
                            modifier = Modifier.testTag("topbar_more_button")
                        ) {
                            Icon(Icons.Rounded.Menu, contentDescription = "القائمة الكاملة")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    bottomDestinations.forEach { dest ->
                        val selected = currentRoute == dest.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigateTopLevel(dest.route) },
                            icon = { Icon(dest.icon, contentDescription = dest.labelAr) },
                            label = {
                                Text(
                                    text = dest.labelAr,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            modifier = Modifier.testTag(dest.testTag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = NetRoutes.DASHBOARD
                ) {
                    composable(NetRoutes.DASHBOARD) {
                        DashboardScreen(
                            state = state,
                            onRefresh = viewModel::refreshNow,
                            onRequestUsageAccess = {
                                context.startActivity(viewModel.repository.trafficEngine.openUsageAccessIntent())
                            },
                            onSelectChartPeriod = viewModel::setChartPeriod,
                            onNavigateToQuota = { navigateTopLevel(NetRoutes.QUOTA) },
                            onNavigateToRouter = { navigateTopLevel(NetRoutes.ROUTER) },
                            onNavigateToDevices = { navigateTopLevel(NetRoutes.DEVICES) },
                            onNavigateToApps = { navigateTopLevel(NetRoutes.APPS) }
                        )
                    }
                    composable(NetRoutes.DEVICES) {
                        DevicesScreen(
                            state = state,
                            onScanNetwork = viewModel::scanNetwork,
                            onOpenDevice = { id ->
                                navController.navigate(NetRoutes.deviceDetails(id))
                            }
                        )
                    }
                    composable(
                        route = NetRoutes.DEVICE_DETAILS,
                        arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
                    ) { backStack ->
                        val encodedId = backStack.arguments?.getString("deviceId").orEmpty()
                        val decodedId = Uri.decode(encodedId)
                        DeviceDetailsScreen(
                            deviceId = decodedId,
                            state = state,
                            onBack = { navController.popBackStack() },
                            onSaveCustomization = viewModel::updateDeviceCustomization,
                            onToggleBlock = viewModel::toggleDeviceBlock,
                            onRestartConnection = viewModel::restartRouterConnection,
                            onNavigateToQuota = { navigateTopLevel(NetRoutes.QUOTA) },
                            onNavigateToSpeed = { navigateTopLevel(NetRoutes.SPEED) }
                        )
                    }
                    composable(NetRoutes.APPS) {
                        AppUsageScreen(
                            state = state,
                            onRequestUsageAccess = {
                                context.startActivity(viewModel.repository.trafficEngine.openUsageAccessIntent())
                            }
                        )
                    }
                    composable(NetRoutes.QUOTA) {
                        QuotaDistributionScreen(
                            state = state,
                            onSavePlanConfig = viewModel::setPlanConfig,
                            onSaveQuota = viewModel::saveQuotaAllocation,
                            onDeleteQuota = viewModel::deleteQuotaAllocation
                        )
                    }
                    composable(NetRoutes.SPEED) {
                        SpeedControlScreen(
                            state = state,
                            onApplyRule = viewModel::applySpeedRule,
                            onNavigateToRouter = { navigateTopLevel(NetRoutes.ROUTER) },
                            onScanNetwork = viewModel::scanNetwork
                        )
                    }
                    composable(NetRoutes.ANALYTICS) {
                        AnalyticsScreen(
                            state = state,
                            onSelectChartPeriod = viewModel::setChartPeriod,
                            onExportCsv = viewModel::exportCsv,
                            onExportPdf = viewModel::exportPdf
                        )
                    }
                    composable(NetRoutes.ROUTER) {
                        RouterManagementScreen(
                            state = state,
                            onAutoDetect = viewModel::autoDetectRouter,
                            onConnectRouter = viewModel::connectRouter,
                            onRestartWan = viewModel::restartRouterConnection
                        )
                    }
                    composable(NetRoutes.NOTIFICATIONS) {
                        NotificationsScreen(
                            state = state,
                            onMarkAllRead = viewModel::markAllNotificationsRead,
                            onApproveExtraQuota = viewModel::approveExtraQuota,
                            onTestNotification = viewModel::triggerTestNotification
                        )
                    }
                    composable(NetRoutes.SETTINGS) {
                        SettingsScreen(
                            state = state,
                            onSelectTheme = viewModel::setThemeMode,
                            onUpdateNotificationPrefs = viewModel::setNotificationPrefs,
                            onEnablePin = viewModel::enablePinLock,
                            onDisablePin = viewModel::disablePinLock,
                            onRequestUsageAccess = {
                                context.startActivity(viewModel.repository.trafficEngine.openUsageAccessIntent())
                            },
                            onRequestPostNotifications = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    viewModel.showBanner("صلاحية الإشعارات مفعلة تلقائيًا في هذا الإصدار.")
                                }
                            },
                            onDeleteAllData = viewModel::deleteAllUserData
                        )
                    }
                }
            }
        }

        if (showMoreSheet) {
            ModalBottomSheet(onDismissRequest = { showMoreSheet = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "جميع أقسام نت كنترول",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    (bottomDestinations + secondaryDestinations).forEach { item ->
                        NavigationDrawerItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                showMoreSheet = false
                                navigateTopLevel(item.route)
                            },
                            icon = { Icon(item.icon, contentDescription = item.labelAr) },
                            label = { Text(item.labelAr) },
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                    Spacer(Modifier.size(16.dp))
                }
            }
        }
    }
}
