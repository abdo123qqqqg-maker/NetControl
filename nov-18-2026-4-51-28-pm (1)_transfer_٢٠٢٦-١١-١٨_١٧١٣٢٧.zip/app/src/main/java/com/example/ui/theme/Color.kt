package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Slate-Navy & Electric Teal Network Command Palette
val TealPrimaryDark = Color(0xFF00DFC0)
val OnTealPrimaryDark = Color(0xFF003830)
val TealContainerDark = Color(0xFF005147)
val OnTealContainerDark = Color(0xFF7AF8E0)

val CyanSecondaryDark = Color(0xFF56CCF2)
val OnCyanSecondaryDark = Color(0xFF003447)
val CyanContainerDark = Color(0xFF0A4B66)
val OnCyanContainerDark = Color(0xFFC2ECFF)

val AmberTertiaryDark = Color(0xFFFFB74D)
val OnAmberTertiaryDark = Color(0xFF472A00)

val DarkBackground = Color(0xFF09111E)
val DarkSurface = Color(0xFF0F1929)
val DarkSurfaceVariant = Color(0xFF17253B)
val DarkSurfaceElevated = Color(0xFF1E304B)
val DarkOutline = Color(0xFF2D4363)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Network Operations Palette
val TealPrimaryLight = Color(0xFF00796B)
val OnTealPrimaryLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFC8F5EC)
val OnTealContainerLight = Color(0xFF00201C)

val CyanSecondaryLight = Color(0xFF0277BD)
val OnCyanSecondaryLight = Color(0xFFFFFFFF)
val CyanContainerLight = Color(0xFFD0EDFF)
val OnCyanContainerLight = Color(0xFF001E30)

val AmberTertiaryLight = Color(0xFFD97706)
val OnAmberTertiaryLight = Color(0xFFFFFFFF)

val LightBackground = Color(0xFFF3F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6EEF7)
val LightOutline = Color(0xFFCBD8E8)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

// Semantic Status Colors
val StatusOnline = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)
val StatusInfo = Color(0xFF38BDF8)
val UploadColor = Color(0xFF8B5CF6)
val DownloadColor = Color(0xFF00BFA5)
