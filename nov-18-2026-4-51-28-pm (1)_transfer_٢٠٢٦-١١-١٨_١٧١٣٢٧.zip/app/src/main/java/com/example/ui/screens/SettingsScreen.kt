package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.security.CryptoManager
import com.example.domain.model.AppThemeMode
import com.example.ui.components.InfoBannerCard
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.viewmodel.NetControlUiState

@Composable
fun SettingsScreen(
    state: NetControlUiState,
    onSelectTheme: (AppThemeMode) -> Unit,
    onUpdateNotificationPrefs: (Boolean, Boolean, Boolean) -> Unit,
    onEnablePin: (String, Boolean) -> Unit,
    onDisablePin: () -> Unit,
    onRequestUsageAccess: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onDeleteAllData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings = state.settings
    val bioAvailable = remember { CryptoManager.isBiometricAvailable(context) }

    var showPinDialog by remember { mutableStateOf(false) }
    var showWipeConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "الإعدادات والأمان",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "المظهر، التنبيهات، قفل الأمان، الصلاحيات، والخصوصية",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Theme Mode
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("مظهر التطبيق", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { onSelectTheme(mode) },
                                label = { Text(mode.labelAr) }
                            )
                        }
                    }
                }
            }
        }

        // Security & PIN / Biometric
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("حماية واجهة الإدارة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = if (settings.pinEnabled) {
                            "القفل مفعل برمز PIN مشفّر ${if (settings.biometricEnabled) "+ بصمة الجهاز" else ""}"
                        } else {
                            "القفل غير مفعل حاليًا. فعّل رمز PIN أو البصمة لحماية إعدادات الراوتر."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showPinDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_pin_setup_button")
                        ) {
                            Text(if (settings.pinEnabled) "تغيير رمز PIN" else "تفعيل رمز PIN")
                        }
                        if (settings.pinEnabled) {
                            OutlinedButton(
                                onClick = onDisablePin,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إلغاء القفل")
                            }
                        }
                    }
                }
            }
        }

        // Notification Triggers
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("التنبيهات الذكية التلقائية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    SettingSwitchRow(
                        title = "إشعار عند اتصال جهاز جديد",
                        checked = settings.notifyOnNewDevice,
                        onCheckedChange = {
                            onUpdateNotificationPrefs(it, settings.notifyOnInternetDown, settings.notifyOnUsageSpike)
                        }
                    )
                    SettingSwitchRow(
                        title = "إشعار عند انقطاع الإنترنت",
                        checked = settings.notifyOnInternetDown,
                        onCheckedChange = {
                            onUpdateNotificationPrefs(settings.notifyOnNewDevice, it, settings.notifyOnUsageSpike)
                        }
                    )
                    SettingSwitchRow(
                        title = "إشعار عند ارتفاع الاستهلاك بشكل غير معتاد",
                        checked = settings.notifyOnUsageSpike,
                        onCheckedChange = {
                            onUpdateNotificationPrefs(settings.notifyOnNewDevice, settings.notifyOnInternetDown, it)
                        }
                    )
                }
            }
        }

        // Permissions Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("الصلاحيات الضرورية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (state.hasUsagePermission) "إحصائيات الاستخدام: مفعلة" else "إحصائيات الاستخدام: غير مفعلة",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (state.hasUsagePermission) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = onRequestUsageAccess) {
                            Text("ضبط")
                        }
                    }
                    OutlinedButton(
                        onClick = onRequestPostNotifications,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("التحقق من صلاحية الإشعارات")
                    }
                }
            }
        }

        // Privacy & Full Data Deletion
        item {
            InfoBannerCard(
                title = "الخصوصية وتشفير البيانات",
                body = "تُخزن جميع بيانات الشبكة، الأسماء، وسجل الاستهلاك محليًا على جهازك فقط دون إرسالها إلى أي خادم خارجي. تُشفّر كلمات مرور الراوتر عبر Android Keystore AES-256.",
                accentColor = StatusOnline
            )
        }

        item {
            Button(
                onClick = { showWipeConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_wipe_data_button")
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text("حذف جميع بيانات المستخدم نهائيًا")
            }
        }
    }

    if (showPinDialog) {
        SetupPinDialog(
            biometricAvailable = bioAvailable,
            initialBio = settings.biometricEnabled,
            onDismiss = { showPinDialog = false },
            onSave = { pin, bio ->
                onEnablePin(pin, bio)
                showPinDialog = false
            }
        )
    }

    if (showWipeConfirm) {
        AlertDialog(
            onDismissRequest = { showWipeConfirm = false },
            title = { Text("تأكيد حذف جميع البيانات") },
            text = { Text("سيتم حذف إعدادات الراوتر المشفرة، حصص التوزيع الذكي، قواعد السرعة، وسجل الإشعارات والتقارير محليًا بشكل نهائي.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllData()
                        showWipeConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("حذف الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeConfirm = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SetupPinDialog(
    biometricAvailable: Boolean,
    initialBio: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Boolean) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var useBio by remember { mutableStateOf(initialBio && biometricAvailable) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعيين رمز قفل التطبيق (PIN)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                    label = { Text("أدخل 4 إلى 6 أرقام") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )
                if (biometricAvailable) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("السماح بفتح القفل عبر البصمة", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = useBio, onCheckedChange = { useBio = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(pin, useBio) },
                enabled = pin.length >= 4
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
