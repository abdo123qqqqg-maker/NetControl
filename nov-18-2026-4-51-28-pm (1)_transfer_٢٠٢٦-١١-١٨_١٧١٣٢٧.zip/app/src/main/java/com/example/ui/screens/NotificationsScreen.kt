package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.NotificationType
import com.example.domain.model.SmartNotification
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.formatTimeArabic
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.NetControlUiState

@Composable
fun NotificationsScreen(
    state: NetControlUiState,
    onMarkAllRead: () -> Unit,
    onApproveExtraQuota: (Long, String, Double) -> Unit,
    onTestNotification: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "الإشعارات الذكية",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.unreadNotificationsCount} إشعارات غير مقروءة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onTestNotification) {
                        Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.size(4.dp))
                        Text("اختبار")
                    }
                    if (state.notifications.isNotEmpty()) {
                        OutlinedButton(onClick = onMarkAllRead, modifier = Modifier.testTag("notifications_mark_read")) {
                            Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        if (state.notifications.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Notifications,
                    title = "لا توجد تنبيهات حاليًا",
                    description = "سيظهر هنا أي تنبيه عند اتصال جهاز جديد، أو اقتراب نفاد حصة جهاز، أو انقطاع الإنترنت، أو ارتفاع الاستهلاك بشكل غير معتاد.",
                    actionLabel = "إرسال تنبيه تجريبي",
                    onAction = onTestNotification
                )
            }
        } else {
            items(state.notifications, key = { it.id }) { item ->
                NotificationCard(
                    item = item,
                    onApprove = { extraGb ->
                        item.relatedDeviceId?.let { devId ->
                            onApproveExtraQuota(item.id, devId, extraGb)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun NotificationCard(
    item: SmartNotification,
    onApprove: (Double) -> Unit
) {
    val accent = when (item.type) {
        NotificationType.QUOTA_EXCEEDED, NotificationType.INTERNET_DOWN, NotificationType.USAGE_SPIKE -> StatusDanger
        NotificationType.QUOTA_WARNING, NotificationType.PLAN_EXPIRING, NotificationType.UNKNOWN_DEVICE -> StatusWarning
        NotificationType.APPROVAL_REQUEST -> StatusOnline
        NotificationType.NEW_DEVICE -> StatusInfo
    }

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (item.isRead) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accent.copy(alpha = 0.16f)
                ) {
                    Text(
                        text = item.type.labelAr,
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Text(
                    text = formatTimeArabic(item.timestampMillis),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(text = item.titleAr, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(text = item.messageAr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (item.requiresApproval && !item.approvalHandled && item.relatedDeviceId != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onApprove(5.0) }) {
                        Text("موافقة (+5 جيجابايت)")
                    }
                    OutlinedButton(onClick = { onApprove(0.0) }) {
                        Text("رفض")
                    }
                }
            }
        }
    }
}
