package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.export.ReportExporter
import com.example.core.security.CryptoManager
import com.example.data.local.UserSettings
import com.example.data.repository.NetControlRepository
import com.example.domain.model.AnalyticsSummary
import com.example.domain.model.AppThemeMode
import com.example.domain.model.AppUsageStat
import com.example.domain.model.DeviceIconKey
import com.example.domain.model.DeviceInfo
import com.example.domain.model.DeviceQuotaAllocation
import com.example.domain.model.LiveConnectionInfo
import com.example.domain.model.NetworkPriority
import com.example.domain.model.NotificationType
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterVendor
import com.example.domain.model.SmartNotification
import com.example.domain.model.SpeedControlRule
import com.example.domain.model.UsageChartPeriod
import com.example.domain.model.UsageDataPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class NetControlUiState(
    val settings: UserSettings = UserSettings(),
    val liveConnection: LiveConnectionInfo = LiveConnectionInfo(),
    val hasUsagePermission: Boolean = false,
    val routerProfile: RouterProfile = RouterProfile(),
    val devices: List<DeviceInfo> = emptyList(),
    val appUsage: List<AppUsageStat> = emptyList(),
    val quotas: List<DeviceQuotaAllocation> = emptyList(),
    val speedRules: List<SpeedControlRule> = emptyList(),
    val notifications: List<SmartNotification> = emptyList(),
    val chartPeriod: UsageChartPeriod = UsageChartPeriod.DAILY,
    val chartData: List<UsageDataPoint> = emptyList(),
    val analyticsSummary: AnalyticsSummary = AnalyticsSummary(),
    val lanScanNote: String = "",
    val isScanningLan: Boolean = false,
    val isConnectingRouter: Boolean = false,
    val isLocked: Boolean = false,
    val lockError: String? = null,
    val statusBannerMessage: String? = null
) {
    val connectedDevicesCount: Int get() = devices.count { it.isOnline }
    val topDevice: DeviceInfo? get() = devices.maxByOrNull { it.monthBytes }
    val topApp: AppUsageStat? get() = appUsage.firstOrNull()
    val unreadNotificationsCount: Int get() = notifications.count { !it.isRead }
    val totalAllocatedGb: Double get() = quotas.sumOf { it.allocatedGb }
    val reservePoolGb: Double get() = (settings.totalMonthlyPlanGb - totalAllocatedGb).coerceAtLeast(0.0)
    val totalMonthUsedBytes: Long
        get() {
            val devicesSum = devices.sumOf { it.monthBytes }
            return maxOf(liveConnection.phoneMonthBytes, devicesSum)
        }
    val remainingPlanBytes: Long
        get() {
            val planBytes = (settings.totalMonthlyPlanGb * 1024.0 * 1024.0 * 1024.0).toLong()
            return (planBytes - totalMonthUsedBytes).coerceAtLeast(0L)
        }
}

class NetControlViewModel(application: Application) : AndroidViewModel(application) {

    val repository = NetControlRepository(application)
    private val exporter = ReportExporter(application)

    private val _chartPeriod = MutableStateFlow(UsageChartPeriod.DAILY)
    private val _isScanningLan = MutableStateFlow(false)
    private val _isConnectingRouter = MutableStateFlow(false)
    private val _statusBanner = MutableStateFlow<String?>(null)
    private val _isUnlockedThisSession = MutableStateFlow(false)
    private val _lockError = MutableStateFlow<String?>(null)

    private val coreDataFlow = combine(
        repository.userSettings,
        repository.liveConnection,
        repository.hasUsagePermission,
        repository.routerProfile,
        repository.devices
    ) { settings, live, perm, router, devices ->
        CoreBundle(settings, live, perm, router, devices)
    }

    private val secondaryDataFlow = combine(
        repository.appUsage,
        repository.quotas,
        repository.speedRules,
        repository.notifications,
        repository.usageSnapshots
    ) { apps, quotas, rules, notifs, snapshots ->
        SecondaryBundle(apps, quotas, rules, notifs, snapshots)
    }

    private val uiFlagsFlow = combine(
        _chartPeriod,
        _isScanningLan,
        _isConnectingRouter,
        _statusBanner,
        _isUnlockedThisSession
    ) { period, scanning, connecting, banner, unlocked ->
        UiFlagsBundle(period, scanning, connecting, banner, unlocked)
    }

    val uiState: StateFlow<NetControlUiState> = combine(
        coreDataFlow,
        secondaryDataFlow,
        uiFlagsFlow,
        repository.lanScanNote,
        _lockError
    ) { core, secondary, flags, lanNote, lockErr ->
        val chartSeries = repository.buildChartSeries(secondary.snapshots, flags.period, core.live)
        val summary = repository.computeAnalyticsSummary(secondary.snapshots, core.live, secondary.apps, core.settings)
        val shouldLock = core.settings.pinEnabled && !flags.unlocked

        NetControlUiState(
            settings = core.settings,
            liveConnection = core.live,
            hasUsagePermission = core.hasUsagePerm,
            routerProfile = core.router,
            devices = core.devices,
            appUsage = secondary.apps,
            quotas = secondary.quotas,
            speedRules = secondary.rules,
            notifications = secondary.notifications,
            chartPeriod = flags.period,
            chartData = chartSeries,
            analyticsSummary = summary,
            lanScanNote = lanNote,
            isScanningLan = flags.scanning,
            isConnectingRouter = flags.connecting,
            isLocked = shouldLock,
            lockError = lockErr,
            statusBannerMessage = flags.banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = NetControlUiState()
    )

    init {
        startLiveTelemetryLoop()
        triggerInitialScan()
    }

    private fun startLiveTelemetryLoop() {
        viewModelScope.launch {
            while (isActive) {
                runCatching {
                    repository.refreshLiveTelemetry(uiState.value.settings)
                }
                delay(2500L)
            }
        }
    }

    private fun triggerInitialScan() {
        viewModelScope.launch {
            delay(400L)
            scanNetwork()
        }
    }

    fun refreshNow() {
        viewModelScope.launch {
            repository.refreshLiveTelemetry(uiState.value.settings)
        }
    }

    fun scanNetwork() {
        if (_isScanningLan.value) return
        viewModelScope.launch {
            _isScanningLan.value = true
            runCatching {
                repository.refreshLiveTelemetry(uiState.value.settings)
                repository.scanLanAndSyncRouter(uiState.value.settings)
            }.onFailure {
                _statusBanner.value = "تعذر إكمال فحص الشبكة: ${it.localizedMessage}"
            }
            _isScanningLan.value = false
        }
    }

    fun setChartPeriod(period: UsageChartPeriod) {
        _chartPeriod.value = period
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun showBanner(msg: String) {
        _statusBanner.value = msg
    }

    fun connectRouter(
        vendor: RouterVendor,
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String,
        gatewayUrl: String,
        gatewayToken: String
    ) {
        viewModelScope.launch {
            _isConnectingRouter.value = true
            val res = repository.connectRouter(
                vendor = vendor,
                hostIp = hostIp.trim(),
                port = port,
                useHttps = useHttps,
                username = username.trim(),
                password = password,
                gatewayUrl = gatewayUrl.trim(),
                gatewayToken = gatewayToken,
                settings = uiState.value.settings
            )
            res.onSuccess { profile ->
                _statusBanner.value = "تم الاتصال بـ ${profile.manufacturer} (${profile.modelName})"
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "فشل الاتصال بالراوتر. تحقق من عنوان IP وبيانات الدخول."
            }
            _isConnectingRouter.value = false
        }
    }

    fun autoDetectRouter(hostIp: String, onDetected: (RouterVendor) -> Unit) {
        viewModelScope.launch {
            _isConnectingRouter.value = true
            val detected = repository.autoDetectRouterVendor(hostIp.trim())
            _isConnectingRouter.value = false
            onDetected(detected)
            _statusBanner.value = "نتيجة الاكتشاف التلقائي: ${detected.displayNameAr}"
        }
    }

    fun updateDeviceCustomization(
        deviceId: String,
        customName: String,
        iconKey: DeviceIconKey,
        avatarUri: String?,
        isKnown: Boolean
    ) {
        viewModelScope.launch {
            repository.updateDeviceCustomization(deviceId, customName, iconKey, avatarUri, isKnown)
            _statusBanner.value = "تم حفظ تعديلات الجهاز بنجاح."
        }
    }

    fun toggleDeviceBlock(device: DeviceInfo, blocked: Boolean) {
        viewModelScope.launch {
            val res = repository.setDeviceBlocked(device, blocked)
            _statusBanner.value = res.messageAr
        }
    }

    fun restartRouterConnection() {
        viewModelScope.launch {
            val res = repository.restartRouterConnection()
            _statusBanner.value = res.messageAr
        }
    }

    fun saveQuotaAllocation(allocation: DeviceQuotaAllocation) {
        viewModelScope.launch {
            repository.saveQuotaAllocation(allocation)
            repository.evaluateQuotasAndAlerts(uiState.value.settings)
            _statusBanner.value = "تم حفظ حصة ${allocation.deviceName} (${allocation.allocatedGb} جيجابايت)."
        }
    }

    fun deleteQuotaAllocation(deviceId: String) {
        viewModelScope.launch {
            repository.deleteQuotaAllocation(deviceId)
            _statusBanner.value = "تمت إزالة تخصيص الحصة."
        }
    }

    fun applySpeedRule(
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float,
        priority: NetworkPriority,
        isEnabled: Boolean,
        isPaused: Boolean
    ) {
        viewModelScope.launch {
            val rule = SpeedControlRule(
                deviceId = device.id,
                deviceName = device.displayName,
                maxDownloadMbps = maxDownloadMbps,
                maxUploadMbps = maxUploadMbps,
                priority = priority,
                isEnabled = isEnabled,
                isPaused = isPaused,
                appliedToRouter = false,
                lastSyncedMillis = System.currentTimeMillis()
            )
            val res = repository.applySpeedRule(rule, device)
            _statusBanner.value = res.messageAr
        }
    }

    fun approveExtraQuota(notificationId: Long, deviceId: String, extraGb: Double) {
        viewModelScope.launch {
            repository.approveExtraQuota(notificationId, deviceId, extraGb)
            _statusBanner.value = "تمت الموافقة على إضافة $extraGb جيجابايت."
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun triggerTestNotification() {
        viewModelScope.launch {
            repository.recordNotification(
                type = NotificationType.QUOTA_WARNING,
                titleAr = "اختبار نظام التنبيهات الذكية",
                messageAr = "إشعارات نت كنترول تعمل بنجاح وجاهزة لتنبيهك عند اقتراب نفاد الباقة أو اتصال جهاز جديد."
            )
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { repository.preferences.setThemeMode(mode) }
    }

    fun setPlanConfig(totalGb: Double, resetDay: Int) {
        viewModelScope.launch {
            repository.preferences.setPlanConfig(totalGb, resetDay)
            _statusBanner.value = "تم تحديث إعدادات الباقة ($totalGb جيجابايت)."
        }
    }

    fun setNotificationPrefs(onNewDevice: Boolean, onInternetDown: Boolean, onSpike: Boolean) {
        viewModelScope.launch {
            repository.preferences.setNotificationPreferences(onNewDevice, onInternetDown, onSpike)
        }
    }

    fun enablePinLock(pin: String, enableBiometric: Boolean) {
        viewModelScope.launch {
            repository.preferences.enablePin(pin, enableBiometric)
            _isUnlockedThisSession.value = true
            _statusBanner.value = "تم تفعيل قفل الأمان بنجاح."
        }
    }

    fun disablePinLock() {
        viewModelScope.launch {
            repository.preferences.disableSecurityLock()
            _isUnlockedThisSession.value = true
            _statusBanner.value = "تم إلغاء قفل التطبيق."
        }
    }

    fun unlockWithPin(pin: String) {
        val settings = uiState.value.settings
        if (CryptoManager.verifyPin(pin, settings.pinSalt, settings.pinHash)) {
            _isUnlockedThisSession.value = true
            _lockError.value = null
        } else {
            _lockError.value = "رمز PIN غير صحيح. حاول مرة أخرى."
        }
    }

    fun unlockWithBiometricSuccess() {
        _isUnlockedThisSession.value = true
        _lockError.value = null
    }

    fun exportCsv(uri: Uri) {
        viewModelScope.launch {
            val state = uiState.value
            val res = exporter.exportCsv(uri, state.devices, state.appUsage, state.quotas, state.analyticsSummary)
            _statusBanner.value = if (res.isSuccess) "تم تصدير تقرير CSV بنجاح." else "فشل تصدير CSV: ${res.exceptionOrNull()?.localizedMessage}"
        }
    }

    fun exportPdf(uri: Uri) {
        viewModelScope.launch {
            val state = uiState.value
            val res = exporter.exportPdf(uri, state.devices, state.appUsage, state.quotas, state.analyticsSummary)
            _statusBanner.value = if (res.isSuccess) "تم تصدير تقرير PDF بنجاح." else "فشل تصدير PDF: ${res.exceptionOrNull()?.localizedMessage}"
        }
    }

    fun deleteAllUserData() {
        viewModelScope.launch {
            repository.clearAllUserData()
            _isUnlockedThisSession.value = true
            _statusBanner.value = "تم حذف جميع البيانات المخزنة وإعدادات الراوتر بأمان."
        }
    }

    private data class CoreBundle(
        val settings: UserSettings,
        val live: LiveConnectionInfo,
        val hasUsagePerm: Boolean,
        val router: RouterProfile,
        val devices: List<DeviceInfo>
    )

    private data class SecondaryBundle(
        val apps: List<AppUsageStat>,
        val quotas: List<DeviceQuotaAllocation>,
        val rules: List<SpeedControlRule>,
        val notifications: List<SmartNotification>,
        val snapshots: List<com.example.data.local.UsageSnapshotEntity>
    )

    private data class UiFlagsBundle(
        val period: UsageChartPeriod,
        val scanning: Boolean,
        val connecting: Boolean,
        val banner: String?,
        val unlocked: Boolean
    )
}
