package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.UsageDataPoint
import com.example.ui.theme.DownloadColor
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.UploadColor
import kotlin.math.roundToInt

@Composable
fun InteractiveTrafficChart(
    data: List<UsageDataPoint>,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember(data) { mutableStateOf<Int?>(data.lastIndex.takeIf { it >= 0 }) }
    val animProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 650),
        label = "chartReveal"
    )

    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val dlColor = DownloadColor
    val ulColor = UploadColor

    Column(modifier = modifier.fillMaxWidth()) {
        // Legend + Selected Tooltip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                LegendDot(color = dlColor, label = "التحميل")
                LegendDot(color = ulColor, label = "الرفع")
            }
            val selectedPoint = selectedIndex?.let { data.getOrNull(it) }
            if (selectedPoint != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = "${selectedPoint.labelAr}: ↓ ${Formatters.formatBytesCompact(selectedPoint.downloadBytes)} | ↑ ${Formatters.formatBytesCompact(selectedPoint.uploadBytes)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (data.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "لا توجد قراءات مسجلة بعد لعرض الرسم البياني",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .pointerInput(data) {
                        detectTapGestures { tapOffset ->
                            if (data.size <= 1) {
                                selectedIndex = 0
                            } else {
                                val stepX = size.width.toFloat() / (data.size - 1).coerceAtLeast(1)
                                val idx = (tapOffset.x / stepX).roundToInt().coerceIn(0, data.lastIndex)
                                selectedIndex = idx
                            }
                        }
                    }
            ) {
                val maxVal = data.maxOf { maxOf(it.downloadBytes, it.uploadBytes) }.coerceAtLeast(1L).toFloat()
                val topPad = 14.dp.toPx()
                val bottomPad = 16.dp.toPx()
                val chartHeight = (size.height - topPad - bottomPad).coerceAtLeast(1f)
                val chartWidth = size.width

                // Horizontal grid lines
                for (i in 0..3) {
                    val y = topPad + (chartHeight / 3f) * i
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(chartWidth, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                if (data.size == 1) {
                    val barW = 42.dp.toPx()
                    val centerX = chartWidth / 2f
                    val dlH = (data[0].downloadBytes / maxVal) * chartHeight * animProgress
                    val ulH = (data[0].uploadBytes / maxVal) * chartHeight * animProgress
                    drawRect(
                        color = dlColor,
                        topLeft = Offset(centerX - barW - 6.dp.toPx(), topPad + chartHeight - dlH),
                        size = Size(barW, dlH)
                    )
                    drawRect(
                        color = ulColor,
                        topLeft = Offset(centerX + 6.dp.toPx(), topPad + chartHeight - ulH),
                        size = Size(barW, ulH)
                    )
                    return@Canvas
                }

                val stepX = chartWidth / (data.size - 1).coerceAtLeast(1)
                val dlPoints = data.mapIndexed { idx, pt ->
                    val x = idx * stepX
                    val y = topPad + chartHeight - (pt.downloadBytes / maxVal) * chartHeight * animProgress
                    Offset(x, y)
                }
                val ulPoints = data.mapIndexed { idx, pt ->
                    val x = idx * stepX
                    val y = topPad + chartHeight - (pt.uploadBytes / maxVal) * chartHeight * animProgress
                    Offset(x, y)
                }

                // Fill gradient under download curve
                val areaPath = Path().apply {
                    moveTo(dlPoints.first().x, topPad + chartHeight)
                    dlPoints.forEach { lineTo(it.x, it.y) }
                    lineTo(dlPoints.last().x, topPad + chartHeight)
                    close()
                }
                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(dlColor.copy(alpha = 0.28f), Color.Transparent),
                        startY = topPad,
                        endY = topPad + chartHeight
                    )
                )

                // Lines
                val dlPath = Path().apply {
                    moveTo(dlPoints.first().x, dlPoints.first().y)
                    for (i in 1 until dlPoints.size) {
                        val prev = dlPoints[i - 1]
                        val curr = dlPoints[i]
                        val midX = (prev.x + curr.x) / 2f
                        cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                    }
                }
                drawPath(dlPath, color = dlColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))

                val ulPath = Path().apply {
                    moveTo(ulPoints.first().x, ulPoints.first().y)
                    for (i in 1 until ulPoints.size) {
                        val prev = ulPoints[i - 1]
                        val curr = ulPoints[i]
                        val midX = (prev.x + curr.x) / 2f
                        cubicTo(midX, prev.y, midX, curr.y, curr.x, curr.y)
                    }
                }
                drawPath(ulPath, color = ulColor, style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round))

                // Points & selection indicator
                dlPoints.forEachIndexed { idx, pt ->
                    val isSel = idx == selectedIndex
                    if (isSel) {
                        drawLine(
                            color = dlColor.copy(alpha = 0.45f),
                            start = Offset(pt.x, topPad),
                            end = Offset(pt.x, topPad + chartHeight),
                            strokeWidth = 1.5.dp.toPx()
                        )
                        drawCircle(color = dlColor, radius = 6.dp.toPx(), center = pt)
                    } else {
                        drawCircle(color = dlColor, radius = 3.5.dp.toPx(), center = pt)
                    }
                }
            }

            // X-axis labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val labelsToShow = if (data.size <= 5) data else listOf(data.first(), data[data.size / 2], data.last())
                labelsToShow.forEach { pt ->
                    Text(
                        text = pt.labelAr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ComparisonBarList(
    items: List<Pair<String, Long>>,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val maxBytes = items.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { (label, bytes) ->
            val targetFraction = (bytes.toFloat() / maxBytes.toFloat()).coerceIn(0.03f, 1f)
            val animFraction by animateFloatAsState(
                targetValue = targetFraction,
                animationSpec = tween(550),
                label = "barAnim"
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = Formatters.formatBytes(bytes),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animFraction)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(barColor)
                    )
                }
            }
        }
    }
}

@Composable
fun QuotaRingGauge(
    percent: Float,
    centerLabel: String,
    subLabel: String,
    modifier: Modifier = Modifier
) {
    val clamped = percent.coerceIn(0f, 100f)
    val animSweep by animateFloatAsState(
        targetValue = (clamped / 100f) * 260f,
        animationSpec = tween(700),
        label = "ringSweep"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
    val arcColor = when {
        percent >= 90f -> StatusDanger
        percent >= 75f -> StatusWarning
        else -> StatusOnline
    }

    Box(modifier = modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(140.dp)) {
            val strokeW = 14.dp.toPx()
            drawArc(
                color = trackColor,
                startAngle = 140f,
                sweepAngle = 260f,
                useCenter = false,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
            drawArc(
                color = arcColor,
                startAngle = 140f,
                sweepAngle = animSweep,
                useCenter = false,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerLabel,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
