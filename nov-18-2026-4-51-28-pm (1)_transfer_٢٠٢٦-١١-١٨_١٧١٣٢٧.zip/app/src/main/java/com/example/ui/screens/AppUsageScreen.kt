package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppUsageStat
import com.example.domain.model.Formatters
import com.example.domain.model.UsageChartPeriod
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InfoBannerCard
import com.example.ui.theme.DownloadColor
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.UploadColor
import com.example.ui.viewmodel.NetControlUiState
import java.util.Locale

@Composable
fun AppUsageScreen(
    state: NetControlUiState,
    onRequestUsageAccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPeriod by remember { mutableStateOf(UsageChartPeriod.MONTHLY) }
    var query by remember { mutableStateOf("") }

    val sortedApps = remember(state.appUsage, selectedPeriod, query) {
        state.appUsage
            .filter {
                query.isBlank() ||
                    it.appName.contains(query, ignoreCase = true) ||
                    it.packageName.contains(query, ignoreCase = true)
            }
            .sortedByDescending {
                when (selectedPeriod) {
                    UsageChartPeriod.DAILY -> it.todayBytes
                    UsageChartPeriod.WEEKLY -> it.weekBytes
                    UsageChartPeriod.MONTHLY -> it.monthBytes
                }
            }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "مراقبة استهلاك التطبيقات",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تحليل استهلاك بيانات Wi-Fi والجوال لكل تطبيق على هذا الهاتف",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            InfoBannerCard(
                title = "شفافية مصدر البيانات",
                body = "تُقرأ هذه الإحصائيات مباشرة من واجهة NetworkStatsManager في أندرويد لهذا الهاتف فقط. لا تدّعي التطبيقات معرفة استهلاك تطبيقات الأجهزة الأخرى على الشبكة إلا إذا كان الراوتر يدعم فحص الحزم العميق (DPI).",
                accentColor = StatusInfo
            )
        }

        if (!state.hasUsagePermission) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Apps,
                    title = "يلزم منح صلاحية إحصائيات الاستخدام",
                    description = "فعّل «الوصول إلى بيانات الاستخدام» لتطبيق نت كنترول حتى يتمكن من حساب استهلاك كل تطبيق بدقة.",
                    actionLabel = "فتح إعدادات الصلاحية",
                    onAction = onRequestUsageAccess
                )
            }
        } else {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("ابحث عن تطبيق") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    UsageChartPeriod.entries.forEach { p ->
                        FilterChip(
                            selected = selectedPeriod == p,
                            onClick = { selectedPeriod = p },
                            label = { Text(p.labelAr) }
                        )
                    }
                }
            }

            if (sortedApps.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Rounded.Apps,
                        title = "لا توجد بيانات تطبيقات مسجلة",
                        description = "لم يسجل النظام استهلاكًا للتطبيقات في الفترة المحددة بعد."
                    )
                }
            } else {
                items(sortedApps, key = { it.uid }) { app ->
                    AppUsageRowCard(app = app, period = selectedPeriod)
                }
            }
        }
    }
}

@Composable
private fun AppUsageRowCard(
    app: AppUsageStat,
    period: UsageChartPeriod
) {
    val context = LocalContext.current
    val appIconBitmap = remember(app.packageName) {
        runCatching {
            val drawable = context.packageManager.getApplicationIcon(app.packageName)
            drawableToBitmap(drawable)
        }.getOrNull()
    }

    val displayedBytes = when (period) {
        UsageChartPeriod.DAILY -> app.todayBytes
        UsageChartPeriod.WEEKLY -> app.weekBytes
        UsageChartPeriod.MONTHLY -> app.monthBytes
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                    contentAlignment = Alignment.Center
                ) {
                    if (appIconBitmap != null) {
                        Image(
                            bitmap = appIconBitmap,
                            contentDescription = app.appName,
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        Icon(Icons.Rounded.Apps, contentDescription = app.appName)
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "↓ ${Formatters.formatBytesCompact(app.downloadBytes)}  •  ↑ ${Formatters.formatBytesCompact(app.uploadBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = Formatters.formatBytes(displayedBytes),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.1f", app.percentageOfTotal)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Share bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((app.percentageOfTotal / 100f).coerceIn(0.02f, 1f))
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(DownloadColor)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "اليوم: ${Formatters.formatBytesCompact(app.todayBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "الأسبوع: ${Formatters.formatBytesCompact(app.weekBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "الشهر: ${Formatters.formatBytesCompact(app.monthBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun drawableToBitmap(drawable: Drawable): ImageBitmap {
    val w = drawable.intrinsicWidth.coerceAtLeast(64)
    val h = drawable.intrinsicHeight.coerceAtLeast(64)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bmp.asImageBitmap()
}
