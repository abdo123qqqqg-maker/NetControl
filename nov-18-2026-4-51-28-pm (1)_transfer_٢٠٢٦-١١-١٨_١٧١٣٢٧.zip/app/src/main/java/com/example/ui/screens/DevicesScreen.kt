package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.DeviceInfo
import com.example.domain.model.Formatters
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.InfoBannerCard
import com.example.ui.components.deviceIconForKey
import com.example.ui.components.formatTimeArabic
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.NetControlUiState

private enum class DeviceFilter(val labelAr: String) {
    ALL("الكل"),
    ONLINE("متصل حاليًا"),
    PREVIOUS("متصلة سابقًا"),
    NEW("أجهزة جديدة")
}

@Composable
fun DevicesScreen(
    state: NetControlUiState,
    onScanNetwork: () -> Unit,
    onOpenDevice: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(DeviceFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredDevices = remember(state.devices, selectedFilter, searchQuery) {
        state.devices.filter { dev ->
            val matchesFilter = when (selectedFilter) {
                DeviceFilter.ALL -> true
                DeviceFilter.ONLINE -> dev.isOnline
                DeviceFilter.PREVIOUS -> !dev.isOnline
                DeviceFilter.NEW -> dev.isNew || !dev.isKnown
            }
            val matchesQuery = searchQuery.isBlank() ||
                dev.displayName.contains(searchQuery, ignoreCase = true) ||
                dev.ipAddress.contains(searchQuery, ignoreCase = true) ||
                dev.macAddress.contains(searchQuery, ignoreCase = true) ||
                dev.manufacturer.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "الأجهزة المتصلة بالراوتر",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.connectedDevicesCount} متصل الآن • ${state.devices.size} إجمالي السجل",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = onScanNetwork,
                    enabled = !state.isScanningLan,
                    modifier = Modifier.testTag("devices_scan_button")
                ) {
                    if (state.isScanningLan) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Rounded.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.size(6.dp))
                    Text(if (state.isScanningLan) "جارٍ الفحص" else "فحص الشبكة")
                }
            }
        }

        if (state.lanScanNote.isNotBlank()) {
            item {
                InfoBannerCard(
                    title = "حالة الاكتشاف الشبكي",
                    body = state.lanScanNote,
                    accentColor = StatusInfo
                )
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("ابحث بالاسم أو IP أو MAC أو الشركة") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DeviceFilter.entries) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.labelAr) }
                    )
                }
            }
        }

        if (filteredDevices.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.Devices,
                    title = "لا توجد أجهزة مطابقة",
                    description = "تأكد من اتصالك بشبكة Wi-Fi ثم اضغط «فحص الشبكة» أو اربط جهاز الراوتر من صفحة الإدارة.",
                    actionLabel = "فحص الشبكة الآن",
                    onAction = onScanNetwork
                )
            }
        } else {
            items(filteredDevices, key = { it.id }) { device ->
                DeviceListCard(
                    device = device,
                    onClick = { onOpenDevice(device.id) }
                )
            }
        }
    }
}

@Composable
private fun DeviceListCard(
    device: DeviceInfo,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("device_card_${device.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                if (!device.customAvatarUri.isNullOrBlank()) {
                    AsyncImage(
                        model = device.customAvatarUri,
                        contentDescription = device.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = deviceIconForKey(device.iconKey),
                        contentDescription = device.displayName,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = device.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (device.isNew && !device.isKnown) {
                        StatusChipBadge("جديد", StatusWarning)
                    }
                    if (device.isBlocked) {
                        StatusChipBadge("محظور", StatusDanger)
                    }
                }
                Text(
                    text = "${device.ipAddress}  •  ${device.manufacturer}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "MAC: ${device.macAddress}  •  آخر اتصال: ${formatTimeArabic(device.lastSeenMillis)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = (if (device.isOnline) StatusOnline else MaterialTheme.colorScheme.outline).copy(alpha = 0.16f)
                ) {
                    Text(
                        text = if (device.isOnline) "متصل" else "سابق",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (device.isOnline) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                if (device.monthBytes > 0L) {
                    Text(
                        text = Formatters.formatBytesCompact(device.monthBytes),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (device.isBlocked) {
                    Icon(
                        imageVector = Icons.Rounded.Block,
                        contentDescription = "محظور",
                        tint = StatusDanger,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusChipBadge(label: String, color: androidx.compose.ui.graphics.Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.16f)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
