package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.DeviceIconKey
import com.example.domain.model.Formatters
import com.example.ui.components.InfoBannerCard
import com.example.ui.components.deviceIconForKey
import com.example.ui.components.formatTimeArabic
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.NetControlUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeviceDetailsScreen(
    deviceId: String,
    state: NetControlUiState,
    onBack: () -> Unit,
    onSaveCustomization: (String, String, DeviceIconKey, String?, Boolean) -> Unit,
    onToggleBlock: (com.example.domain.model.DeviceInfo, Boolean) -> Unit,
    onRestartConnection: () -> Unit,
    onNavigateToQuota: () -> Unit,
    onNavigateToSpeed: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val device = state.devices.firstOrNull { it.id == deviceId }
    if (device == null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("لم يتم العثور على بيانات هذا الجهاز", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.size(12.dp))
            Button(onClick = onBack) { Text("رجوع") }
        }
        return
    }

    var customName by remember(device.id, device.customName) { mutableStateOf(device.customName) }
    var selectedIcon by remember(device.id, device.iconKey) { mutableStateOf(device.iconKey) }
    var avatarUri by remember(device.id, device.customAvatarUri) { mutableStateOf(device.customAvatarUri) }
    var isKnown by remember(device.id, device.isKnown) { mutableStateOf(device.isKnown) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) avatarUri = uri.toString()
    }

    val routerSupportsBlock = state.routerProfile.capabilities.supportsDeviceBlocking ||
        state.routerProfile.gatewayAgentConnected

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("device_details_back")) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "رجوع")
                }
                Text(
                    text = "تفاصيل الجهاز",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Device Identity Header
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!avatarUri.isNullOrBlank()) {
                            AsyncImage(
                                model = avatarUri,
                                contentDescription = device.displayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = deviceIconForKey(selectedIcon),
                                contentDescription = device.displayName,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = device.displayName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "الاسم الأصلي: ${device.originalName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (device.isOnline) "متصل حاليًا" else "غير متصل (اتصال سابق)",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (device.isOnline) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Network & Usage Stats
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("معلومات الشبكة والاستهلاك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    DetailRow("عنوان IP", device.ipAddress)
                    DetailRow("عنوان MAC", device.macAddress)
                    DetailRow("نوع الجهاز", device.deviceType.labelAr)
                    DetailRow("الشركة المصنعة", device.manufacturer)
                    DetailRow("مصدر البيانات", device.sourceLabelAr)
                    DetailRow("إجمالي الاستهلاك", Formatters.formatBytes(device.totalBytes))
                    DetailRow("استهلاك التحميل", Formatters.formatBytes(device.downloadBytes))
                    DetailRow("استهلاك الرفع", Formatters.formatBytes(device.uploadBytes))
                    DetailRow("استهلاك اليوم", Formatters.formatBytes(device.todayBytes))
                    DetailRow("استهلاك الأسبوع", Formatters.formatBytes(device.weekBytes))
                    DetailRow("استهلاك الشهر", Formatters.formatBytes(device.monthBytes))
                    DetailRow("السرعة الحالية (تحميل / رفع)", "${Formatters.formatSpeedBps(device.currentDownloadBps)} / ${Formatters.formatSpeedBps(device.currentUploadBps)}")
                    DetailRow("آخر وقت اتصال", formatTimeArabic(device.lastSeenMillis))
                }
            }
        }

        // Customization Section
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("تخصيص اسم وصورة الجهاز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("الاسم المخصص (مثال: هاتف أحمد)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("device_custom_name_input")
                    )

                    Text("أيقونة الجهاز:", style = MaterialTheme.typography.labelLarge)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DeviceIconKey.entries.forEach { key ->
                            FilterChip(
                                selected = selectedIcon == key,
                                onClick = { selectedIcon = key },
                                leadingIcon = {
                                    Icon(deviceIconForKey(key), contentDescription = key.labelAr, modifier = Modifier.size(16.dp))
                                },
                                label = { Text(key.labelAr) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("تصنيف كجهاز معروف وموثوق", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = isKnown, onCheckedChange = { isKnown = it })
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("اختيار صورة")
                        }
                        Button(
                            onClick = {
                                onSaveCustomization(device.id, customName, selectedIcon, avatarUri, isKnown)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("device_save_customization")
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("حفظ التعديلات")
                        }
                    }
                }
            }
        }

        // Router Controls for this device
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("التحكم المباشر بالجهاز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (!routerSupportsBlock) {
                        InfoBannerCard(
                            title = "تنبيه التوافق مع الراوتر",
                            body = "الراوتر الحالي لا يدعم إيقاف أو حظر الأجهزة مباشرة عبر API. اربط راوتر OpenWrt / MikroTik أو وسيط الشبكة المحلي لتفعيل الأزرار التالية فعليًا.",
                            accentColor = StatusWarning
                        )
                    }
                    Button(
                        onClick = { onToggleBlock(device, !device.isBlocked) },
                        enabled = routerSupportsBlock,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (device.isBlocked) StatusOnline else StatusDanger
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("device_toggle_block")
                    ) {
                        Icon(
                            if (device.isBlocked) Icons.Rounded.CheckCircle else Icons.Rounded.Block,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.size(8.dp))
                        Text(if (device.isBlocked) "السماح بالاتصال وإزالة الحظر" else "إيقاف وحظر الإنترنت عن هذا الجهاز")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onNavigateToQuota,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.PieChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("تحديد حصة")
                        }
                        OutlinedButton(
                            onClick = onNavigateToSpeed,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("تحديد السرعة")
                        }
                    }

                    OutlinedButton(
                        onClick = onRestartConnection,
                        enabled = state.routerProfile.capabilities.supportsConnectionRestart || state.routerProfile.gatewayAgentConnected,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("إعادة تشغيل اتصال الراوتر (WAN)")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
