package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.ConnectionStatus
import com.example.domain.model.Formatters
import com.example.domain.model.UsageChartPeriod
import com.example.ui.components.InfoBannerCard
import com.example.ui.components.InteractiveTrafficChart
import com.example.ui.components.MetricStatCard
import com.example.ui.components.QuotaRingGauge
import com.example.ui.theme.DownloadColor
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusOnline
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.UploadColor
import com.example.ui.viewmodel.NetControlUiState

@Composable
fun DashboardScreen(
    state: NetControlUiState,
    onRefresh: () -> Unit,
    onRequestUsageAccess: () -> Unit,
    onSelectChartPeriod: (UsageChartPeriod) -> Unit,
    onNavigateToQuota: () -> Unit,
    onNavigateToRouter: () -> Unit,
    onNavigateToDevices: () -> Unit,
    onNavigateToApps: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val live = state.liveConnection
    val isOnline = live.status == ConnectionStatus.WIFI_ONLINE ||
        live.status == ConnectionStatus.CELLULAR_ONLINE ||
        live.status == ConnectionStatus.ETHERNET_ONLINE
    val statusColor = when (live.status) {
        ConnectionStatus.WIFI_ONLINE, ConnectionStatus.CELLULAR_ONLINE, ConnectionStatus.ETHERNET_ONLINE -> StatusOnline
        ConnectionStatus.LIMITED -> StatusWarning
        ConnectionStatus.OFFLINE -> StatusDanger
    }

    val planBytes = (state.settings.totalMonthlyPlanGb * 1024.0 * 1024.0 * 1024.0).toLong().coerceAtLeast(1L)
    val usedPercent = ((state.totalMonthUsedBytes.toDouble() / planBytes.toDouble()) * 100.0).toFloat()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Network Status Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_network_hero_1795012806595),
                        contentDescription = "خلفية حالة الشبكة",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xB807111E),
                                        Color(0xE8081424)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = statusColor.copy(alpha = 0.22f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(statusColor)
                                        )
                                        Text(
                                            text = live.status.labelAr,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            IconButton(
                                onClick = onRefresh,
                                modifier = Modifier.testTag("dashboard_refresh_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "تحديث القراءات",
                                    tint = Color.White
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = live.networkName,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "IP المحلي: ${live.localIp}  •  الراوتر: ${live.gatewayIp}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFCBD5E1)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SpeedPill(
                                label = "سرعة التحميل",
                                value = Formatters.formatSpeedBps(live.downloadBps),
                                icon = Icons.Rounded.ArrowDownward,
                                color = DownloadColor,
                                modifier = Modifier.weight(1f)
                            )
                            SpeedPill(
                                label = "سرعة الرفع",
                                value = Formatters.formatSpeedBps(live.uploadBps),
                                icon = Icons.Rounded.ArrowUpward,
                                color = UploadColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Permission Prompt for Real Android App/Data Usage
        if (!state.hasUsagePermission) {
            item {
                InfoBannerCard(
                    title = "تفعيل صلاحية إحصائيات الاستخدام",
                    body = "لعرض استهلاك الإنترنت الحقيقي لليوم والأسبوع والشهر ولكل تطبيق على هذا الهاتف، امنح صلاحية «الوصول إلى بيانات الاستخدام» من إعدادات النظام.",
                    accentColor = StatusWarning,
                    actionLabel = "منح الصلاحية الآن",
                    onActionClick = onRequestUsageAccess
                )
            }
        }

        // Plan Remaining Gauge + Monthly Summary Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    QuotaRingGauge(
                        percent = usedPercent,
                        centerLabel = "${usedPercent.toInt()}%",
                        subLabel = "مستهلك"
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "حالة الباقة الشهرية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المتبقي: ${Formatters.formatBytes(state.remainingPlanBytes)}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المستهلك هذا الشهر: ${Formatters.formatBytes(state.totalMonthUsedBytes)} من ${state.settings.totalMonthlyPlanGb.toInt()} جيجابايت",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = onNavigateToQuota,
                            modifier = Modifier.testTag("dashboard_open_quota_button")
                        ) {
                            Icon(Icons.Rounded.PieChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("التوزيع الذكي")
                        }
                    }
                }
            }
        }

        // KPI Grid (All 10 Dashboard Metrics Covered)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricStatCard(
                        title = "استهلاك اليوم",
                        value = Formatters.formatBytes(live.phoneTodayBytes),
                        subtitle = if (state.hasUsagePermission) "من إحصائيات النظام" else "بانتظار الصلاحية",
                        icon = Icons.Rounded.Today,
                        accentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "هذا الأسبوع",
                        value = Formatters.formatBytes(live.phoneWeekBytes),
                        subtitle = "إجمالي الأسبوع الحالي",
                        icon = Icons.Rounded.DateRange,
                        accentColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricStatCard(
                        title = "هذا الشهر",
                        value = Formatters.formatBytes(state.totalMonthUsedBytes),
                        subtitle = "الشهر الجاري",
                        icon = Icons.Rounded.CalendarMonth,
                        accentColor = DownloadColor,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "الأجهزة المتصلة",
                        value = "${state.connectedDevicesCount}",
                        subtitle = "من إجمالي ${state.devices.size} مسجل",
                        icon = Icons.Rounded.Devices,
                        accentColor = StatusOnline,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onNavigateToDevices)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricStatCard(
                        title = "الأكثر استهلاكًا (جهاز)",
                        value = state.topDevice?.displayName ?: "لا توجد بيانات",
                        subtitle = state.topDevice?.let { Formatters.formatBytes(it.monthBytes) } ?: "افحص الشبكة أو اربط الراوتر",
                        icon = Icons.Rounded.Router,
                        accentColor = StatusWarning,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onNavigateToDevices)
                    )
                    MetricStatCard(
                        title = "الأكثر استهلاكًا (تطبيق)",
                        value = state.topApp?.appName ?: "لا توجد بيانات",
                        subtitle = state.topApp?.let { Formatters.formatBytes(it.monthBytes) } ?: "على هذا الهاتف",
                        icon = Icons.Rounded.Apps,
                        accentColor = UploadColor,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onNavigateToApps)
                    )
                }
            }
        }

        // Interactive Consumption Chart (Daily / Weekly / Monthly)
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الرسم البياني للاستهلاك",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            UsageChartPeriod.entries.forEach { period ->
                                FilterChip(
                                    selected = state.chartPeriod == period,
                                    onClick = { onSelectChartPeriod(period) },
                                    label = { Text(period.labelAr) }
                                )
                            }
                        }
                    }
                    InteractiveTrafficChart(data = state.chartData)
                }
            }
        }

        // Router Status Quick Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isOnline) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                                contentDescription = "الراوتر",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column {
                            Text(
                                text = if (state.routerProfile.isConnected) "${state.routerProfile.manufacturer} • ${state.routerProfile.modelName}" else "الراوتر غير مربوط بعد",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = state.routerProfile.statusMessageAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                        }
                    }
                    Button(
                        onClick = onNavigateToRouter,
                        modifier = Modifier.testTag("dashboard_router_setup_button")
                    ) {
                        Text(if (state.routerProfile.isConnected) "إدارة" else "ربط")
                    }
                }
            }
        }
    }
}

@Composable
private fun SpeedPill(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.10f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(18.dp))
            Column {
                Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color(0xFFCBD5E1))
                Text(text = value, style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
