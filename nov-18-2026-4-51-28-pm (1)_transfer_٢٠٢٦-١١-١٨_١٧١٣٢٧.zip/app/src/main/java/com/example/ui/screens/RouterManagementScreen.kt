package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.RouterVendor
import com.example.ui.components.InfoBannerCard
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusOnline
import com.example.ui.viewmodel.NetControlUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouterManagementScreen(
    state: NetControlUiState,
    onAutoDetect: (String, (RouterVendor) -> Unit) -> Unit,
    onConnectRouter: (RouterVendor, String, Int, Boolean, String, String, String, String) -> Unit,
    onRestartWan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profile = state.routerProfile
    val detectedGateway = state.liveConnection.gatewayIp.takeIf { it != "—" } ?: profile.hostIp

    var selectedVendor by remember(profile.vendor) { mutableStateOf(profile.vendor) }
    var hostIp by remember(profile.hostIp, detectedGateway) {
        mutableStateOf(if (profile.isConnected) profile.hostIp else detectedGateway)
    }
    var portText by remember(profile.port) { mutableStateOf(profile.port.toString()) }
    var useHttps by remember(profile.useHttps) { mutableStateOf(profile.useHttps) }
    var username by remember(profile.username) { mutableStateOf(profile.username) }
    var password by remember { mutableStateOf("") }
    var gatewayUrl by remember(profile.gatewayAgentUrl) { mutableStateOf(profile.gatewayAgentUrl) }
    var gatewayToken by remember { mutableStateOf("") }
    var vendorMenuExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "إدارة وتكامل الراوتر",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "اتصال مرن متعدد البروتوكولات: OpenWrt ubus، MikroTik REST، Huawei HiLink، TR-064/UPnP، أو وسيط الشبكة",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Current Router Identity & Status Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Router,
                            contentDescription = "الراوتر",
                            tint = if (profile.isConnected) StatusOnline else MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(
                                text = if (profile.isConnected) "${profile.manufacturer} — ${profile.modelName}" else "لم يتم الاتصال براوتر بعد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "IP: ${profile.hostIp}  •  ${if (profile.isConnected) "متصل (${profile.protocol.labelAr})" else "غير متصل"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (profile.isConnected) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        text = profile.statusMessageAr,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (profile.isConnected && profile.capabilities.supportsConnectionRestart) {
                        OutlinedButton(
                            onClick = onRestartWan,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("إعادة تشغيل اتصال WAN")
                        }
                    }
                }
            }
        }

        // Connection Setup Form
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("إعدادات الاتصال بالراوتر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    ExposedDropdownMenuBox(
                        expanded = vendorMenuExpanded,
                        onExpandedChange = { vendorMenuExpanded = !vendorMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedVendor.displayNameAr,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("نوع الراوتر / البروتوكول") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vendorMenuExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = vendorMenuExpanded,
                            onDismissRequest = { vendorMenuExpanded = false }
                        ) {
                            RouterVendor.entries.forEach { v ->
                                DropdownMenuItem(
                                    text = { Text(v.displayNameAr) },
                                    onClick = {
                                        selectedVendor = v
                                        portText = (v.defaultPorts.firstOrNull() ?: 80).toString()
                                        vendorMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = hostIp,
                            onValueChange = { hostIp = it },
                            label = { Text("عنوان IP للراوتر") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(2f)
                                .testTag("router_ip_input")
                        )
                        OutlinedTextField(
                            value = portText,
                            onValueChange = { if (it.all(Char::isDigit)) portText = it },
                            label = { Text("المنفذ") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("استخدام اتصال مشفر HTTPS", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = useHttps,
                            onCheckedChange = {
                                useHttps = it
                                if (it && portText == "80") portText = "443"
                                if (!it && portText == "443") portText = "80"
                            }
                        )
                    }

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم المستخدم") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور (تُشفّر محليًا بـ Android Keystore)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (selectedVendor == RouterVendor.GATEWAY_AGENT) {
                        OutlinedTextField(
                            value = gatewayUrl,
                            onValueChange = { gatewayUrl = it },
                            label = { Text("رابط وسيط الشبكة (مثال: http://192.168.1.2:8090)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = gatewayToken,
                            onValueChange = { gatewayToken = it },
                            label = { Text("رمز المصادقة (Bearer Token)") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = {
                                onAutoDetect(hostIp) { detected ->
                                    selectedVendor = detected
                                    portText = (detected.defaultPorts.firstOrNull() ?: 80).toString()
                                }
                            },
                            enabled = !state.isConnectingRouter,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("router_autodetect_button")
                        ) {
                            Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(4.dp))
                            Text("اكتشاف تلقائي")
                        }

                        Button(
                            onClick = {
                                onConnectRouter(
                                    selectedVendor,
                                    hostIp,
                                    portText.toIntOrNull() ?: 80,
                                    useHttps,
                                    username,
                                    password,
                                    gatewayUrl,
                                    gatewayToken
                                )
                            },
                            enabled = !state.isConnectingRouter && hostIp.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("router_connect_button")
                        ) {
                            if (state.isConnectingRouter) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Rounded.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                            Spacer(Modifier.size(4.dp))
                            Text("اتصال وفحص")
                        }
                    }
                }
            }
        }

        // Supported vs Unsupported Capabilities Matrix
        val caps = if (profile.isConnected) profile.capabilities else state.routerProfile.capabilities
        if (caps.supportedFeaturesAr.isNotEmpty() || caps.unsupportedFeaturesAr.isNotEmpty() || caps.technicalNoteAr.isNotBlank()) {
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("مصفوفة دعم الميزات الفعلية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (caps.supportedFeaturesAr.isNotEmpty()) {
                            Text("الميزات المدعومة:", style = MaterialTheme.typography.labelLarge, color = StatusOnline)
                            caps.supportedFeaturesAr.forEach { feat ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = StatusOnline, modifier = Modifier.size(16.dp))
                                    Text(feat, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (caps.unsupportedFeaturesAr.isNotEmpty()) {
                            Text("الميزات غير المدعومة مباشرة:", style = MaterialTheme.typography.labelLarge, color = StatusDanger)
                            caps.unsupportedFeaturesAr.forEach { feat ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Cancel, contentDescription = null, tint = StatusDanger, modifier = Modifier.size(16.dp))
                                    Text(feat, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (caps.technicalNoteAr.isNotBlank()) {
                            InfoBannerCard(
                                title = "ملاحظة تقنية / الوسيط المحلي",
                                body = caps.technicalNoteAr,
                                accentColor = StatusInfo
                            )
                        }
                    }
                }
            }
        }
    }
}
