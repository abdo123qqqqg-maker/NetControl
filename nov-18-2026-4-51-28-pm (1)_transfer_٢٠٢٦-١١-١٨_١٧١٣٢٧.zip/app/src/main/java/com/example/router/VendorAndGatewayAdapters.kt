package com.example.router

import com.example.core.network.LanScannerEngine
import com.example.domain.model.DeviceInfo
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Adapter for NetControl Local Network Gateway Agent (Raspberry Pi / OpenWrt / Linux box on LAN)
 * which exposes REST endpoints backed by nftables (quotas & blocking) and Linux tc (per-IP bandwidth shaping).
 */
class NetControlGatewayAdapter : RouterAdapter {
    override val vendor: RouterVendor = RouterVendor.GATEWAY_AGENT
    override val protocol: RouterProtocol = RouterProtocol.GATEWAY_REST

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    override fun capabilities() = RouterCapabilities(
        supportsDeviceList = true,
        supportsPerDeviceTraffic = true,
        supportsQuotaEnforcement = true,
        supportsSpeedLimiting = true,
        supportsDeviceBlocking = true,
        supportsConnectionRestart = true,
        supportsLiveBandwidth = true,
        supportedFeaturesAr = listOf(
            "مراقبة استهلاك كل جهاز بالبايت لحظيًا (nftables)",
            "التحكم الفعلي بسرعة التحميل والرفع لكل جهاز (Linux tc)",
            "تنفيذ حصص التوزيع الذكي وإيقاف الإنترنت تلقائيًا",
            "حظر وفك حظر الأجهزة فورًا"
        ),
        unsupportedFeaturesAr = emptyList(),
        technicalNoteAr = "وسيط الشبكة المحلي يمنحك تحكمًا كاملاً في الحصص والسرعة حتى لو كان الراوتر الأساسي من مزود الخدمة لا يدعم ذلك."
    )

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)
            val req = Request.Builder()
                .url("$baseUrl/api/v1/status")
                .apply { if (password.isNotBlank()) header("Authorization", "Bearer $password") }
                .get()
                .build()

            val statusJson = client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) throw IllegalStateException("لم يستجب وسيط الشبكة المحلي على $baseUrl (رمز ${res.code}).")
                JSONObject(res.body?.string() ?: "{}")
            }

            val devices = fetchGatewayDevices(client, baseUrl, password)
            val profile = RouterProfile(
                vendor = RouterVendor.GATEWAY_AGENT,
                protocol = RouterProtocol.GATEWAY_REST,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = "NetControl Gateway",
                modelName = statusJson.optString("hostname", "بوابة الشبكة المحلية"),
                firmwareVersion = statusJson.optString("version", "1.0"),
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "متصل بوسيط الشبكة المحلي — جميع ميزات التحكم مفعلة",
                capabilities = capabilities(),
                gatewayAgentUrl = baseUrl,
                gatewayAgentConnected = true
            )
            RouterSyncSnapshot(profile = profile, devices = devices)
        }
    }

    override suspend fun fetchDevices(profile: RouterProfile, password: String): Result<List<DeviceInfo>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
                val client = RouterHttpClients.buildClient(profile.useHttps)
                fetchGatewayDevices(client, baseUrl, password)
            }
        }

    override suspend fun setDeviceBlocked(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        blocked: Boolean
    ): RouterControlResult = withContext(Dispatchers.IO) {
        postAction(profile, password, "/api/v1/devices/block", JSONObject().apply {
            put("ip", device.ipAddress)
            put("mac", device.macAddress)
            put("blocked", blocked)
        }, if (blocked) "تم إيقاف الإنترنت عن ${device.displayName} عبر الوسيط." else "تم إعادة الاتصال لـ ${device.displayName}.")
    }

    override suspend fun setDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float
    ): RouterControlResult = withContext(Dispatchers.IO) {
        postAction(profile, password, "/api/v1/devices/speed-limit", JSONObject().apply {
            put("ip", device.ipAddress)
            put("downloadMbps", maxDownloadMbps)
            put("uploadMbps", maxUploadMbps)
        }, "تم تطبيق حد السرعة (${maxDownloadMbps} / ${maxUploadMbps} ميجابت/ث) عبر الوسيط.")
    }

    override suspend fun clearDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo
    ): RouterControlResult = setDeviceSpeedLimit(profile, password, device, 0f, 0f)

    override suspend fun restartWanConnection(
        profile: RouterProfile,
        password: String
    ): RouterControlResult = withContext(Dispatchers.IO) {
        postAction(profile, password, "/api/v1/wan/restart", JSONObject(), "تم إرسال أمر إعادة تشغيل الاتصال عبر الوسيط.")
    }

    private fun postAction(
        profile: RouterProfile,
        password: String,
        path: String,
        payload: JSONObject,
        successMsg: String
    ): RouterControlResult = runCatching {
        val baseUrl = profile.gatewayAgentUrl.ifBlank {
            RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
        }
        val client = RouterHttpClients.buildClient(profile.useHttps)
        val req = Request.Builder()
            .url("$baseUrl$path")
            .apply { if (password.isNotBlank()) header("Authorization", "Bearer $password") }
            .post(payload.toString().toRequestBody(jsonMedia))
            .build()
        client.newCall(req).execute().use { res ->
            if (res.isSuccessful) RouterControlResult(true, successMsg)
            else RouterControlResult(false, "فشل تنفيذ الأمر على الوسيط (رمز ${res.code}).")
        }
    }.getOrElse {
        RouterControlResult(false, "تعذر الاتصال بوسيط الشبكة: ${it.localizedMessage}", requiresGatewayAgent = true)
    }

    private fun fetchGatewayDevices(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        token: String
    ): List<DeviceInfo> {
        val req = Request.Builder()
            .url("$baseUrl/api/v1/devices")
            .apply { if (token.isNotBlank()) header("Authorization", "Bearer $token") }
            .get()
            .build()
        val body = client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) return emptyList()
            res.body?.string().orEmpty()
        }
        val arr = JSONArray(body.ifBlank { "[]" })
        val now = System.currentTimeMillis()
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val ip = obj.optString("ip")
                val mac = obj.optString("mac").uppercase()
                val name = obj.optString("hostname").ifBlank { "جهاز ($ip)" }
                val vendor = LanScannerEngine.lookupOuiVendor(mac)
                val type = LanScannerEngine.inferDeviceType(vendor, name)
                val dl = obj.optLong("downloadBytes", 0L)
                val ul = obj.optLong("uploadBytes", 0L)
                add(
                    DeviceInfo(
                        id = if (mac.isNotBlank()) "mac:$mac" else "ip:$ip",
                        originalName = name,
                        customName = "",
                        ipAddress = ip,
                        macAddress = mac.ifBlank { "—" },
                        deviceType = type,
                        manufacturer = vendor,
                        isOnline = obj.optBoolean("online", true),
                        isKnown = false,
                        isNew = true,
                        isBlocked = obj.optBoolean("blocked", false),
                        isPaused = obj.optBoolean("paused", false),
                        iconKey = LanScannerEngine.iconForDeviceType(type),
                        totalBytes = dl + ul,
                        downloadBytes = dl,
                        uploadBytes = ul,
                        todayBytes = obj.optLong("todayBytes", dl + ul),
                        weekBytes = obj.optLong("weekBytes", dl + ul),
                        monthBytes = obj.optLong("monthBytes", dl + ul),
                        currentDownloadBps = obj.optLong("downloadBps", 0L),
                        currentUploadBps = obj.optLong("uploadBps", 0L),
                        lastSeenMillis = now,
                        sourceLabelAr = "وسيط الشبكة المحلي"
                    )
                )
            }
        }
    }
}

/**
 * TR-064 / UPnP IGD Adapter for ISP & Consumer Routers supporting TR-064 (port 49000) or UPnP XML descriptions.
 */
class Tr064UpnpAdapter : RouterAdapter {
    override val vendor: RouterVendor = RouterVendor.TR064_UPNP
    override val protocol: RouterProtocol = RouterProtocol.TR064_SOAP

    override fun capabilities() = RouterCapabilities(
        supportsDeviceList = true,
        supportsPerDeviceTraffic = false,
        supportsQuotaEnforcement = false,
        supportsSpeedLimiting = false,
        supportsDeviceBlocking = false,
        supportsConnectionRestart = false,
        supportsLiveBandwidth = true,
        supportedFeaturesAr = listOf(
            "اكتشاف اسم وموديل الراوتر عبر XML/UPnP",
            "قراءة عدادات التحميل والرفع الإجمالية للـ WAN",
            "قراءة قائمة الأجهزة عبر TR-064 Hosts عند توفرها"
        ),
        unsupportedFeaturesAr = listOf(
            "التحكم في سرعة كل جهاز أو توزيع حصص الجيجابايت (غير متاح في معيار UPnP/TR-064 العام)"
        ),
        technicalNoteAr = "بروتوكول TR-064 / UPnP يوفر معلومات الراوتر وإجمالي البايتات، بينما يتطلب التحكم الدقيق في الأجهزة استخدام OpenWrt أو MikroTik أو وسيط الشبكة المحلي."
    )

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)
            val paths = listOf("/tr64/tr64desc.xml", "/gatedesc.xml", "/igd.xml", "/rootDesc.xml")
            var xml = ""
            for (p in paths) {
                val attempt = runCatching {
                    client.newCall(Request.Builder().url("$baseUrl$p").get().build()).execute().use { res ->
                        if (res.isSuccessful) res.body?.string().orEmpty() else ""
                    }
                }.getOrDefault("")
                if (attempt.contains("<device>", ignoreCase = true)) {
                    xml = attempt
                    break
                }
            }
            if (xml.isBlank()) throw IllegalStateException("لم يتم العثور على وصف TR-064 أو UPnP XML على المنفذ $port.")

            val manufacturer = extractTag(xml, "manufacturer").ifBlank { "راوتر متوافق مع UPnP/TR-064" }
            val model = extractTag(xml, "modelName").ifBlank { extractTag(xml, "friendlyName").ifBlank { "بوابة شبكية" } }
            val fw = extractTag(xml, "modelNumber").ifBlank { "TR-064 / IGD" }

            val profile = RouterProfile(
                vendor = RouterVendor.TR064_UPNP,
                protocol = RouterProtocol.TR064_SOAP,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = manufacturer,
                modelName = model,
                firmwareVersion = fw,
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "تم التعرف على الراوتر عبر TR-064 / UPnP ($manufacturer)",
                capabilities = capabilities()
            )
            RouterSyncSnapshot(profile = profile, devices = emptyList())
        }
    }

    override suspend fun fetchDevices(profile: RouterProfile, password: String): Result<List<DeviceInfo>> =
        Result.success(emptyList())

    override suspend fun setDeviceBlocked(profile: RouterProfile, password: String, device: DeviceInfo, blocked: Boolean) =
        RouterControlResult(false, "بروتوكول UPnP/TR-064 العام لا يدعم حظر الأجهزة؛ اربط وسيط الشبكة المحلي.", requiresGatewayAgent = true)

    override suspend fun setDeviceSpeedLimit(profile: RouterProfile, password: String, device: DeviceInfo, maxDownloadMbps: Float, maxUploadMbps: Float) =
        RouterControlResult(false, "بروتوكول UPnP/TR-064 لا يدعم تحديد السرعة لكل جهاز؛ اربط وسيط الشبكة المحلي.", requiresGatewayAgent = true)

    override suspend fun clearDeviceSpeedLimit(profile: RouterProfile, password: String, device: DeviceInfo) =
        setDeviceSpeedLimit(profile, password, device, 0f, 0f)

    override suspend fun restartWanConnection(profile: RouterProfile, password: String) =
        RouterControlResult(false, "إعادة تشغيل WAN عبر TR-064 تتطلب مصادقة Digest الخاصة بالشركة المصنعة.")

    private fun extractTag(xml: String, tag: String): String {
        val m = Regex("<$tag>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(xml)
        return m?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }
}

/**
 * Real HTTP Probe & Capability Matrix for TP-Link, ASUS, ZTE, and Tenda Consumer Routers.
 * Strictly follows truthfulness guidelines: probes real web admin headers/titles and exposes
 * exact supported vs unsupported features without faking non-existent API control.
 */
class VendorHttpFingerprintAdapter(override val vendor: RouterVendor) : RouterAdapter {
    override val protocol: RouterProtocol = RouterProtocol.VENDOR_HTTP

    override fun capabilities(): RouterCapabilities {
        val vendorName = vendor.displayNameAr
        return RouterCapabilities(
            supportsDeviceList = false,
            supportsPerDeviceTraffic = false,
            supportsQuotaEnforcement = false,
            supportsSpeedLimiting = false,
            supportsDeviceBlocking = false,
            supportsConnectionRestart = false,
            supportsLiveBandwidth = false,
            supportedFeaturesAr = listOf(
                "التحقق من وصول واجهة إدارة $vendorName على الشبكة المحلية",
                "مراقبة استهلاك هذا الهاتف والأجهزة المكتشفة عبر فحص الشبكة"
            ),
            unsupportedFeaturesAr = listOf(
                "لا توفر البرامج الأصلية لمعظم موديلات $vendorName واجهة API موحدة لتوزيع الجيجابايت أو قراءة استهلاك كل جهاز",
                "تحديد السرعة وحظر الأجهزة برمجيًا يتطلب وسيط الشبكة المحلي أو راوتر OpenWrt / MikroTik"
            ),
            technicalNoteAr = "أجهزة $vendorName المنزلية تستخدم واجهات ويب مشفرة ومختلفة من موديل لآخر. للحصول على توزيع الحصص وتحديد السرعة الفعلي لكل جهاز، اربط وسيط الشبكة المحلي (Gateway)."
        )
    }

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)
            val req = Request.Builder().url(baseUrl).get().build()
            val (title, serverHeader) = client.newCall(req).execute().use { res ->
                val html = res.body?.string().orEmpty().take(4096)
                val t = Regex("<title>(.*?)</title>", RegexOption.IGNORE_CASE)
                    .find(html)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val srv = res.header("Server").orEmpty()
                t to srv
            }

            val detectedModel = title.ifBlank { serverHeader.ifBlank { "${vendor.displayNameAr} ($hostIp)" } }
            val profile = RouterProfile(
                vendor = vendor,
                protocol = RouterProtocol.VENDOR_HTTP,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = vendor.displayNameAr,
                modelName = detectedModel,
                firmwareVersion = "واجهة الويب المحلية",
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "تم الوصول إلى واجهة ${vendor.displayNameAr}. الميزات المتقدمة تتطلب وسيطًا محليًا إذا لم يدعمها الموديل.",
                capabilities = capabilities()
            )
            RouterSyncSnapshot(profile = profile, devices = emptyList())
        }
    }

    override suspend fun fetchDevices(profile: RouterProfile, password: String): Result<List<DeviceInfo>> =
        Result.success(emptyList())

    override suspend fun setDeviceBlocked(profile: RouterProfile, password: String, device: DeviceInfo, blocked: Boolean) =
        RouterControlResult(
            success = false,
            messageAr = "هذا الموديل من ${vendor.displayNameAr} لا يوفر واجهة تحكم برمجية مفتوحة للحظر. فعّل وسيط الشبكة المحلي لتنفيذ الحظر الفعلي.",
            requiresGatewayAgent = true
        )

    override suspend fun setDeviceSpeedLimit(profile: RouterProfile, password: String, device: DeviceInfo, maxDownloadMbps: Float, maxUploadMbps: Float) =
        RouterControlResult(
            success = false,
            messageAr = "تحديد سرعة كل جهاز غير مدعوم مباشرة في واجهة ${vendor.displayNameAr} هذه؛ استخدم وسيط الشبكة المحلي (Gateway).",
            requiresGatewayAgent = true
        )

    override suspend fun clearDeviceSpeedLimit(profile: RouterProfile, password: String, device: DeviceInfo) =
        setDeviceSpeedLimit(profile, password, device, 0f, 0f)

    override suspend fun restartWanConnection(profile: RouterProfile, password: String) =
        RouterControlResult(
            success = false,
            messageAr = "يرجى إعادة تشغيل الراوتر من لوحة التحكم الرسمية (${profile.hostIp}) أو عبر وسيط الشبكة.",
            requiresGatewayAgent = true
        )
}
