package com.example.router

import com.example.core.network.LanScannerEngine
import com.example.domain.model.DeviceInfo
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class OpenWrtUbusAdapter : RouterAdapter {
    override val vendor: RouterVendor = RouterVendor.OPENWRT
    override val protocol: RouterProtocol = RouterProtocol.UBUS_RPC

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    override fun capabilities() = RouterCapabilities(
        supportsDeviceList = true,
        supportsPerDeviceTraffic = true,
        supportsQuotaEnforcement = true,
        supportsSpeedLimiting = true,
        supportsDeviceBlocking = true,
        supportsConnectionRestart = true,
        supportsLiveBandwidth = true,
        supportedFeaturesAr = listOf(
            "قائمة الأجهزة وعناوين MAC/IP عبر ubus",
            "قياس استهلاك كل جهاز (مع nlbwmon / nftables)",
            "تحديد السرعة عبر SQM / tc",
            "حظر أو إيقاف اتصال أي جهاز عبر جدار الحماية",
            "إعادة تشغيل اتصال WAN"
        ),
        unsupportedFeaturesAr = emptyList(),
        technicalNoteAr = "يتطلب تفعيل uhttpd-mod-ubus وصلاحيات RPC للمستخدم على OpenWrt."
    )

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)
            val sessionId = loginUbus(client, baseUrl, username, password)
                ?: throw IllegalStateException("تعذر تسجيل الدخول عبر OpenWrt ubus. تأكد من اسم المستخدم وكلمة المرور وتفعيل ubus.")

            val boardInfo = callUbus(client, baseUrl, sessionId, "system", "board", JSONObject())
            val model = boardInfo?.optString("model").orEmpty().ifBlank { "جهاز OpenWrt" }
            val release = boardInfo?.optJSONObject("release")
            val fw = release?.optString("description").orEmpty().ifBlank { "OpenWrt" }

            val devices = fetchUbusHosts(client, baseUrl, sessionId)
            val profile = RouterProfile(
                vendor = RouterVendor.OPENWRT,
                protocol = RouterProtocol.UBUS_RPC,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = "OpenWrt",
                modelName = model,
                firmwareVersion = fw,
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "متصل بنجاح عبر OpenWrt ubus RPC",
                capabilities = capabilities()
            )
            RouterSyncSnapshot(profile = profile, devices = devices)
        }
    }

    override suspend fun fetchDevices(
        profile: RouterProfile,
        password: String
    ): Result<List<DeviceInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val sessionId = loginUbus(client, baseUrl, profile.username, password)
                ?: throw IllegalStateException("انتهت جلسة OpenWrt")
            fetchUbusHosts(client, baseUrl, sessionId)
        }
    }

    override suspend fun setDeviceBlocked(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        blocked: Boolean
    ): RouterControlResult = withContext(Dispatchers.IO) {
        if (device.macAddress.isBlank() || device.macAddress == "—") {
            return@withContext RouterControlResult(false, "لا يوجد عنوان MAC صالح لهذا الجهاز لتطبيق قاعدة الحظر.")
        }
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val sessionId = loginUbus(client, baseUrl, profile.username, password)
                ?: return@withContext RouterControlResult(false, "فشل المصادقة مع OpenWrt ubus.")

            val ruleName = "netcontrol_block_${device.macAddress.replace(":", "")}"
            if (blocked) {
                val addParams = JSONObject().apply {
                    put("config", "firewall")
                    put("type", "rule")
                    put("name", ruleName)
                    put("values", JSONObject().apply {
                        put("name", ruleName)
                        put("src", "lan")
                        put("dest", "wan")
                        put("src_mac", device.macAddress)
                        put("target", "REJECT")
                        put("enabled", "1")
                    })
                }
                callUbus(client, baseUrl, sessionId, "uci", "add", addParams)
            } else {
                val delParams = JSONObject().apply {
                    put("config", "firewall")
                    put("section", ruleName)
                }
                callUbus(client, baseUrl, sessionId, "uci", "delete", delParams)
            }
            callUbus(client, baseUrl, sessionId, "uci", "commit", JSONObject().put("config", "firewall"))
            callUbus(client, baseUrl, sessionId, "service", "reload", JSONObject().put("name", "firewall"))
            RouterControlResult(
                success = true,
                messageAr = if (blocked) "تم إيقاف الإنترنت عن ${device.displayName} عبر جدار حماية OpenWrt." else "تم السماح بالإنترنت مجددًا لـ ${device.displayName}."
            )
        }.getOrElse {
            RouterControlResult(false, "تعذر تنفيذ الأمر على OpenWrt: ${it.localizedMessage ?: "خطأ اتصال"}")
        }
    }

    override suspend fun setDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float
    ): RouterControlResult = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val sessionId = loginUbus(client, baseUrl, profile.username, password)
                ?: return@withContext RouterControlResult(false, "فشل المصادقة مع OpenWrt ubus.")

            // Check if netcontrol_qos CGI/ubus helper is installed on OpenWrt
            val resp = callUbus(
                client,
                baseUrl,
                sessionId,
                "file",
                "exec",
                JSONObject().apply {
                    put("command", "/usr/bin/netcontrol-tc")
                    put("params", JSONArray(listOf(device.ipAddress, maxDownloadMbps.toInt().toString(), maxUploadMbps.toInt().toString())))
                }
            )
            if (resp != null && resp.optInt("code", -1) == 0) {
                RouterControlResult(true, "تم تطبيق حد السرعة (${maxDownloadMbps} / ${maxUploadMbps} ميجابت/ث) على ${device.displayName}.")
            } else {
                RouterControlResult(
                    success = false,
                    messageAr = "لتطبيق حد السرعة على كل IP في OpenWrt يلزم تثبيت حزمة tc / netcontrol-tc أو ربط وسيط الشبكة المحلي.",
                    requiresGatewayAgent = true
                )
            }
        }.getOrElse {
            RouterControlResult(false, "تعذر تطبيق حد السرعة: ${it.localizedMessage}", requiresGatewayAgent = true)
        }
    }

    override suspend fun clearDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo
    ): RouterControlResult = setDeviceSpeedLimit(profile, password, device, 0f, 0f)

    override suspend fun restartWanConnection(
        profile: RouterProfile,
        password: String
    ): RouterControlResult = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val sessionId = loginUbus(client, baseUrl, profile.username, password)
                ?: return@withContext RouterControlResult(false, "فشل تسجيل الدخول إلى OpenWrt.")
            callUbus(client, baseUrl, sessionId, "network.interface.wan", "down", JSONObject())
            callUbus(client, baseUrl, sessionId, "network.interface.wan", "up", JSONObject())
            RouterControlResult(true, "تم إرسال أمر إعادة تشغيل واجهة WAN في OpenWrt بنجاح.")
        }.getOrElse {
            RouterControlResult(false, "تعذر إعادة تشغيل WAN: ${it.localizedMessage}")
        }
    }

    private fun loginUbus(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        username: String,
        password: String
    ): String? {
        val payload = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "call")
            put("params", JSONArray().apply {
                put("00000000000000000000000000000000")
                put("session")
                put("login")
                put(JSONObject().apply {
                    put("username", username)
                    put("password", password)
                })
            })
        }
        val req = Request.Builder()
            .url("$baseUrl/ubus")
            .post(payload.toString().toRequestBody(jsonMedia))
            .build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) return null
            val body = res.body?.string() ?: return null
            val json = JSONObject(body)
            val resultArr = json.optJSONArray("result") ?: return null
            if (resultArr.optInt(0, -1) != 0) return null
            return resultArr.optJSONObject(1)?.optString("ubus_rpc_session")?.takeIf { it.isNotBlank() }
        }
    }

    private fun callUbus(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        sessionId: String,
        obj: String,
        method: String,
        params: JSONObject
    ): JSONObject? {
        val payload = JSONObject().apply {
            put("jsonrpc", "2.0")
            put("id", 2)
            put("method", "call")
            put("params", JSONArray().apply {
                put(sessionId)
                put(obj)
                put(method)
                put(params)
            })
        }
        val req = Request.Builder()
            .url("$baseUrl/ubus")
            .post(payload.toString().toRequestBody(jsonMedia))
            .build()
        return runCatching {
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return null
                val json = JSONObject(res.body?.string() ?: return null)
                val resultArr = json.optJSONArray("result") ?: return null
                if (resultArr.optInt(0, -1) != 0) return null
                resultArr.optJSONObject(1)
            }
        }.getOrNull()
    }

    private fun fetchUbusHosts(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        sessionId: String
    ): List<DeviceInfo> {
        val hints = callUbus(client, baseUrl, sessionId, "luci-rpc", "getHostHints", JSONObject())
            ?: return emptyList()
        val now = System.currentTimeMillis()
        val list = mutableListOf<DeviceInfo>()
        val keys = hints.keys()
        while (keys.hasNext()) {
            val mac = keys.next()
            val obj = hints.optJSONObject(mac) ?: continue
            val ip = obj.optJSONArray("ipaddrs")?.optString(0).orEmpty().ifBlank { "—" }
            val name = obj.optString("name").ifBlank { "جهاز ($ip)" }
            val vendor = LanScannerEngine.lookupOuiVendor(mac)
            val type = LanScannerEngine.inferDeviceType(vendor, name)
            list.add(
                DeviceInfo(
                    id = "mac:${mac.uppercase()}",
                    originalName = name,
                    customName = "",
                    ipAddress = ip,
                    macAddress = mac.uppercase(),
                    deviceType = type,
                    manufacturer = vendor,
                    isOnline = true,
                    isKnown = false,
                    isNew = true,
                    isBlocked = false,
                    isPaused = false,
                    iconKey = LanScannerEngine.iconForDeviceType(type),
                    totalBytes = 0L,
                    downloadBytes = 0L,
                    uploadBytes = 0L,
                    todayBytes = 0L,
                    weekBytes = 0L,
                    monthBytes = 0L,
                    currentDownloadBps = 0L,
                    currentUploadBps = 0L,
                    lastSeenMillis = now,
                    sourceLabelAr = "OpenWrt ubus"
                )
            )
        }
        return list
    }
}
