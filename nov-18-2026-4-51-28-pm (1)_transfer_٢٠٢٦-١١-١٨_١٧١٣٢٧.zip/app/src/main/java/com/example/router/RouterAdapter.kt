package com.example.router

import com.example.domain.model.DeviceInfo
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import okhttp3.OkHttpClient
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

data class RouterSyncSnapshot(
    val profile: RouterProfile,
    val devices: List<DeviceInfo>,
    val totalRouterDownloadBytes: Long? = null,
    val totalRouterUploadBytes: Long? = null,
    val currentRouterDownloadBps: Long? = null,
    val currentRouterUploadBps: Long? = null
)

interface RouterAdapter {
    val vendor: RouterVendor
    val protocol: RouterProtocol

    fun capabilities(): RouterCapabilities

    suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot>

    suspend fun fetchDevices(
        profile: RouterProfile,
        password: String
    ): Result<List<DeviceInfo>>

    suspend fun setDeviceBlocked(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        blocked: Boolean
    ): RouterControlResult

    suspend fun setDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float
    ): RouterControlResult

    suspend fun clearDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo
    ): RouterControlResult

    suspend fun restartWanConnection(
        profile: RouterProfile,
        password: String
    ): RouterControlResult
}

object RouterHttpClients {
    fun buildClient(useHttps: Boolean): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .writeTimeout(4, TimeUnit.SECONDS)
            .followRedirects(true)

        if (useHttps) {
            // Routers on local LAN almost universally use self-signed certificates.
            runCatching {
                val trustAll = object : X509TrustManager {
                    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                }
                val sslContext = SSLContext.getInstance("TLS")
                sslContext.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
                builder.sslSocketFactory(sslContext.socketFactory, trustAll)
                builder.hostnameVerifier { _, _ -> true }
            }
        }
        return builder.build()
    }

    fun baseUrl(hostIp: String, port: Int, useHttps: Boolean): String {
        val scheme = if (useHttps) "https" else "http"
        val isDefaultPort = (useHttps && port == 443) || (!useHttps && port == 80)
        return if (isDefaultPort) "$scheme://$hostIp" else "$scheme://$hostIp:$port"
    }
}
