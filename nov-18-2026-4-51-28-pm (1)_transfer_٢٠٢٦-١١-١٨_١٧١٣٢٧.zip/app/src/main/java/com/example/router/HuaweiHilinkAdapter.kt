package com.example.router

import com.example.core.network.LanScannerEngine
import com.example.domain.model.DeviceInfo
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

class HuaweiHilinkAdapter : RouterAdapter {
    override val vendor: RouterVendor = RouterVendor.HUAWEI
    override val protocol: RouterProtocol = RouterProtocol.HILINK_HTTP

    override fun capabilities() = RouterCapabilities(
        supportsDeviceList = true,
        supportsPerDeviceTraffic = false,
        supportsQuotaEnforcement = false,
        supportsSpeedLimiting = false,
        supportsDeviceBlocking = false,
        supportsConnectionRestart = false,
        supportsLiveBandwidth = true,
        supportedFeaturesAr = listOf(
            "قراءة موديل راوتر هواوي وإصدار النظام",
            "مراقبة سرعة التحميل والرفع الإجمالية",
            "عرض الأجهزة المتصلة عبر /api/wlan/host-list"
        ),
        unsupportedFeaturesAr = listOf(
            "توزيع الجيجابايت لكل جهاز مباشرة من راوتر هواوي المنزلي",
            "تحديد سرعة كل جهاز على حدة (يلزم وسيط شبكي محلي)"
        ),
        technicalNoteAr = "معظم راوترات Huawei 4G/5G HiLink تعرض الاستهلاك الإجمالي وقائمة الأجهزة بدون مصادقة معقدة، بينما يتطلب التحكم بالسرعة والحصص وجود وسيط الشبكة المحلي."
    )

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)

            val infoBody = client.newCall(
                Request.Builder().url("$baseUrl/api/device/information").get().build()
            ).execute().use { res ->
                if (!res.isSuccessful) throw IllegalStateException("لم يستجب الراوتر لواجهة Huawei HiLink API.")
                res.body?.string().orEmpty()
            }
            if (!infoBody.contains("<DeviceName>", ignoreCase = true) && !infoBody.contains("<response>", ignoreCase = true)) {
                throw IllegalStateException("الاستجابة لا تطابق بروتوكول Huawei HiLink.")
            }

            val model = extractXmlTag(infoBody, "DeviceName").ifBlank { "Huawei Router" }
            val fw = extractXmlTag(infoBody, "SoftwareVersion").ifBlank { "HiLink" }

            var dlRate = 0L
            var ulRate = 0L
            var totalDl = 0L
            var totalUl = 0L

            runCatching {
                client.newCall(
                    Request.Builder().url("$baseUrl/api/monitoring/traffic-statistics").get().build()
                ).execute().use { tRes ->
                    val tBody = tRes.body?.string().orEmpty()
                    dlRate = extractXmlTag(tBody, "CurrentDownloadRate").toLongOrNull() ?: 0L
                    ulRate = extractXmlTag(tBody, "CurrentUploadRate").toLongOrNull() ?: 0L
                    totalDl = extractXmlTag(tBody, "TotalDownload").toLongOrNull() ?: 0L
                    totalUl = extractXmlTag(tBody, "TotalUpload").toLongOrNull() ?: 0L
                }
            }

            val devices = fetchHuaweiHosts(client, baseUrl)
            val profile = RouterProfile(
                vendor = RouterVendor.HUAWEI,
                protocol = RouterProtocol.HILINK_HTTP,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = "Huawei",
                modelName = model,
                firmwareVersion = fw,
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "متصل عبر واجهة Huawei HiLink XML",
                capabilities = capabilities()
            )
            RouterSyncSnapshot(
                profile = profile,
                devices = devices,
                totalRouterDownloadBytes = totalDl,
                totalRouterUploadBytes = totalUl,
                currentRouterDownloadBps = dlRate,
                currentRouterUploadBps = ulRate
            )
        }
    }

    override suspend fun fetchDevices(
        profile: RouterProfile,
        password: String
    ): Result<List<DeviceInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            fetchHuaweiHosts(client, baseUrl)
        }
    }

    override suspend fun setDeviceBlocked(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        blocked: Boolean
    ): RouterControlResult = RouterControlResult(
        success = false,
        messageAr = "هذا الموديل من Huawei HiLink لا يتيح حظر MAC مباشرة عبر API بدون جلسة CSRF كاملة أو وسيط شبكي.",
        requiresGatewayAgent = true
    )

    override suspend fun setDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float
    ): RouterControlResult = RouterControlResult(
        success = false,
        messageAr = "راوترات Huawei HiLink المنزلية لا تدعم تحديد السرعة لكل جهاز برمجيًا؛ فعّل وسيط الشبكة المحلي لتطبيق قواعد QoS.",
        requiresGatewayAgent = true
    )

    override suspend fun clearDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo
    ): RouterControlResult = setDeviceSpeedLimit(profile, password, device, 0f, 0f)

    override suspend fun restartWanConnection(
        profile: RouterProfile,
        password: String
    ): RouterControlResult = RouterControlResult(
        success = false,
        messageAr = "إعادة تشغيل اتصال Huawei HiLink يتطلب توثيق SesTokInfo في لوحة الراوتر الرسمية."
    )

    private fun fetchHuaweiHosts(client: okhttp3.OkHttpClient, baseUrl: String): List<DeviceInfo> {
        val xml = runCatching {
            client.newCall(Request.Builder().url("$baseUrl/api/wlan/host-list").get().build()).execute().use {
                it.body?.string().orEmpty()
            }
        }.getOrDefault("")
        if (xml.isBlank()) return emptyList()
        val now = System.currentTimeMillis()
        val hostBlocks = Regex("<Host>(.*?)</Host>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
        return hostBlocks.mapNotNull { match ->
            val block = match.groupValues[1]
            val ip = extractXmlTag(block, "IpAddress")
            val mac = extractXmlTag(block, "MacAddress").uppercase()
            val name = extractXmlTag(block, "HostName").ifBlank { "جهاز ($ip)" }
            if (ip.isBlank() && mac.isBlank()) return@mapNotNull null
            val vendor = LanScannerEngine.lookupOuiVendor(mac)
            val type = LanScannerEngine.inferDeviceType(vendor, name)
            DeviceInfo(
                id = if (mac.isNotBlank()) "mac:$mac" else "ip:$ip",
                originalName = name,
                customName = "",
                ipAddress = ip.ifBlank { "—" },
                macAddress = mac.ifBlank { "—" },
                deviceType = type,
                manufacturer = vendor,
                isOnline = true,
                isKnown = false,
                isNew = true,
                isBlocked = false,
                isPaused = false,
                iconKey = LanScannerEngine.iconForDeviceType(type),
                totalBytes = 0L,
                downloadBytes = 0L,
                uploadBytes = 0L,
                todayBytes = 0L,
                weekBytes = 0L,
                monthBytes = 0L,
                currentDownloadBps = 0L,
                currentUploadBps = 0L,
                lastSeenMillis = now,
                sourceLabelAr = "Huawei HiLink"
            )
        }.toList()
    }

    private fun extractXmlTag(xml: String, tag: String): String {
        val m = Regex("<$tag>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(xml)
        return m?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }
}
