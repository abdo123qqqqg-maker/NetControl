package com.example.router

import com.example.core.network.LanScannerEngine
import com.example.domain.model.DeviceInfo
import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterControlResult
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterProtocol
import com.example.domain.model.RouterVendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class MikroTikRouterOsAdapter : RouterAdapter {
    override val vendor: RouterVendor = RouterVendor.MIKROTIK
    override val protocol: RouterProtocol = RouterProtocol.ROUTEROS_REST

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    override fun capabilities() = RouterCapabilities(
        supportsDeviceList = true,
        supportsPerDeviceTraffic = true,
        supportsQuotaEnforcement = true,
        supportsSpeedLimiting = true,
        supportsDeviceBlocking = true,
        supportsConnectionRestart = true,
        supportsLiveBandwidth = true,
        supportedFeaturesAr = listOf(
            "قائمة أجهزة DHCP و ARP الفعلية",
            "قياس استهلاك كل جهاز من Simple Queues",
            "تحديد سرعة التحميل والرفع لكل جهاز (Queue Simple)",
            "حظر وإيقاف الإنترنت عبر Firewall Filter",
            "إعادة تشغيل واجهة الإنترنت (PPPoE / DHCP Client)"
        ),
        unsupportedFeaturesAr = emptyList(),
        technicalNoteAr = "يدعم RouterOS v7+ REST API (HTTP/HTTPS) بشكل مباشر. للإصدارات الأقدم v6 يُنصح بتفعيل وسيط الشبكة المحلي للوصول عبر منفذ API 8728."
    )

    override suspend fun probeAndConnect(
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(hostIp, port, useHttps)
            val client = RouterHttpClients.buildClient(useHttps)
            val auth = Credentials.basic(username, password)

            val resReq = Request.Builder()
                .url("$baseUrl/rest/system/resource")
                .header("Authorization", auth)
                .get()
                .build()

            val resourceJson = client.newCall(resReq).execute().use { res ->
                if (res.code == 401) throw IllegalStateException("بيانات الدخول غير صحيحة (401).")
                if (!res.isSuccessful) throw IllegalStateException("تعذر الوصول إلى MikroTik REST API (رمز ${res.code}).")
                JSONObject(res.body?.string() ?: "{}")
            }

            val model = resourceJson.optString("board-name").ifBlank { "MikroTik RouterBoard" }
            val fw = resourceJson.optString("version").ifBlank { "RouterOS v7+" }
            val devices = fetchMikroTikDevices(client, baseUrl, auth)

            val profile = RouterProfile(
                vendor = RouterVendor.MIKROTIK,
                protocol = RouterProtocol.ROUTEROS_REST,
                hostIp = hostIp,
                port = port,
                useHttps = useHttps,
                username = username,
                manufacturer = "MikroTik",
                modelName = model,
                firmwareVersion = fw,
                isConnected = true,
                lastCheckedMillis = System.currentTimeMillis(),
                statusMessageAr = "متصل بنجاح عبر MikroTik RouterOS REST API",
                capabilities = capabilities()
            )
            RouterSyncSnapshot(profile = profile, devices = devices)
        }
    }

    override suspend fun fetchDevices(
        profile: RouterProfile,
        password: String
    ): Result<List<DeviceInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val auth = Credentials.basic(profile.username, password)
            fetchMikroTikDevices(client, baseUrl, auth)
        }
    }

    override suspend fun setDeviceBlocked(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        blocked: Boolean
    ): RouterControlResult = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val auth = Credentials.basic(profile.username, password)
            val commentTag = "netcontrol_block_${device.ipAddress}"

            if (blocked) {
                val payload = JSONObject().apply {
                    put("chain", "forward")
                    put("src-address", device.ipAddress)
                    put("action", "drop")
                    put("comment", commentTag)
                }
                val req = Request.Builder()
                    .url("$baseUrl/rest/ip/firewall/filter")
                    .header("Authorization", auth)
                    .put(payload.toString().toRequestBody(jsonMedia))
                    .build()
                client.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) {
                        return@withContext RouterControlResult(false, "رفض MikroTik إضافة قاعدة الحظر (${res.code}).")
                    }
                }
                RouterControlResult(true, "تم حظر الإنترنت عن ${device.displayName} عبر جدار حماية MikroTik.")
            } else {
                // Find rule ID by comment and remove
                val listReq = Request.Builder()
                    .url("$baseUrl/rest/ip/firewall/filter")
                    .header("Authorization", auth)
                    .get()
                    .build()
                val idsToRemove = mutableListOf<String>()
                client.newCall(listReq).execute().use { res ->
                    if (res.isSuccessful) {
                        val arr = JSONArray(res.body?.string() ?: "[]")
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            if (item.optString("comment") == commentTag) {
                                item.optString(".id").takeIf { it.isNotBlank() }?.let { idsToRemove.add(it) }
                            }
                        }
                    }
                }
                idsToRemove.forEach { ruleId ->
                    val delReq = Request.Builder()
                        .url("$baseUrl/rest/ip/firewall/filter/$ruleId")
                        .header("Authorization", auth)
                        .delete()
                        .build()
                    client.newCall(delReq).execute().close()
                }
                RouterControlResult(true, "تم رفع الحظر عن ${device.displayName} في MikroTik.")
            }
        }.getOrElse {
            RouterControlResult(false, "خطأ اتصال مع MikroTik: ${it.localizedMessage}")
        }
    }

    override suspend fun setDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo,
        maxDownloadMbps: Float,
        maxUploadMbps: Float
    ): RouterControlResult = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val auth = Credentials.basic(profile.username, password)
            val queueName = "nc_limit_${device.ipAddress}"
            val upLimit = if (maxUploadMbps <= 0f) "0" else "${maxUploadMbps.toInt().coerceAtLeast(1)}M"
            val downLimit = if (maxDownloadMbps <= 0f) "0" else "${maxDownloadMbps.toInt().coerceAtLeast(1)}M"

            // Check if queue exists
            val existingId = findSimpleQueueId(client, baseUrl, auth, queueName)
            val payload = JSONObject().apply {
                put("name", queueName)
                put("target", "${device.ipAddress}/32")
                put("max-limit", "$upLimit/$downLimit")
            }

            val req = if (existingId != null) {
                Request.Builder()
                    .url("$baseUrl/rest/queue/simple/$existingId")
                    .header("Authorization", auth)
                    .patch(payload.toString().toRequestBody(jsonMedia))
                    .build()
            } else {
                Request.Builder()
                    .url("$baseUrl/rest/queue/simple")
                    .header("Authorization", auth)
                    .put(payload.toString().toRequestBody(jsonMedia))
                    .build()
            }
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    return@withContext RouterControlResult(false, "تعذر ضبط Simple Queue على MikroTik (${res.code}).")
                }
            }
            RouterControlResult(true, "تم تطبيق تحديد السرعة ($downLimit تنزيل / $upLimit رفع) على ${device.displayName} عبر MikroTik.")
        }.getOrElse {
            RouterControlResult(false, "تعذر الاتصال بـ MikroTik: ${it.localizedMessage}")
        }
    }

    override suspend fun clearDeviceSpeedLimit(
        profile: RouterProfile,
        password: String,
        device: DeviceInfo
    ): RouterControlResult = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = RouterHttpClients.baseUrl(profile.hostIp, profile.port, profile.useHttps)
            val client = RouterHttpClients.buildClient(profile.useHttps)
            val auth = Credentials.basic(profile.username, password)
            val queueName = "nc_limit_${device.ipAddress}"
            val existingId = findSimpleQueueId(client, baseUrl, auth, queueName)
            if (existingId != null) {
                val delReq = Request.Builder()
                    .url("$baseUrl/rest/queue/simple/$existingId")
                    .header("Authorization", auth)
                    .delete()
                    .build()
                client.newCall(delReq).execute().close()
            }
            RouterControlResult(true, "تم إلغاء قيد السرعة عن ${device.displayName}.")
        }.getOrElse {
            RouterControlResult(false, "تعذر إلغاء قيد السرعة: ${it.localizedMessage}")
        }
    }

    override suspend fun restartWanConnection(
        profile: RouterProfile,
        password: String
    ): RouterControlResult = withContext(Dispatchers.IO) {
        RouterControlResult(
            success = false,
            messageAr = "لأمان الشبكة، اختر واجهة WAN المحددة من داخل Winbox أو استخدم إعادة تهيئة DHCP Client."
        )
    }

    private fun findSimpleQueueId(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        auth: String,
        name: String
    ): String? {
        val req = Request.Builder()
            .url("$baseUrl/rest/queue/simple")
            .header("Authorization", auth)
            .get()
            .build()
        return runCatching {
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return null
                val arr = JSONArray(res.body?.string() ?: "[]")
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    if (item.optString("name") == name) return item.optString(".id")
                }
                null
            }
        }.getOrNull()
    }

    private fun fetchMikroTikDevices(
        client: okhttp3.OkHttpClient,
        baseUrl: String,
        auth: String
    ): List<DeviceInfo> {
        val now = System.currentTimeMillis()
        val leaseReq = Request.Builder()
            .url("$baseUrl/rest/ip/dhcp-server/lease")
            .header("Authorization", auth)
            .get()
            .build()

        val queueMap = mutableMapOf<String, Pair<Long, Long>>()
        runCatching {
            val qReq = Request.Builder()
                .url("$baseUrl/rest/queue/simple")
                .header("Authorization", auth)
                .get()
                .build()
            client.newCall(qReq).execute().use { qRes ->
                if (qRes.isSuccessful) {
                    val arr = JSONArray(qRes.body?.string() ?: "[]")
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val target = obj.optString("target").substringBefore("/")
                        val bytesParts = obj.optString("bytes").split("/")
                        val up = bytesParts.getOrNull(0)?.toLongOrNull() ?: 0L
                        val down = bytesParts.getOrNull(1)?.toLongOrNull() ?: 0L
                        if (target.isNotBlank()) queueMap[target] = down to up
                    }
                }
            }
        }

        val devices = mutableListOf<DeviceInfo>()
        client.newCall(leaseReq).execute().use { res ->
            if (!res.isSuccessful) return emptyList()
            val arr = JSONArray(res.body?.string() ?: "[]")
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val ip = obj.optString("address").ifBlank { continue }
                val mac = obj.optString("mac-address").uppercase()
                val hostName = obj.optString("host-name").ifBlank { "جهاز ($ip)" }
                val status = obj.optString("status")
                val vendor = LanScannerEngine.lookupOuiVendor(mac)
                val type = LanScannerEngine.inferDeviceType(vendor, hostName)
                val usage = queueMap[ip] ?: (0L to 0L)
                devices.add(
                    DeviceInfo(
                        id = if (mac.isNotBlank()) "mac:$mac" else "ip:$ip",
                        originalName = hostName,
                        customName = "",
                        ipAddress = ip,
                        macAddress = mac.ifBlank { "—" },
                        deviceType = type,
                        manufacturer = vendor,
                        isOnline = status == "bound",
                        isKnown = false,
                        isNew = true,
                        isBlocked = obj.optString("blocked") == "true",
                        isPaused = false,
                        iconKey = LanScannerEngine.iconForDeviceType(type),
                        totalBytes = usage.first + usage.second,
                        downloadBytes = usage.first,
                        uploadBytes = usage.second,
                        todayBytes = usage.first + usage.second,
                        weekBytes = usage.first + usage.second,
                        monthBytes = usage.first + usage.second,
                        currentDownloadBps = 0L,
                        currentUploadBps = 0L,
                        lastSeenMillis = now,
                        sourceLabelAr = "MikroTik DHCP/Queue"
                    )
                )
            }
        }
        return devices
    }
}
