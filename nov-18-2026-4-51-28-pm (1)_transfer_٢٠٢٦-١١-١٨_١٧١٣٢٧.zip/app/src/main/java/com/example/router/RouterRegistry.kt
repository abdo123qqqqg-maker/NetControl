package com.example.router

import com.example.domain.model.RouterCapabilities
import com.example.domain.model.RouterProfile
import com.example.domain.model.RouterVendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Socket

class RouterRegistry {

    private val adapters: Map<RouterVendor, RouterAdapter> = mapOf(
        RouterVendor.OPENWRT to OpenWrtUbusAdapter(),
        RouterVendor.MIKROTIK to MikroTikRouterOsAdapter(),
        RouterVendor.HUAWEI to HuaweiHilinkAdapter(),
        RouterVendor.TR064_UPNP to Tr064UpnpAdapter(),
        RouterVendor.TPLINK to VendorHttpFingerprintAdapter(RouterVendor.TPLINK),
        RouterVendor.ASUS to VendorHttpFingerprintAdapter(RouterVendor.ASUS),
        RouterVendor.ZTE to VendorHttpFingerprintAdapter(RouterVendor.ZTE),
        RouterVendor.TENDA to VendorHttpFingerprintAdapter(RouterVendor.TENDA),
        RouterVendor.GATEWAY_AGENT to NetControlGatewayAdapter()
    )

    fun adapterFor(vendor: RouterVendor): RouterAdapter {
        return adapters[vendor] ?: adapters.getValue(RouterVendor.TPLINK)
    }

    fun capabilitiesFor(vendor: RouterVendor): RouterCapabilities {
        return if (vendor == RouterVendor.AUTO) {
            RouterCapabilities(
                technicalNoteAr = "اضغط «اكتشاف تلقائي» لاختبار البروتوكولات المدعومة على عنوان الراوتر."
            )
        } else {
            adapterFor(vendor).capabilities()
        }
    }

    suspend fun autoDetectVendor(hostIp: String): RouterVendor = withContext(Dispatchers.IO) {
        if (hostIp.isBlank() || hostIp == "—") return@withContext RouterVendor.AUTO
        val client = RouterHttpClients.buildClient(false)

        // 1. Check Gateway Agent (:8090/api/v1/status)
        if (isPortOpen(hostIp, 8090)) {
            val gw = runCatching {
                client.newCall(Request.Builder().url("http://$hostIp:8090/api/v1/status").get().build()).execute().use { it.isSuccessful }
            }.getOrDefault(false)
            if (gw) return@withContext RouterVendor.GATEWAY_AGENT
        }

        // 2. Check OpenWrt /ubus
        val hasUbus = runCatching {
            client.newCall(Request.Builder().url("http://$hostIp/ubus").get().build()).execute().use {
                it.code == 400 || it.code == 405 || it.code == 200
            }
        }.getOrDefault(false)
        if (hasUbus) return@withContext RouterVendor.OPENWRT

        // 3. Check MikroTik REST /rest or port 8728
        if (isPortOpen(hostIp, 8728)) return@withContext RouterVendor.MIKROTIK
        val hasMikroTikRest = runCatching {
            client.newCall(Request.Builder().url("http://$hostIp/rest/system/resource").get().build()).execute().use {
                it.code == 401 || it.isSuccessful
            }
        }.getOrDefault(false)
        if (hasMikroTikRest) return@withContext RouterVendor.MIKROTIK

        // 4. Check Huawei HiLink XML API
        val hasHuawei = runCatching {
            client.newCall(Request.Builder().url("http://$hostIp/api/device/information").get().build()).execute().use {
                val body = it.body?.string().orEmpty()
                body.contains("<DeviceName>", ignoreCase = true) || body.contains("<response>", ignoreCase = true)
            }
        }.getOrDefault(false)
        if (hasHuawei) return@withContext RouterVendor.HUAWEI

        // 5. Check TR-064 / UPnP port 49000
        if (isPortOpen(hostIp, 49000)) return@withContext RouterVendor.TR064_UPNP

        // 6. Inspect HTML title / Server header on port 80
        val fingerprint = runCatching {
            client.newCall(Request.Builder().url("http://$hostIp").get().build()).execute().use { res ->
                val html = res.body?.string().orEmpty().take(4096)
                val hdr = res.header("Server").orEmpty()
                "$hdr $html".lowercase()
            }
        }.getOrDefault("")

        when {
            fingerprint.contains("tp-link") || fingerprint.contains("archer") -> RouterVendor.TPLINK
            fingerprint.contains("asus") || fingerprint.contains("asuswrt") -> RouterVendor.ASUS
            fingerprint.contains("huawei") -> RouterVendor.HUAWEI
            fingerprint.contains("zte") -> RouterVendor.ZTE
            fingerprint.contains("tenda") -> RouterVendor.TENDA
            fingerprint.contains("luci") || fingerprint.contains("openwrt") -> RouterVendor.OPENWRT
            fingerprint.contains("mikrotik") || fingerprint.contains("routeros") -> RouterVendor.MIKROTIK
            else -> RouterVendor.TR064_UPNP
        }
    }

    suspend fun connect(
        vendor: RouterVendor,
        hostIp: String,
        port: Int,
        useHttps: Boolean,
        username: String,
        password: String
    ): Result<RouterSyncSnapshot> {
        val resolvedVendor = if (vendor == RouterVendor.AUTO) {
            autoDetectVendor(hostIp)
        } else vendor
        val effectivePort = if (port <= 0) resolvedVendor.defaultPorts.firstOrNull() ?: 80 else port
        return adapterFor(resolvedVendor).probeAndConnect(hostIp, effectivePort, useHttps, username, password)
    }

    fun resolveControlAdapter(profile: RouterProfile): RouterAdapter {
        return if (profile.gatewayAgentConnected && profile.gatewayAgentUrl.isNotBlank()) {
            adapterFor(RouterVendor.GATEWAY_AGENT)
        } else {
            adapterFor(profile.vendor)
        }
    }

    private fun isPortOpen(ip: String, port: Int): Boolean {
        return runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), 500)
                true
            }
        }.getOrDefault(false)
    }
}
